#ifndef myoptions_h
#define myoptions_h

/* Ссылка на генератор с настроенными пинами: https://trip5.github.io/ehRadio_myoptions/generator.html?b=ESP32-S3-DevKitC-1_44Pin&r=72,1,2,4,9,73,42,43,54&i=1,2,3,4,15,16,17,28,29,30&v=9,10,-1,255,42,41,2,5,6,4 */
/* Maleksm мод: https://4pda.to/forum/index.php?showtopic=1010378&st=11240#entry125839228 */
/* Ядро 3.2.0 + модифицированные библиотеки для него: https://4pda.to/forum/index.php?showtopic=1010378&st=23280#entry136601043 */
/* Библиотеки надо для s3 положить по пути с заменой: C:\Users\USER\AppData\Local\Arduino15\packages\esp32\tools\esp32-arduino-libs\idf-release_v5.4-2f7dcd86-v1\esp32s3\lib */
/* Для дисплея DSP_SSD1322 тоже все настроено, надо только его включить */

#define ARDUINO_ESP32S3_DEV

//#define DSP_MODEL			DSP_SSD1322
#define DSP_MODEL   DSP_ST7789_76
#define TFT_DC			9
#define TFT_CS			10
#define TFT_RST			-1
#define BRIGHTNESS_PIN			8
#define I2S_DOUT			42
#define I2S_BCLK			41
#define I2S_LRC			2
#define ENC_BTNR      5
#define ENC_BTNL      6
#define ENC_BTNB      4
#define ENC_INTERNALPULLUP			true
#define L10N_LANGUAGE RU
#define BATTERY_OFF           
#define HIDE_VOLT


#endif

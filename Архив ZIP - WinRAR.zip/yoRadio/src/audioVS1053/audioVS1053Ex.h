/*
 *  vs1053_ext.h
 *
 *  Created on: Jul 09.2017
 *  Updated on: Sep 15.2025 (Maleksm)
 *      Author: Wolle (schreibfaul1), easy
 */
#if VS1053_CS!=255
#ifndef _vs1053_ext
#define _vs1053_ext

//#pragma once
//#pragma GCC optimize ("Ofast")
//#include "esp_arduino_version.h"
#include <vector>
#include <deque>
#include <charconv>
//#include <functional>
#include <Arduino.h>
#include <libb64/cencode.h>
#include <SPI.h>
//#include <esp32-hal-log.h>
//#include <WiFi.h>
#include <SD.h>
//#include <SD_MMC.h>
#include <FS.h>
#include <FFat.h>
#include <atomic>
#include <codecvt>
#include <locale>
#include <memory>
#include <NetworkClient.h>
#include <NetworkClientSecure.h>
#include "../audioI2S/audiolib_structs.hpp"

//#include "SPI.h"

#if ESP_IDF_VERSION_MAJOR >= 5
    #include "driver/gpio.h"
#endif

#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
#include "hal/gpio_ll.h"
#endif

#include "vs1053b-patches-flac.h"

#define VS1053VOLM 128				// 128 or 96 only
#define VS1053VOL(v) (VS1053VOLM==128?log10(((float)v+1)) * 50.54571334 + 128:log10(((float)v+1)) * 64.54571334 + 96)

extern __attribute__((weak)) void audio_info(const char*);
extern __attribute__((weak)) void audio_id3data(const char*); //ID3 metadata
//extern __attribute__((weak)) void audio_id3image(File& file, const size_t pos, const size_t size); //ID3 metadata image
//extern __attribute__((weak)) void audio_oggimage(File& file, std::vector<uint32_t> v); //OGG blockpicture
//extern __attribute__((weak)) void audio_id3lyrics(const char* text); //ID3 metadata lyrics
extern __attribute__((weak)) void audio_eof_mp3(const char*); //end of file
extern __attribute__((weak)) void audio_showstreamtitle(const char*);
//extern __attribute__((weak)) void audio_showstation(const char*);
extern __attribute__((weak)) void audio_bitrate(const char*);
extern __attribute__((weak)) void audio_icyurl(const char*);
//extern __attribute__((weak)) void audio_icylogo(const char*);
//	extern __attribute__((weak)) void audio_icydescription(const char*);
extern __attribute__((weak)) void audio_lasthost(const char*);
extern __attribute__((weak)) void audio_eof_stream(const char*); // The webstream comes to an end

extern __attribute__((weak)) void audio_log(uint8_t logLevel, const char* msg, const char* arg);
extern __attribute__((weak)) void audio_id3artist(const char*);
extern __attribute__((weak)) void audio_id3album(const char*);
//extern __attribute__((weak)) void audio_id3title(const char*);
extern __attribute__((weak)) void audio_beginSDread();
extern __attribute__((weak)) void audio_progress(uint32_t startpos, uint32_t endpos);
extern __attribute__((weak)) void audio_error(const char*);
//----------------------------------------------------------------------------------------------------------------------

class AudioBuffer {
// AudioBuffer will be allocated in PSRAM
//
//  m_buffer            m_readPtr                 m_writePtr                 m_endPtr
//   |                       |<------dataLength------->|<------ writeSpace ----->|
//   ▼                       ▼                         ▼                         ▼
//   ---------------------------------------------------------------------------------------------------------------
//   |                     <--m_buffSize-->                                      |      <--m_resBuffSize -->     |
//   ---------------------------------------------------------------------------------------------------------------
//   |<-----freeSpace------->|                         |<------freeSpace-------->|
//
//
//
//   if the space between m_readPtr and buffend < m_resBuffSize copy data from the beginning to resBuff
//   so that the mp3/aac/flac frame is always completed
//
//  m_buffer                      m_writePtr                 m_readPtr        m_endPtr
//   |                                 |<-------writeSpace------>|<--dataLength-->|
//   ▼                                 ▼                         ▼                ▼
//   ---------------------------------------------------------------------------------------------------------------
//   |                        <--m_buffSize-->                                    |      <--m_resBuffSize -->     |
//   ---------------------------------------------------------------------------------------------------------------
//   |<---  ------dataLength--  ------>|<-------freeSpace------->|
//
//

public:
    AudioBuffer(size_t maxBlockSize = 0);       // constructor
    ~AudioBuffer();                             // frees the buffer
    size_t   init();                            // set default values
    bool     isInitialized() { return m_f_init; };
    int32_t  getBufsize();
    bool     setBufsize(size_t mbs);            // default is m_buffSizePSRAM for psram, and m_buffSizeRAM without psram
//    void     setBufsize(int ram, int psram);            // default is m_buffSizePSRAM for psram, and m_buffSizeRAM without psram
    void     changeMaxBlockSize(uint16_t mbs);  // is default 1600 for mp3 and aac, set 16384 for FLAC
    uint16_t getMaxBlockSize();                 // returns maxBlockSize
    size_t   freeSpace();                       // number of free bytes to overwrite
    size_t   writeSpace();                      // space fom writepointer to bufferend
    size_t   bufferFilled();                    // returns the number of filled bytes
    size_t   getMaxAvailableBytes();            // max readable bytes in one block
    void     bytesWritten(size_t bw);           // update writepointer
    void     bytesWasRead(size_t br);           // update readpointer
    uint8_t* getWritePtr();                     // returns the current writepointer
    uint8_t* getReadPtr();                      // returns the current readpointer
    uint32_t getWritePos();                     // write position relative to the beginning
    uint32_t getReadPos();                      // read position relative to the beginning
    void     resetBuffer();                     // restore defaults

protected:
    size_t            m_buffSize         = UINT16_MAX * 10;   // most webstreams limit the advance to 100...300Kbytes
    size_t            m_freeSpace        = 0;
    size_t            m_writeSpace       = 0;
    size_t            m_dataLength       = 0;
    size_t            m_resBuffSize      = 4096 * 6; // reserved buffspace, >= one flac frame
    size_t            m_maxBlockSize     = 1600;
    ps_ptr<uint8_t>   m_buffer;
    uint8_t*          m_writePtr         = NULL;
    uint8_t*          m_readPtr          = NULL;
    uint8_t*          m_endPtr           = NULL;
    bool              m_f_init           = false;
    bool              m_f_isEmpty        = true;
};
//----------------------------------------------------------------------------------------------------------------------


class Audio{

    AudioBuffer InBuff; // instance of input buffer

public:
    // Constructor.  Only sets pin values.  Doesn't touch the chip.  Be sure to call begin()!
    //Audio(uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, uint8_t spi, uint8_t mosi, uint8_t miso, uint8_t sclk);
    //Audio ( uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, uint8_t spi = VSPI, uint8_t mosi = 23, uint8_t miso = 19, uint8_t sclk = 18);
    Audio ( uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, SPIClass *spi=&SPI);
    ~Audio();

// callbacks ---------------------------------------------------------
/*    typedef enum {evt_info = 0, evt_id3data, evt_eof, evt_name, evt_icydescription, evt_streamtitle, evt_bitrate, evt_icyurl, evt_icylogo, evt_lasthost, evt_image, evt_lyrics, evt_log} event_t;
    const char* eventStr[13] = {"info", "id3data", "eof", "station_name", "icy_description", "streamtitle", "bitrate", "icy_url", "icy_logo", "lasthost", "cover_image", "lyrics", "log"};
    typedef struct _msg{ // used in info(audio_info_callback());
        const char* msg = nullptr;
        const char* s = nullptr;
        event_t e = (event_t)0; // event type
        uint8_t i2s_num = 0;
        int32_t arg1 = 0;
        int32_t arg2 = 0;
        std::vector<uint32_t> vec = {}; // apic [pos, len, pos, len, pos, len, ....]
    } msg_t;
    inline static std::function<void(msg_t i)> audio_info_callback;*/
// -------------------------------------------------------------------

    void     begin() ;                                // Begin operation.  Sets pins correctly and prepares SPI bus.
    void     printDetails(const char* str);           // Print configuration details to serial output.
    uint8_t  printVersion();                            // Returns version of vs1053 chip
    uint32_t printChipID();                            // Returns chipID of vs1053 chip
//   bool   setBitrate(uint32_t br);
//    void     softReset() ;                              // Do a soft reset
    void     computeVUlevel();
//    void     loadUserCode();

    bool         openai_speech(const String& api_key, const String& model, const String& input, const String& instructions, const String& voice, const String& response_format, const String& speed);
    audiolib::hwoe_t       dismantle_host(const char* host);
    bool         connecttohost(const char* host, const char* user = "", const char* pwd = "");
    bool         connecttospeech(const char* speech, const char* lang);
    bool         connecttoFS(fs::FS& fs, const char* path, int32_t fileStartPos = -1);
//    bool setFileLoop(bool input);//TEST loop
    void         setConnectionTimeout(uint16_t timeout_ms, uint16_t timeout_ms_ssl);
//    bool         setAudioPlayTime(uint16_t sec);
//    bool audioFileSeek(const float speed);
    bool         setTimeOffset(int sec);
    bool         pauseResume();
    bool         isRunning() { return m_f_running; }
    void         loop();
    uint32_t     stopSong(); 			// Finish playing a song. Call this after the last playChunk call.
    void           startSong(); 			// Prepare to start playing. Call this each time a new song starts.
    void         forceMono(bool m);
    void         setBalance(int8_t bal = 0);	 // Adjusting the left and right volume balance, higher - right, lower - left side.
    void         setVolume(uint8_t vol);            // Set the player volume.Level from 0-255, higher is louder.
    uint8_t      getVolume();                              // Get the current volume setting, higher is louder.
    uint32_t     getFileSize();
//    uint32_t     getSampleRate();
//    uint8_t      getBitsPerSample();
//    uint8_t      getChannels();
    uint32_t     getBitRate();			// average br from WRAM register
    uint32_t     getAudioFileDuration();
    uint32_t     getAudioCurrentTime();
/*    uint32_t     getAudioFilePosition();*/    uint32_t getFilePos();
/*    bool     setAudioFilePosition(uint32_t pos);*/    bool     setFilePos(uint32_t pos);
//    bool         fsRange(uint32_t range);
//    uint32_t     getTotalPlayingTime();
    /* VU METER */
/*    uint16_t     getVUlevel();*/    uint16_t     get_VUlevel(uint16_t dimension);
    void           setVUmeter();
    bool           eofHeader;
    void           setDefaults(); // free buffers and set defaults
    uint32_t     inBufferFilled();            // returns the number of stored bytes in the inputbuffer
//    uint32_t     inBufferFree();              // returns the number of free bytes in the inputbuffer
//    uint32_t     getInBufferSize();           // returns the size of the inputbuffer in bytes
//    bool        setInBufferSize(size_t mbs); // sets the size of the inputbuffer in bytes
    void         setTone(int8_t* rtone);           // Set the player baas/treble, 4 nibbles for treble gain/freq and bass gain/freq
    void         setTone(int8_t gainLowPass, int8_t gainBandPass, int8_t gainHighPass);
    int          getCodec() { return m_codec; }
    const char*  getCodecname() { return codecname[m_codec]; }
//    const char*  getVersion() { return audioI2SVers; }

private:
    uint8_t       cs_pin; 		// Pin where CS line is connected
    uint8_t       dcs_pin; 		// Pin where DCS line is connected
    uint8_t       dreq_pin; 		// Pin where DREQ line is connected
//    uint8_t       mosi_pin; 		// Pin where MOSI line is connected
//    uint8_t       miso_pin; 		// Pin where MISO line is connected
//    uint8_t       sclk_pin; 		// Pin where SCLK line is connected
    uint8_t       curvol; 				// Current volume setting 0..100%
    int8_t         m_balance = 0; 		// -16 (mute left) ... +16 (mute right)

    const uint8_t vs1053_chunk_size = 32 ;
    // SCI Register
    const uint8_t SCI_MODE          = 0x0 ;
    const uint8_t SCI_STATUS        = 0x1 ;
    const uint8_t SCI_BASS          = 0x2 ;
    const uint8_t SCI_CLOCKF        = 0x3 ;
    const uint8_t SCI_DECODE_TIME   = 0x4 ;        // current decoded time in full seconds
    const uint8_t SCI_AUDATA        = 0x5 ;
    const uint8_t SCI_WRAM          = 0x6 ;
    const uint8_t SCI_WRAMADDR      = 0x7 ;
    const uint8_t SCI_HDAT0         = 0x8 ; 		// (Read average bitRate from WRAM register)
    const uint8_t SCI_HDAT1         = 0x9 ; 		// (Read laer and ID from WRAM register)
    const uint8_t SCI_AIADDR        = 0xA ;
    const uint8_t SCI_VOL           = 0xB ;
    const uint8_t SCI_AICTRL0       = 0xC ;
    const uint8_t SCI_AICTRL1       = 0xD ;
    const uint8_t SCI_AICTRL2       = 0xE ;
    const uint8_t SCI_AICTRL3       = 0xF ;
    // SCI_MODE bits
    const uint8_t SM_SDINEW         = 11 ;        	// Bitnumber in SCI_MODE always on
    const uint8_t SM_RESET          = 2 ;        	// Bitnumber in SCI_MODE soft reset
    const uint8_t SM_CANCEL         = 3 ;         	// Bitnumber in SCI_MODE cancel song
    const uint8_t SM_TESTS          = 5 ;         	// Bitnumber in SCI_MODE for tests
    const uint8_t SM_LINE1          = 14 ;        	// Bitnumber in SCI_MODE for Line input

    SPIClass*       spi_VS1053 = NULL;
    SPISettings     VS1053_SPI_DATA;                // SPI settings normal speed
    SPISettings     VS1053_SPI_CTL;                 // SPI settings control mode



protected:

    #ifndef ESP_ARDUINO_VERSION_VAL
        #define ESP_ARDUINO_VERSION_MAJOR 0
        #define ESP_ARDUINO_VERSION_MINOR 0
        #define ESP_ARDUINO_VERSION_PATCH 0
    #endif

//    #if ESP_IDF_VERSION_MAJOR < 5
        inline void DCS_HIGH() {(dcs_pin&0x20) ? GPIO.out1_w1ts.data = 1 << (dcs_pin - 32) : GPIO.out_w1ts = 1 << dcs_pin;}
        inline void DCS_LOW()  {(dcs_pin&0x20) ? GPIO.out1_w1tc.data = 1 << (dcs_pin - 32) : GPIO.out_w1tc = 1 << dcs_pin;}
        inline void CS_HIGH()  {( cs_pin&0x20) ? GPIO.out1_w1ts.data = 1 << ( cs_pin - 32) : GPIO.out_w1ts = 1 <<  cs_pin;}
        inline void CS_LOW()   {( cs_pin&0x20) ? GPIO.out1_w1tc.data = 1 << ( cs_pin - 32) : GPIO.out_w1tc = 1 <<  cs_pin;}
/*    #else
        inline void DCS_HIGH() {gpio_set_level((gpio_num_t)dcs_pin, 1);}
        inline void DCS_LOW()  {gpio_set_level((gpio_num_t)dcs_pin, 0);}
        inline void CS_HIGH()  {gpio_set_level((gpio_num_t) cs_pin, 1);}
        inline void CS_LOW()   {gpio_set_level((gpio_num_t) cs_pin, 0);}
//    #endif		*/

    inline void await_data_request() {while(!digitalRead(dreq_pin)) NOP();}	  // Very short delay
    inline bool data_request()     {return(digitalRead(dreq_pin) == HIGH);}

    void     initInBuff();
    void     control_mode_on();
    void     control_mode_off();
    void     data_mode_on();
    void     data_mode_off();
    uint16_t read_register ( uint8_t _reg ) ;
    void     write_register ( uint8_t _reg, uint16_t _value );
    void     sdi_send_buffer ( uint8_t* data, size_t len );
    size_t      sendBytes(uint8_t* data, size_t len);
    void     sdi_send_fillers ( size_t length );
    void     wram_write ( uint16_t address, uint16_t data );
    uint16_t wram_read ( uint16_t address );
    void     loadUserCode();

private:
    // ------- PRIVATE MEMBERS ----------------------------------------
//    template <typename... Args>
//    void         info(event_t e, const char* fmt, Args&&... args);
//    void         info(event_t e, std::vector<uint32_t>& v);
private:
    void         latinToUTF8(ps_ptr<char>& buff, bool UTF8check = true);
    void         htmlToUTF8(char* str);
// displased
    int32_t      audioFileRead(uint8_t* buff = nullptr, size_t len = 0);
    int32_t      audioFileSeek(uint32_t position, size_t len = 0);
    bool         httpPrint(const char* host);
    bool         httpRange(uint32_t range, uint32_t length = UINT32_MAX);
    void         processLocalFile();
    void         processWebStream();
    void         processWebFile();
    void         processWebStreamTS();
    void         processWebStreamHLS();
    void         playAudioData();
    bool         readPlayListData();
    const char*  parsePlaylist_M3U();
    const char*  parsePlaylist_PLS();
    const char*  parsePlaylist_ASX();
    ps_ptr<char> parsePlaylist_M3U8();
    uint16_t     accomplish_m3u8_url();
    int16_t      prepare_first_m3u8_url(ps_ptr<char>& playlistBuff);
    ps_ptr<char> m3u8redirection(uint8_t* codec);
//    void         showCodecParams();
    int          findNextSync(uint8_t* data, size_t len);
//    uint32_t     decodeError(int8_t res, uint8_t* data, int32_t bytesDecoded);
//    uint32_t     decodeContinue(int8_t res, uint8_t* data, int32_t bytesDecoded);
//    void         calculateAudioTime(uint16_t bytesDecoderIn, uint16_t bytesDecoderOut);
    void         showID3Tag(const char* tag, const char* val);
    size_t       readAudioHeader(uint32_t bytes);
    int          read_WAV_Header(uint8_t* data, size_t len);
    int          read_FLAC_Header(uint8_t* data, size_t len);
//    int          read_OPUS_Header(uint8_t* data, size_t len);
//    int          read_VORBIS_Header(uint8_t* data, size_t len);
//   int           read_OGG_Header(uint8_t *data, size_t len);
    int          read_ID3_Header(uint8_t* data, size_t len);
    int          read_M4A_Header(uint8_t* data, size_t len);
    size_t       process_m3u8_ID3_Header(uint8_t* packet);
//    void         playChunk();
    void         showstreamtitle(char* ml);
    bool         parseContentType(char* ct);
    bool         parseHttpResponseHeader();
    bool         parseHttpRangeHeader();
    bool         initializeDecoder(uint8_t codec);
//    void        printProcessLog(int r, const char* s = "");
    uint32_t  streamavail() { return m_client ? m_client->available() : 0; }
    bool        ts_parsePacket(uint8_t* packet, uint8_t* packetStart, uint8_t* packetLength);
    uint64_t     getLastGranulePosition();

    //+++ create a T A S K  for playAudioData(), output via I2S +++
public:
    void         setAudioTaskCore(uint8_t coreID);
    uint32_t     getHighWatermark();

private:
    void         startAudioTask(); // starts a task for decode and play
    void         stopAudioTask();  // stops task for audio
    static void  taskWrapper(void* param);
    void         audioTask();
    void         performAudioTask();
    uint8_t    m_audioTaskCoreId = 1;  // :If the ARDUINO RUNNING CORE is 1, the audio task should be core 0 or vice versa
    bool        m_f_audioTaskIsRunning = false;

    //+++ H E L P   F U N C T I O N S +++
    bool         readMetadata(uint16_t b, uint16_t *readedBytes, bool first = false);
    int32_t      getChunkSize(uint16_t *readedBytes, bool first = false);
    bool         readID3V1Tag();
    int32_t      newInBuffStart(int32_t m_resumeFilePos);
    boolean      streamDetection(uint32_t bytesAvail);
    uint32_t     m4a_correctResumeFilePos();
    uint32_t     ogg_correctResumeFilePos();
    int32_t      flac_correctResumeFilePos();
    int32_t      mp3_correctResumeFilePos();
    uint8_t      determineOggCodec(uint8_t* data, uint16_t len);

    //++++ implement several function with respect to the index of string ++++
    void strlower(char* str) {
        unsigned char* p = (unsigned char*)str;
        while(*p) {
            *p = tolower((unsigned char)*p);
            p++;
        }
    }

    void trim(char *str) {
        char *start = str;  // keep the original pointer
        char *end;
        while (isspace((unsigned char)*start)) start++; // find the first non-space character

        if (*start == 0) {  // all characters were spaces
            str[0] = '\0';  // return a empty string
            return;
        }

        end = start + strlen(start) - 1;  // find the end of the string

        while (end > start && isspace((unsigned char)*end)) end--;
        end[1] = '\0';  // Null-terminate the string after the last non-space character

        // Move the trimmed string to the beginning of the memory area
        memmove(str, start, strlen(start) + 1);  // +1 for '\0'
    }

    bool startsWith (const char* base, const char* str) {
    //fb
        char c;
        while ( (c = *str++) != '\0' )
          if (c != *base++) return false;
        return true;
    }

    bool endsWith(const char *base, const char *searchString) {
        int32_t slen = strlen(searchString);
        if(slen == 0) return false;
        const char *p = base + strlen(base);
    //  while(p > base && isspace(*p)) p--;  // rtrim
        p -= slen;
        if(p < base) return false;
        return (strncmp(p, searchString, slen) == 0);
    }

    int indexOf (const char* base, const char* str, int startIndex = 0) {
    //fbi
        const char *p = base;
        for (; startIndex > 0; startIndex--)
            if (*p++ == '\0') return -1;
        char* pos = strstr(p, str);
        if (pos == nullptr) return -1;
        return pos - base;
    }

    int indexOf (const char* base, char ch, int startIndex = 0) {
    //fb
        const char *p = base;
        for (; startIndex > 0; startIndex--)
            if (*p++ == '\0') return -1;
        char *pos = strchr(p, ch);
        if (pos == nullptr) return -1;
        return pos - base;
    }

    int lastIndexOf(const char* haystack, const char* needle) {
    //fb
        int nlen = strlen(needle);
        if (nlen == 0) return -1;
        const char *p = haystack - nlen + strlen(haystack);
        while (p >= haystack) {
          int i = 0;
          while (needle[i] == p[i])
            if (++i == nlen) return p - haystack;
          p--;
        }
        return -1;
    }

    int lastIndexOf(const char* haystack, const char needle) {
    //fb
        const char *p = strrchr(haystack, needle);
        return (p ? p - haystack : -1);
    }

    int specialIndexOf (uint8_t* base, const char* str, int baselen, bool exact = false){
        int result = 0;  // seek for str in buffer or in header up to baselen, not nullterninated
        if (strlen(str) > baselen) return -1; // if exact == true seekstr in buffer must have "\0" at the end
        for (int i = 0; i < baselen - strlen(str); i++){
            result = i;
            for (int j = 0; j < strlen(str) + exact; j++){
                if (*(base + i + j) != *(str + j)){
                    result = -1;
                    break;
                }
            }
            if (result >= 0) break;
        }
        return result;
    }

    // Find the last instance of Str in the buffer backwards and checks end-of-stream-bit
    int specialIndexOfLast(uint8_t* base, const char* str, int baselen) {
        int result = -1;
        if (strlen(str) > baselen) return -1; // too short buffer

        for (int i = baselen - strlen(str); i >= 0; i--) { // search backwards, start at the end of the buffer
            int match = 1;
            for (int j = 0; j < strlen(str); j++) {
                if (base[i + j] != str[j]) {
                    match = 0;
                    break;
                }
            }
            if(match) return i;
        }
        return result;
    }

    int find_utf16_null_terminator(const uint8_t* buf, int start, int max) {
        for (int i = start; i + 1 < max; i += 2) {
            if (buf[i] == 0x00 && buf[i + 1] == 0x00)
                return i; // Index to the first zero-byte
        }
        return -1; // not found
    }

    int32_t min3(int32_t a, int32_t b, int32_t c){
        uint32_t min_val = a;
        if (b < min_val) min_val = b;
        if (c < min_val) min_val = c;
        return min_val;
    }

    // some other functions
    uint64_t bigEndian(uint8_t* base, uint8_t numBytes, uint8_t shiftLeft = 8) {
        uint64_t result = 0;  // Use uint64_t for greater caching
        if(numBytes < 1 || numBytes > 8) return 0;
        for (int i = 0; i < numBytes; i++) {
            result |= (uint64_t)(*(base + i)) << ((numBytes - i - 1) * shiftLeft); //Make sure the calculation is done correctly
        }
        if(result > SIZE_MAX) {
            log_e("range overflow");
            return 0;
        }
        return result;
    }

    bool b64encode(const char* source, uint16_t sourceLength, char* dest){
        size_t size = base64_encode_expected_len(sourceLength) + 1;
        char * buffer = (char *) malloc(size);
        if(buffer) {
            base64_encodestate _state;
            base64_init_encodestate(&_state);
            int len = base64_encode_block(&source[0], sourceLength, &buffer[0], &_state);
            base64_encode_blockend((buffer + len), &_state);
            memcpy(dest, buffer, strlen(buffer));
            dest[strlen(buffer)] = '\0';
            free(buffer);
            return true;
        }
        return false;
    }

    void vector_clear_and_shrink(std::vector<ps_ptr<char>>& vec){
        for(int i = 0; i< vec.size(); i++) vec[i].reset();
        vec.clear();            // unique_ptr takes care of free()
        vec.shrink_to_fit();    // put back memory
    }

    void deque_clear_and_shrink(std::deque<ps_ptr<char>>& deq){
        for(int i = 0; i< deq.size(); i++) deq[i].reset();
        deq.clear();            // unique_ptr takes care of free()
        deq.shrink_to_fit();    // put back memory
    }

    uint32_t simpleHash(const char* str){
        if(str == NULL) return 0;
        uint32_t hash = 0;
        for(int i=0; i<strlen(str); i++){
		    if(str[i] < 32) continue; // ignore control sign
		    hash += (str[i] - 31) * i * 32;
        }
        return hash;
	  }

    ps_ptr<char> urlencode(const char* str, bool spacesOnly) {
        if (!str) {return {};}  // Enter is zero

        // Reserve memory for the result (3x the length of the input string, worst-case)
        size_t inputLength = strlen(str);
        size_t bufferSize = inputLength * 3 + 1; // Worst-case-Szenario
        ps_ptr<char>encoded;
        encoded.alloc(bufferSize);
        if (!encoded.valid()) {return {}; } // memory allocation failed

        const char *p_input = str;  // Copy of the input pointer
        char *p_encoded = encoded.get();  // pointer of the output buffer
        size_t remainingSpace = bufferSize; // remaining space in the output buffer

        while (*p_input) {
            if (isalnum((unsigned char)*p_input)) {
                // adopt alphanumeric characters directly
                if (remainingSpace > 1) {
                    *p_encoded++ = *p_input;
                    remainingSpace--;
                } else {
                    return {}; // security check failed
                }
            } else if (spacesOnly && *p_input != 0x20) {
                // Nur Leerzeichen nicht kodieren
                if (remainingSpace > 1) {
                    *p_encoded++ = *p_input;
                    remainingSpace--;
                } else {
                    return {}; // security check failed
                }
            } else {
                // encode unsafe characters as '%XX'
                if (remainingSpace > 3) {
                    int written = snprintf(p_encoded, remainingSpace, "%%%02X", (unsigned char)*p_input);
                    if (written < 0 || written >= (int)remainingSpace) {
                        return {}; // error writing to buffer
                    }
                    p_encoded += written;
                    remainingSpace -= written;
                } else {
                    return {}; // security check failed
                }
            }
            p_input++;
        }

        // Null-terminieren
        if (remainingSpace > 0) {
            *p_encoded = '\0';
        } else {
            return {}; // security check failed
        }
        encoded.shrink_to_fit();
        return encoded;
    }

// Function to reverse the byte order of a 32-bit value (big-endian to little-endian)
    uint32_t bswap32(uint32_t x) {
        return ((x & 0xFF000000) >> 24) |
               ((x & 0x00FF0000) >> 8)  |
               ((x & 0x0000FF00) << 8)  |
               ((x & 0x000000FF) << 24);
    }

// Function to reverse the byte order of a 64-bit value (big-endian to little-endian)
    uint64_t bswap64(uint64_t x) {
        return ((x & 0xFF00000000000000ULL) >> 56) |
               ((x & 0x00FF000000000000ULL) >> 40) |
               ((x & 0x0000FF0000000000ULL) >> 24) |
               ((x & 0x000000FF00000000ULL) >> 8)  |
               ((x & 0x00000000FF000000ULL) << 8)  |
               ((x & 0x0000000000FF0000ULL) << 24) |
               ((x & 0x000000000000FF00ULL) << 40) |
               ((x & 0x00000000000000FFULL) << 56);
    }

private:
    enum : int { APLL_AUTO = -1, APLL_ENABLE = 1, APLL_DISABLE = 0 };
    enum : int { FORMAT_NONE = 0, FORMAT_M3U = 1, FORMAT_PLS = 2, FORMAT_ASX = 3, FORMAT_M3U8 = 4}; // playlist formats
    const char* plsFmtStr[5] = {"NONE", "M3U", "PLS", "ASX", "M3U8"}; // playlist format string
    enum : int { AUDIO_NONE, HTTP_RESPONSE_HEADER, HTTP_RANGE_HEADER, AUDIO_DATA, AUDIO_LOCALFILE,
                 AUDIO_PLAYLISTINIT, AUDIO_PLAYLISTHEADER, AUDIO_PLAYLISTDATA};
    const char* dataModeStr[8] = {"AUDIO_NONE", "HTTP_RESPONSE_HEADER", "HTTP_RANGE_HEADER", "AUDIO_DATA", "AUDIO_LOCALFILE", "AUDIO_PLAYLISTINIT", "AUDIO_PLAYLISTHEADER", "AUDIO_PLAYLISTDATA" };
    enum : int { FLAC_BEGIN = 0, FLAC_MAGIC = 1, FLAC_MBH =2, FLAC_SINFO = 3, FLAC_PADDING = 4, FLAC_APP = 5,
                 FLAC_SEEK = 6, FLAC_VORBIS = 7, FLAC_CUESHEET = 8, FLAC_PICTURE = 9, FLAC_OKAY = 100};
    enum : int { M4A_BEGIN = 0, M4A_FTYP = 1, M4A_CHK = 2, M4A_MOOV = 3, M4A_FREE = 4, M4A_TRAK = 5, M4A_MDAT = 6,
                 M4A_ILST = 7, M4A_MP4A = 8, M4A_ESDS = 9, M4A_MDIA = 10, M4A_MINF = 11, M4A_STBL = 12, M4A_STSD = 13, M4A_UDTA = 14,
                 M4A_STSZ = 15, M4A_META = 16, M4A_MDHD = 17, M4A_AMRDY = 99, M4A_OKAY = 100};
    enum : int { CODEC_NONE = 0, CODEC_WAV = 1, CODEC_MP3 = 2, CODEC_AAC = 3, CODEC_M4A = 4, CODEC_FLAC = 5,
                 CODEC_AACP = 6, CODEC_OPUS = 7, CODEC_OGG = 8, CODEC_VORBIS = 9};
    const char *codecname[10] = {"unknown", "WAV", "MP3", "AAC", "M4A", "FLAC", "AACP", "OPUS", "OGG", "VORBIS" };
    enum : int { ST_NONE = 0, ST_WEBFILE = 1, ST_WEBSTREAM = 2};
    const char* streamTypeStr[3] = {"NONE", "WEBFILE", "WEBSTREAM"};

private:
    typedef struct _pis_array{
        int number;
        int pids[4];
    } pid_array;

    File                  m_audiofile;
    NetworkClient	      client;
    NetworkClientSecure	  clientsecure;
    NetworkClient*        m_client = nullptr;

    SemaphoreHandle_t     mutex_playAudioData;
    SemaphoreHandle_t     mutex_audioTask;
    TaskHandle_t          m_audioTaskHandle = nullptr;

//#pragma GCC diagnostic pop

    std::vector<ps_ptr<char>> m_playlistContent;        // m3u8 playlist buffer from responseHeader
    std::vector<ps_ptr<char>> m_playlistURL;            // m3u8 streamURLs buffer
    std::deque <ps_ptr<char>> m_linesWithURL;   // extract from m_playlistContent, contains URL and MediaSequenceNumber
    std::vector<ps_ptr<char>> m_linesWithEXTINF;        // extract from m_playlistContent, contains length and metadata
    std::vector<ps_ptr<char>> m_syltLines;              // SYLT line table
    std::vector<uint32_t>     m_syltTimeStamp;          // SYLT time table
    std::vector<uint32_t>     m_hashQueue;

    static const uint8_t m_tsPacketSize  = 188;
    static const uint8_t m_tsHeaderSize  = 4;

    ps_ptr<int16_t>  m_outBuff;                     // Interleaved L/R
//    ps_ptr<int16_t>  m_samplesBuff48K;              // Interleaved L/R
//    char*           m_chbuf = NULL;
//    ps_ptr<char>     m_ibuff;                       // used in log_info()
    ps_ptr<char>     m_lastHost;                    // Store the last URL to a webstream
    ps_ptr<char>     m_currentHost;                 // can be changed by redirection or playlist
    ps_ptr<char>     m_lastM3U8host;
    ps_ptr<char>     m_speechtxt;                   // stores tts text
    ps_ptr<char>     m_streamTitle;                 // stores the last StreamTitle
    ps_ptr<char>     m_playlistBuff;


//    filter_t        m_filter[3];                    // digital filters
    const uint16_t  m_plsBuffEntryLen = 256;        // length of each entry in playlistBuff
//    int             m_LFcount = 0;                  // Detection of end of header
    uint32_t        m_avr_bitrate = 0;              // average bitrate, median calculated by VBR
    uint32_t        m_nominal_bitrate = 0;          // given br from header
    uint32_t        m_audioFilePosition = 0;        // current position, counts every readed byte
    uint32_t        m_audioFileSize = 0;            // local and web files
    int             m_readbytes = 0;                // bytes read
    uint32_t        m_metacount = 0;                // counts down bytes between metadata
    int             m_controlCounter = 0;           // Status within readID3data() and readWaveHeader()
//    int16_t         m_inputHistory[6] = {0};        // used in resampleTo48kStereo()
//    uint16_t        m_opus_mode = 0;                // celt_only, silk_only or hybrid
    uint8_t         m_BitsPerSample = 16;           // bitsPerSample
    uint32_t       m_SampleRate;
    uint8_t         m_channels = 2;
    uint8_t         m_playlistFormat = 0;           // M3U, PLS, ASX
    uint8_t         m_codec = CODEC_NONE;           //
    uint8_t         m_m3u8Codec = CODEC_AAC;        // codec of m3u8 stream
    uint8_t         m_expectedCodec = CODEC_NONE;   // set in connecttohost (e.g. http://url.mp3 -> CODEC_MP3)
    uint8_t         m_expectedPlsFmt = FORMAT_NONE; // set in connecttohost (e.g. streaming01.m3u) -> FORMAT_M3U)
    uint8_t         m_streamType = ST_NONE;
    uint8_t         m_ID3Size = 0;                  // lengt of ID3frame - ID3header
    uint8_t         vuLeft = 0;                   // average value of samples, left channel
    uint8_t         vuRight = 0;                  // average value of samples, right channel
    uint8_t         m_M4A_objectType = 0;           // set in read_M4A_Header
    uint8_t         m_M4A_chConfig = 0;             // set in read_M4A_Header
    uint16_t        m_M4A_sampleRate = 0;           // set in read_M4A_Header
    int16_t         m_validSamples = {0};           // #144
    uint16_t        m_dataMode{0};                  // Statemaschine
    uint16_t        m_streamTitleHash = 0;          // remember streamtitle, ignore multiple occurence in metadata
    uint16_t        m_timeout_ms = 250;
    uint16_t        m_timeout_ms_ssl = 2700;
    uint32_t        m_metaint = 0;                  // Number of databytes between metadata
    uint32_t        m_chunkcount = 0 ;              // Counter for chunked transfer
    uint32_t        m_t0 = 0;                       // store millis(), is needed for a small delay
    uint32_t        m_bytesNotConsumed = 0;         // pictures or something else that comes with the stream
//    uint64_t        m_lastGranulePosition = 0;      // necessary to calculate the duration in OPUS and VORBIS
    uint32_t        m_PlayingStartTime = 0;         // Stores the milliseconds after the start of the audio
    int32_t         m_resumeFilePos = -1;           // the return value from stopSong(), (-1) is idle
//    int32_t         m_fileStartTime = -1;           // may be set in connecttoFS()
    int32_t         m_fileStartPos = -1;            // may be set in connecttoFS()
    uint16_t        m_m3u8_targetDuration = 10;     //
    uint32_t        m_stsz_numEntries = 0;          // num of entries inside stsz atom (uint32_t)
    uint32_t        m_stsz_position = 0;            // pos of stsz atom within file
    uint32_t        m_haveNewFilePos = 0;           // user changed the file position
    bool            m_f_metadata = false;           // assume stream without metadata
    bool            m_f_unsync = false;             // set within ID3 tag but not used
    bool            m_f_exthdr = false;             // ID3 extended header
    bool            m_f_ssl = false;
    bool            m_f_running = false;
    bool            m_f_firstCall = false;          // InitSequence for processWebstream and processLokalFile
    bool            m_f_firstCurTimeCall = false;   // InitSequence for calculateAudioTime()
    bool            m_f_firstPlayCall = false;      // InitSequence for playAudioData
    bool            m_f_firstM3U8call = false;      // InitSequence for m3u8 parsing
    bool            m_f_ID3v1TagFound = false;      // ID3v1 tag found
    bool            m_f_chunked = false ;           // Station provides chunked transfer
    bool            m_f_firstmetabyte = false;      // True if first metabyte (counter)
    bool            m_f_playing = false;            // valid mp3 stream recognized
    bool            m_f_tts = false;                // text to speech
    bool            m_f_ogg = false;                // OGG stream
    bool            m_f_forceMono = false;          // if true stereo -> mono
    bool            m_f_rtsp = false;               // set if RTSP is used (m3u8 stream)
    bool            m_f_m3u8data = false;           // used in processM3U8entries
    bool            m_f_continue = false;           // next m3u8 chunk is available
    bool            m_f_ts = true;                  // transport stream
    bool            m_f_m4aID3dataAreRead = false;  // has the m4a-ID3data already been read?
    bool            m_f_psramFound = false;         // set in constructor, result of psramInit()
    bool            m_f_timeout = false;            //
    bool            m_f_allDataReceived = false;
    bool            m_f_stream = false;             // stream ready for output?
    bool            m_f_decode_ready = false;       // if true data for decode are ready
    bool            m_f_eof = false;                // end of file
    bool            m_f_lockInBuffer = false;       // lock inBuffer for manipulation
    bool            m_f_audioTaskIsDecoding = false;
    bool            m_f_acceptRanges = false;
    bool            m_f_reset_m3u8Codec = true;     // reset codec for m3u8 stream
    bool            m_f_connectionClose = false;    // set in parseHttpResponseHeader
    uint32_t        m_audioFileDuration = 0;        // seconds
    uint32_t        m_audioCurrentTime = 0;         // seconds
//    bool            m_f_loop = false;               // Set if audio file should loop
    bool            m_f_Log = false;                // set in platformio.ini  -DAUDIO_LOG and -DCORE_DEBUG_LEVEL=3 or 4


    uint32_t        m_audioDataStart = 0;           // in bytes
    size_t          m_audioDataSize = 0;            //
    size_t          m_ibuffSize = 0;                // log buffer size for audio_info()

    uint8_t         m_endFillByte;                 // Byte to send when stopping song
//    bool            m_f_unknownFileLength = false;  // file length unknown
//    bool            m_f_clientIsConnected = false;  // client connected, inter task communication
    bool            m_f_ctseen=false;               // First line of header seen or not
    bool            m_f_webfile = false;
//	    bool            m_f_localfile = false;         // Play from local mp3-file		?
    bool            m_f_webstream = false;         // Play from URL
    bool            _vuInitalized = false;            // true if VUmeter is enabled

//***************************************************************************************
//int32_t  OGG_specialIndexOf(uint8_t* base, const char* str, int32_t baselen, bool exact = false);
//int32_t   VORBISFindSyncWord(unsigned char *buf, int32_t nBytes);
//int32_t  FLACFindSyncWord(unsigned char *buf, int32_t nBytes);
//int32_t  OPUSFindSyncWord(unsigned char *buf, int32_t nBytes);
int8_t    parseVorbisComment(uint8_t *inbuf, int16_t nBytes);
int8_t    parseFlacComment(uint8_t *inbuf, int16_t nBytes);
int8_t    parseOpusComment(uint8_t *inbuf, int32_t nBytes);
char*     VORBISgetStreamTitle();
char*     FLACgetStreamTitle();
char*     OPUSgetStreamTitle();
bool      s_f_vorbisNewSteamTitle = false;  			// VORBIS streamTitle
bool      s_f_flacNewStreamtitle = false;  			// FLAC streamTitle
bool      s_f_opusNewSteamTitle = false;  			// OPUS streamTitle
char*      s_vorbisChbuf = NULL;
char*      s_flacStreamTitle = NULL;
char*      s_opusSteamTitle = NULL;
//uint32_t FLACgetMetadataBlockPicture();
//uint32_t OPUSgetMetadataBlockPicture();
//uint32_t VORBISgetMetadataBlockPicture();
//    bool      read_M4A_Lirics(uint8_t *data, size_t len);
//    bool      read_FLAC_VORBIS_Lirics(uint8_t *data, size_t len);

//    uint16_t getDecodedTime();		 // Provides SCI_DECODE_TIME register value
//    void clearDecodedTime();		// Clears SCI_DECODE_TIME register (sets 0x00)
//    void enableI2sOut(VS1053_I2S_RATE i2sRate = VS1053_I2S_RATE_48_KHZ);	// enable I2S output (GPIO4=LRCLK/WSEL; GPIO5=MCLK; GPIO6=SCLK/BCLK; GPIO7=SDATA/DOUT)
//    void disableI2sOut();			// disable I2S output; this is the default state
//*****************************************************************************************

    // audiolib structs
    audiolib::ID3Hdr_t m_ID3Hdr;
    audiolib::pwsHLS_t m_pwsHLS;
    audiolib::pplM3u8_t m_pplM3U8;
    audiolib::m4aHdr_t m_m4aHdr;
    audiolib::plCh_t m_plCh;
    audiolib::lVar_t m_lVar;
    audiolib::prlf_t m_prlf;
    audiolib::cat_t m_cat;
    audiolib::cVUl_t m_cVUl;
    audiolib::ifCh_t m_ifCh;
    audiolib::tspp_t m_tspp;
    audiolib::pwst_t m_pwst;
    audiolib::gchs_t m_gchs;
    audiolib::pwf_t m_pwf;
    audiolib::pad_t m_pad;
    audiolib::sbyt_t m_sbyt;
    audiolib::rmet_t m_rmet;
    audiolib::pwsts_t m_pwsst;
    audiolib::rwh_t m_rwh;
    audiolib::rflh_t m_rflh;
    audiolib::phreh_t m_phreh;
    audiolib::phrah_t m_phrah;
    audiolib::sdet_t m_sdet;
    audiolib::fnsy_t m_fnsy;


//----------------------------------------------------------------------------------------------------------------------
/*    template <typename... Args>
    void AUDIO_LOG_IMPL(uint8_t level, const char* path, int line, const char* fmt, Args&&... args) {

        #define ANSI_ESC_RESET          "\033[0m"
//        #define ANSI_ESC_BLACK          "\033[30m"
        #define ANSI_ESC_RED            "\033[31m"
        #define ANSI_ESC_GREEN          "\033[32m"
        #define ANSI_ESC_YELLOW         "\033[33m"
//        #define ANSI_ESC_BLUE           "\033[34m"
//        #define ANSI_ESC_MAGENTA        "\033[35m"
        #define ANSI_ESC_CYAN           "\033[36m"
        #define ANSI_ESC_WHITE          "\033[37m"

        ps_ptr<char> result(__LINE__);
        ps_ptr<char> file(__LINE__);

        file.copy_from(path);
        while(file.contains("/")){
            file.remove_before('/', false);
        }

        // First run: determine size
        int len = std::snprintf(nullptr, 0, fmt, std::forward<Args>(args)...);
        if (len <= 0) return;

        result.alloc(len + 1);
        char* dst = result.get();
        if (!dst) return;
        std::snprintf(dst, len + 1, fmt, std::forward<Args>(args)...);

        // build a final string with file/line prefix
        ps_ptr<char> final(__LINE__);
        int total_len = std::snprintf(nullptr, 0, "%s:%d:" ANSI_ESC_RED " %s" ANSI_ESC_RESET, file.c_get(), line, dst);
        if (total_len <= 0) return;
        final.alloc(total_len + 1);
        final.clear();
        char* dest = final.get();
        if (!dest) return;  // or error treatment
        if(audio_info_callback){
            if     (level == 1 && CORE_DEBUG_LEVEL >= 1) snprintf(dest, total_len + 1, "%s:%d:" ANSI_ESC_RED " %s" ANSI_ESC_RESET, file.c_get(), line, dst);
            else if(level == 2 && CORE_DEBUG_LEVEL >= 2) snprintf(dest, total_len + 1, "%s:%d:" ANSI_ESC_YELLOW " %s" ANSI_ESC_RESET, file.c_get(), line, dst);
            else if(level == 3 && CORE_DEBUG_LEVEL >= 3) snprintf(dest, total_len + 1, "%s:%d:" ANSI_ESC_GREEN " %s" ANSI_ESC_RESET, file.c_get(), line, dst);
            else if(level == 4 && CORE_DEBUG_LEVEL >= 4) snprintf(dest, total_len + 1, "%s:%d:" ANSI_ESC_CYAN " %s" ANSI_ESC_RESET, file.c_get(), line, dst);  // debug
            else              if( CORE_DEBUG_LEVEL >= 5) snprintf(dest, total_len + 1, "%s:%d:" ANSI_ESC_WHITE " %s" ANSI_ESC_RESET, file.c_get(), line, dst); // verbose
            msg_t msg;
            msg.msg = final.get();
            const char* logStr[7] ={"", "LOGE", "LOGW", "LOGI", "LOGD", "LOGV", ""};
            msg.s = logStr[level];
            msg.e = evt_log;
            if(final.strlen() > 0)  audio_info_callback(msg);
        }
        else{
            std::snprintf(dest, total_len + 1, "%s:%d: %s", file.c_get(), line, dst);
            if     (level == 1) log_e("%s", final.c_get());
            else if(level == 2) log_w("%s", final.c_get());
            else if(level == 3) log_i("%s", final.c_get());
            else if(level == 4) log_d("%s", final.c_get());
            else                log_v("%s", final.c_get());
        }
        final.reset();
        result.reset();
        file.reset();
    }

    // Macro for comfortable calls
    #define AUDIO_LOG_ERROR(fmt, ...) AUDIO_LOG_IMPL(1, __FILE__, __LINE__, fmt, ##__VA_ARGS__)
//    #define AUDIO_LOG_WARN(fmt, ...)  AUDIO_LOG_IMPL(2, __FILE__, __LINE__, fmt, ##__VA_ARGS__)
    #define AUDIO_LOG_INFO(fmt, ...)  AUDIO_LOG_IMPL(3, __FILE__, __LINE__, fmt, ##__VA_ARGS__)
//    #define AUDIO_LOG_DEBUG(fmt, ...) AUDIO_LOG_IMPL(4, __FILE__, __LINE__, fmt, ##__VA_ARGS__)
*/

};



#endif	// #ifndef _vs1053_ext
#endif	// #if VS1053_CS!=255

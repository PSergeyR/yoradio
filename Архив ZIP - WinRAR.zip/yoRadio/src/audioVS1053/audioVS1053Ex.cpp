
/*****************************************************************************************
   vs1053_ext.cpp

   Created on: Jul 09.2017 
   Version 3.4.2p   Updated on: Sep 15.2025 (Maleksm)
   Author: Wolle (Dec 15.2023), easy
 ****************************************************************************************/
#include "../core/options.h"

#if I2S_DOUT==255
#include "../core/config.h"
#include "audioVS1053Ex.h"
//#include "../audioI2S/aac_decoder/aac_decoder.h"
#include "../audioI2S/flac_decoder/flac_decoder.h"
#include "../audioI2S/mp3_decoder/mp3_decoder.h"
//#include "../audioI2S/opus_decoder/opus_decoder.h"
#include "../audioI2S/vorbis_decoder/vorbis_decoder.h"
#include "../audioI2S/psram_unique_ptr.hpp"

/*#ifndef DMA_BUFCOUNT
  #define DMA_BUFCOUNT  16
#endif
#ifndef DMA_BUFLEN
  #define DMA_BUFLEN  512   //  (512)
#endif	*/

#ifndef VS_PATCH_ENABLE
  #define VS_PATCH_ENABLE  true
#endif

// constants
constexpr size_t    m_frameSizeWav       = 4096;
constexpr size_t    m_frameSizeMP3       = 1600 * 2;
constexpr size_t    m_frameSizeAAC       = 1600;
constexpr size_t    m_frameSizeFLAC      = 4096 * 6; // 24576
constexpr size_t    m_frameSizeOPUS      = 2048;
constexpr size_t    m_frameSizeVORBIS    = 4096 * 2;
constexpr size_t    m_outbuffSize        = 4096 * 2;

constexpr size_t    AUDIO_STACK_SIZE     = 3300;

// static allocations for Audio task
StaticTask_t __attribute__((unused)) xAudioTaskBuffer;
StackType_t  __attribute__((unused)) xAudioStack[AUDIO_STACK_SIZE];

template <typename... Args>
void AUDIO_INFO(const char* fmt, Args&&... args) {
//    if(!audio_info) return;
    ps_ptr<char> result(__LINE__);
    // First run: determine size
    int len = std::snprintf(nullptr, 0, fmt, std::forward<Args>(args)...);
    if (len <= 0) return;
    result.calloc(len + 1);
//    result.clear();
    char* p = result.get();
    if(!p) return;
    std::snprintf(p, len + 1, fmt, std::forward<Args>(args)...);
    audio_info(result.c_get());
    result.reset();
}
template <typename... Args>
void AUDIO_ERROR(const char* fmt, Args&&... args) {
//    if(!audio_info) return;
    ps_ptr<char> result(__LINE__);
    // First run: determine size
    int len = std::snprintf(nullptr, 0, fmt, std::forward<Args>(args)...);
    if (len <= 0) return;
    result.calloc(len + 1);
//    result.clear();
    char* p = result.get();
    if(!p) return;
    std::snprintf(p, len + 1, fmt, std::forward<Args>(args)...);
    audio_error(result.c_get());
    result.reset();
}
//###################################################################
AudioBuffer::AudioBuffer(size_t maxBlockSize) {
    if(maxBlockSize) m_resBuffSize = maxBlockSize;
    if(maxBlockSize) m_maxBlockSize = maxBlockSize;
}

AudioBuffer::~AudioBuffer() {
    // m_buffer.reset();
}

int32_t AudioBuffer::getBufsize() { return m_buffSize; }

bool AudioBuffer::setBufsize(size_t mbs) {
    if(mbs < 2 * m_resBuffSize) {
//        AUDIO_ERROR("not allowed buffer size must be greater than %i", 2 * m_resBuffSize);
        return false;
    }
    m_buffSize = mbs;
    if(!init()) return false;
    return true;
}

size_t AudioBuffer::init() {
    m_buffer.alloc(m_buffSize + m_resBuffSize, "AudioBuffer");
    m_f_init = true;
    resetBuffer();
    return m_buffSize;
}

void AudioBuffer::changeMaxBlockSize(uint16_t mbs) {
    m_maxBlockSize = mbs;
    return;
}

uint16_t AudioBuffer::getMaxBlockSize() { return m_maxBlockSize; }

size_t AudioBuffer::freeSpace() {
    if(m_readPtr == m_writePtr) {
        if(m_f_isEmpty == true) m_freeSpace = m_buffSize;
        else m_freeSpace = 0;
    }
    if(m_readPtr < m_writePtr) {
        m_freeSpace = (m_endPtr - m_writePtr) + (m_readPtr - m_buffer.get());
    }
    if(m_readPtr > m_writePtr) {
        m_freeSpace = m_readPtr - m_writePtr;
    }
    return m_freeSpace;
}

size_t AudioBuffer::writeSpace() {
    if(m_readPtr == m_writePtr) {
        if(m_f_isEmpty == true) m_writeSpace = m_endPtr - m_writePtr;
        else m_writeSpace = 0;
    }
    if(m_readPtr < m_writePtr) {
        m_writeSpace = m_endPtr - m_writePtr;
    }
    if(m_readPtr > m_writePtr) {
        m_writeSpace = m_readPtr - m_writePtr;
    }
    return m_writeSpace;
}

size_t AudioBuffer::bufferFilled() {
    if(m_readPtr == m_writePtr) {
        if(m_f_isEmpty == true) m_dataLength = 0;
        else m_dataLength = m_buffSize;
    }
    if(m_readPtr < m_writePtr) {
        m_dataLength = m_writePtr - m_readPtr;
    }
    if(m_readPtr > m_writePtr) {
        m_dataLength = (m_endPtr - m_readPtr) + (m_writePtr - m_buffer.get());
    }
    return m_dataLength;
}

size_t AudioBuffer::getMaxAvailableBytes() {
    if(m_readPtr == m_writePtr) {
    //   if(m_f_start)m_dataLength = 0;
        if(m_f_isEmpty == true) m_dataLength = 0;
        else m_dataLength = (m_endPtr - m_readPtr);
    }
    if(m_readPtr < m_writePtr) {
        m_dataLength = m_writePtr - m_readPtr;
    }
    if(m_readPtr > m_writePtr) {
        m_dataLength = (m_endPtr - m_readPtr);
    }
    return m_dataLength;
}

void AudioBuffer::bytesWritten(size_t bw) {
    if(!bw) return;
    m_writePtr += bw;
    if(m_writePtr == m_endPtr) { m_writePtr = m_buffer.get(); }
//    if(m_writePtr > m_endPtr) AUDIO_ERROR("AudioBuffer: m_writePtr %i > m_endPtr %i", m_writePtr, m_endPtr);
    m_f_isEmpty = false;
}

void AudioBuffer::bytesWasRead(size_t br) {
    if(!br) return;
    m_readPtr += br;
    if(m_readPtr >= m_endPtr) {
        size_t tmp = m_readPtr - m_endPtr;
        m_readPtr = m_buffer.get() + tmp;
    }
    if(m_readPtr == m_writePtr) m_f_isEmpty = true;
}

uint8_t* AudioBuffer::getWritePtr() { return m_writePtr; }

uint8_t* AudioBuffer::getReadPtr() {
    int32_t len = m_endPtr - m_readPtr;
    if(len < m_maxBlockSize) {                            // be sure the last frame is completed
        memcpy(m_endPtr, m_buffer.get(), m_maxBlockSize - (len)); // cpy from m_buffer to m_endPtr with len
    }
    return m_readPtr;
}

void AudioBuffer::resetBuffer() {
    m_writePtr = m_buffer.get();
    m_readPtr = m_buffer.get();
    m_endPtr = m_buffer.get() + m_buffSize;
    m_f_isEmpty = true;
}

uint32_t AudioBuffer::getWritePos() { return m_writePtr - m_buffer.get(); }

uint32_t AudioBuffer::getReadPos() { return m_readPtr - m_buffer.get(); }
//###################################################################
// **** VS1053 Impl ****
//###################################################################
Audio::Audio(uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, SPIClass *spi) :
        cs_pin(_cs_pin), dcs_pin(_dcs_pin), dreq_pin(_dreq_pin) {				// easy
//Audio::Audio(uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, uint8_t spi, uint8_t mosi, uint8_t miso, uint8_t sclk) :    cs_pin(_cs_pin), dcs_pin(_dcs_pin), dreq_pin(_dreq_pin) {					// Wolle
//Audio::Audio(uint8_t _cs_pin, uint8_t _dcs_pin, uint8_t _dreq_pin, uint8_t spi, uint8_t mosi, uint8_t miso, uint8_t sclk){

    cs_pin   = _cs_pin;
    dcs_pin  = _dcs_pin;
    dreq_pin = _dreq_pin;
//    mosi_pin = mosi;
//    miso_pin  = miso;
//    sclk_pin   = sclk;

    mutex_playAudioData = xSemaphoreCreateMutex();
    mutex_audioTask     = xSemaphoreCreateMutex();

    if(!psramFound()) AUDIO_ERROR("audioI2S requires PSRAM!");

#ifdef AUDIO_LOG
    m_f_Log = true;
#endif

//    spi_VS1053 = new SPIClass(spi);								// Wolle
    spi_VS1053 = spi; 											// easy
//    spi_VS1053->begin(sclk, miso, mosi, -1);							// Wolle
    spi_VS1053->begin(); 										// easy

    m_f_psramFound = psramInit();

    m_outBuff.alloc(m_outbuffSize * sizeof(int16_t), "m_outBuff");

    esp_err_t result = ESP_OK;

#if(ESP_ARDUINO_VERSION_MAJOR < 3)
    log_e("Arduino Version too old!");
#endif

    clientsecure.setInsecure();                 // update to ESP32 Arduino version 1.0.5-rc05 or higher
    m_endFillByte=0;
//    curvol=50;
//    m_LFcount=0;

    startAudioTask();
}
//---------------------------------------------------------------------------------------------------------------------
Audio::~Audio(){
//    stopSong();
    setDefaults();

    stopAudioTask();
    vSemaphoreDelete(mutex_playAudioData);
    vSemaphoreDelete(mutex_audioTask);
}
//----------------------------------------------------------------------------------------------------------------------
// clang-format on
/*template <typename... Args>
void Audio::info(event_t e, const char* fmt, Args&&... args) {
    auto extract_last_number = [&](std::string_view s) -> int32_t {
        auto it = s.end(); // search from back to the front
        while (it != s.begin()) {
            --it;
            if (std::isdigit(static_cast<unsigned char>(*it))) {
                auto end = it + 1;  // end of the number found
                while (it != s.begin() && std::isdigit(static_cast<unsigned char>(*(it - 1)))) --it;   // go back to the beginning of the number
                std::string_view number{it, static_cast<size_t>(end - it)};
                uint32_t value{};
                auto [p, ec] = std::from_chars(number.data(), number.data() + number.size(), value);
                if (ec == std::errc{}) return static_cast<int32_t>(value); // break if errc is invalid_argument or esult_out_of_range
                break;
            }
        }
        return -1; // no number found
    };

    if(!audio_info_callback) return;
    ps_ptr<char> result(__LINE__);
    // First run: determine size
    int len = std::snprintf(nullptr, 0, fmt, std::forward<Args>(args)...);
    if (len <= 0) return;
    result.calloc(len + 1);
    char* p = result.get();
    if(!p) return;
    std::snprintf(p, len + 1, fmt, std::forward<Args>(args)...);
    msg_t i = {0};
    i.msg = result.c_get();
    i.e = e;
    i.s = eventStr[e];
    i.arg1 = extract_last_number(result.c_get());
    i.i2s_num = m_i2s_num;
    audio_info_callback(i);
    result.reset();
}
void Audio::info(event_t e, std::vector<uint32_t>& v) {
    if(!audio_info_callback) return;
    ps_ptr<char>apic;
    apic.assignf("APIC found at pos %lu", v[0]);
    msg_t i;
    i.msg = apic.c_get();
    i.e = e;
    i.s = eventStr[e];
    i.i2s_num = m_i2s_num;
    i.vec = v;
    audio_info_callback(i);
}*/
//###################################################################
void Audio::initInBuff() {
    if(!InBuff.isInitialized()) {
        size_t size = InBuff.init();
        if(size > 0) {
            AUDIO_INFO("inputBufferSize: %u bytes", size - 1);
        }
    }
    InBuff.changeMaxBlockSize(1600); // default size mp3 or aac
//    InBuff.changeMaxBlockSize(4096);
}
//---------------------------------------------------------------------------------------------------------------------
void Audio::control_mode_off(){
    CS_HIGH();                                     // End control mode
    spi_VS1053->endTransaction();                  // Allow other SPI users
}
void Audio::control_mode_on(){
    spi_VS1053->beginTransaction(VS1053_SPI_CTL);   // Prevent other SPI users
    DCS_HIGH();                                     // Bring slave in control mode
    CS_LOW();
}
void Audio::data_mode_on(){
    spi_VS1053->beginTransaction(VS1053_SPI_DATA);  // Prevent other SPI users
    CS_HIGH();                                      // Bring slave in data mode
    DCS_LOW();
}
void Audio::data_mode_off(){
    DCS_HIGH();
    spi_VS1053->endTransaction();                       // Allow other SPI users
}
//---------------------------------------------------------------------------------------------------------------------
uint16_t Audio::read_register(uint8_t _reg){
    uint16_t result=0;
    control_mode_on();
    spi_VS1053->write(3);                                           // Read operation
    spi_VS1053->write(_reg);                                        // Register to write (0..0xF)
    // Note: transfer16 does not seem to work
    result=(spi_VS1053->transfer(0xFF) << 8) | (spi_VS1053->transfer(0xFF));  // Read 16 bits data
    await_data_request();                                   // Wait for DREQ to be HIGH again
    control_mode_off();
    return result;
}
//---------------------------------------------------------------------------------------------------------------------
void Audio::write_register(uint8_t _reg, uint16_t _value){
    control_mode_on();
    spi_VS1053->write(2);                                           // Write operation
    spi_VS1053->write(_reg);                                        // Register to write (0..0xF)
    spi_VS1053->write16(_value);                                    // Send 16 bits data
    await_data_request();
    control_mode_off();
}
//###################################################################
void Audio::sdi_send_buffer(uint8_t* data, size_t len) {
    size_t chunk_length;                                    // Length of chunk 32 byte or shorter

    data_mode_on();
    while(len){                                             // More to do?

        await_data_request();                               // Wait for space available
        chunk_length=len;
        if(len > vs1053_chunk_size){
            chunk_length=vs1053_chunk_size;
        }
        len-=chunk_length;
        spi_VS1053->writeBytes(data, chunk_length);
        data+=chunk_length;
    }
    data_mode_off();
}
//---------------------------------------------------------------------------------------------------------------------
void Audio::sdi_send_fillers(size_t len){

    size_t chunk_length = 0;                                    // Length of chunk 32 byte or shorter

    data_mode_on();
    while(len) {                                             // More to do?
        await_data_request();                               // Wait for space available
//        if(len > 0){ chunk_length = min((size_t)vs1053_chunk_size, len);  }
        chunk_length=len;
        if(len > vs1053_chunk_size){chunk_length=vs1053_chunk_size;}
        len -= chunk_length;
        while(chunk_length--){ spi_VS1053->write(m_endFillByte); }
    }
    data_mode_off();
}
//---------------------------------------------------------------------------------------------------------------------
void Audio::wram_write(uint16_t address, uint16_t data){

    write_register(SCI_WRAMADDR, address);
    write_register(SCI_WRAM, data);
}
//---------------------------------------------------------------------------------------------------------------------
uint16_t Audio::wram_read(uint16_t address){

    write_register(SCI_WRAMADDR, address);                  // Start reading from WRAM
    return read_register(SCI_WRAM);                         // Read back result
}
//###################################################################
void Audio::begin(){

    pinMode(dreq_pin, INPUT);                               // DREQ is an input
    pinMode(cs_pin, OUTPUT);                                // The SCI and SDI signals
    pinMode(dcs_pin, OUTPUT);
    DCS_HIGH();
    CS_HIGH();
    delay(170);

    // Init SPI in slow mode ( 0.2 MHz )
    VS1053_SPI_CTL   = SPISettings( 200000, MSBFIRST, SPI_MODE0);
//    VS1053_SPI_DATA  = SPISettings(8000000, MSBFIRST, SPI_MODE0); // SPIDIV 10 -> 80/10=8.00 MHz	//800000
    VS1053_SPI_DATA  = SPISettings(6700000, MSBFIRST, SPI_MODE0); // SPIDIV 10 -> 80/10=8.00 MHz	//800000
    delay(20);
//    VS1053_SPI._clock    = 200000;
//    VS1053_SPI._bitOrder = MSBFIRST;
//    VS1053_SPI._dataMode = SPI_MODE0;
    // printDetails("Right after reset/startup");

    // Most VS1053 modules will start up in midi mode.  The result is that there is no audio
    // when playing MP3.  You can modify the board, but there is a more elegant way:
    wram_write(0xC017, 3);                                  // GPIO DDR=3
    wram_write(0xC019, 0);                                  // GPIO ODATA=0
    // printDetails("After test loop");
// - - - - - - - - - - - - - - - - - - - - - - // Do a soft reset - - - - - - - - - - - - - - - - - - - - - - - - -
    //softReset();                                            // Do a soft reset
    write_register(SCI_MODE, _BV (SM_SDINEW) | _BV(SM_RESET));
    delay(100);
    await_data_request();
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Switch on the analog parts
    write_register(SCI_AUDATA, 44100 + 1);                  // 44.1kHz + stereo
    // The next clocksetting allows SPI clocking at 5 MHz, 4 MHz is safe then.
    write_register(SCI_CLOCKF, 6 << 12);                    // Normal clock settings multiplyer 3.0=12.2 MHz
//	    VS1053_SPI = SPISettings(6700000, MSBFIRST, SPI_MODE0); // SPIDIV 12 -> 80/12=6.66 MHz
    write_register(SCI_MODE, _BV(SM_SDINEW) | _BV(SM_LINE1));
    await_data_request();
 
    m_endFillByte = wram_read(0x1E06) & 0xFF;
    //  printDetails("After last clocksetting \n");

    if(VS_PATCH_ENABLE) loadUserCode(); // load patch in VS1053B if you want to play flac
    setVUmeter();

    startAudioTask();
    startSong();
}
//###################################################################
/*//void Audio::softReset()
//{
//    write_register(SCI_MODE, _BV (SM_SDINEW) | _BV(SM_RESET));
//    delay(100);
//    await_data_request();
//}
*/
//###################################################################
void Audio::setVUmeter() {

// * brief enable VSdsp VU Meter
// * param[in] enable when set will enable the VU meter
// * Writes the SS_VU_ENABLE bit of the SCI_STATUS register to enable VU meter on
// * board to the VSdsp.
// *
// * See data patches data sheet VU meter for details.
// * warning This feature is only available with patches that support VU meter.
// * n The VU meter takes about 0.2MHz of processing power with 48 kHz samplerate.

  if(!VS_PATCH_ENABLE) return;
  uint16_t VSstatus = read_register(SCI_STATUS);
  if(VSstatus==0) {
    Serial.println("VS1053 Error: Unable to write SCI_STATUS");
    _vuInitalized = false;
    return;
  }
  _vuInitalized = true;
  Serial.print("VS1053 status: OK! \t");
  write_register(SCI_STATUS, VSstatus | _BV(9));
}
//###################################################################
void Audio::loadUserCode(void) {
  int i = 0;

  while (i<sizeof(flac_plugin)/sizeof(flac_plugin[0])) {
    unsigned short addr, n, val;
    addr = flac_plugin[i++];
    n = flac_plugin[i++];
    if (n & 0x8000U) { /* RLE run, replicate n samples */
      n &= 0x7FFF;
      val = flac_plugin[i++];
      while (n--) {
        write_register(addr, val);
      }
    } else {           /* Copy run, copy n samples */
      while (n--) {
        val = flac_plugin[i++];
        write_register(addr, val);
      }
    }
  }
}
//###################################################################
void Audio::setDefaults() {
    stopSong();
    initInBuff(); // initialize InputBuffer if not already done
    InBuff.resetBuffer();
    MP3Decoder_FreeBuffers();
    FLACDecoder_FreeBuffers();
//    AACDecoder_FreeBuffers();
//    OPUSDecoder_FreeBuffers();
    VORBISDecoder_FreeBuffers();
    m_outBuff.clear(); // Clear OutputBuffer
    vector_clear_and_shrink(m_playlistURL);
    vector_clear_and_shrink(m_playlistContent);
    vector_clear_and_shrink(m_syltLines);
    m_syltTimeStamp.clear();
    m_hashQueue.clear();
    m_hashQueue.shrink_to_fit(); // uint32_t vector
    client.stop();
    clientsecure.stop();
    m_client = static_cast<NetworkClient*>(&client); /* default to *something* so that no NULL deref can happen */
    ts_parsePacket(0, 0, 0);                     // reset ts routine
    m_lastM3U8host.reset();

    /*AUDIO_LOG_DEBUG*/AUDIO_INFO("buffers freed, free Heap: %lu bytes", (long unsigned int)ESP.getFreeHeap());

    m_f_timeout = false;
    m_f_chunked = false; // Assume not chunked
    m_f_firstmetabyte = false;
    m_f_playing = false;
//    m_f_ssl = false;
    m_f_metadata = false;
    m_f_tts = false;
    m_f_firstCall = true;        // InitSequence for processWebstream and processLocalFile
    m_f_firstCurTimeCall = true; // InitSequence for calculateAudioTime()
    m_f_firstM3U8call = true;    // InitSequence for parsePlaylist_M3U8
    m_f_firstPlayCall = true;    // InitSequence for playAudioData
//    m_f_running = false;       // already done in stopSong
    m_f_unsync = false;   // set within ID3 tag but not used
    m_f_exthdr = false;   // ID3 extended header
    m_f_rtsp = false;     // RTSP (m3u8)stream
    m_f_m3u8data = false; // set again in processM3U8entries() if necessary
    m_f_continue = false;
    m_f_ts = false;
    m_f_ogg = false;
    m_f_m4aID3dataAreRead = false;
    m_f_stream = false;
    m_f_decode_ready = false;
    m_f_eof = false;
    m_f_ID3v1TagFound = false;
    m_f_lockInBuffer = false;
    m_f_acceptRanges = false;
    m_f_connectionClose = false;

    m_streamType = ST_NONE;
    m_codec = CODEC_NONE;
    m_playlistFormat = FORMAT_NONE;
    m_dataMode = AUDIO_NONE;
    m_streamTitle.assign("");
    m_resumeFilePos = -1;
    m_audioCurrentTime = 0; // Reset playtimer
    m_audioFileDuration = 0;
    m_audioDataStart = 0;
    m_audioDataSize = 0;
    m_audioFileSize = 0;
    m_avr_bitrate = 0;
    m_nominal_bitrate = 0;
    m_bytesNotConsumed = 0; // counts all not decodable bytes
    m_chunkcount = 0;      // for chunked streams
//    m_curSample = 0;
    m_metaint = 0;        // No metaint yet
//    m_LFcount = 0;        // For end of header detection
    m_controlCounter = 0; // Status within readID3data() and readWaveHeader()
    m_channels = 2;       // assume stereo #209
    m_ID3Size = 0;
    m_haveNewFilePos = 0;
    m_validSamples = 0;
    m_M4A_chConfig = 0;
    m_M4A_objectType = 0;
    m_M4A_sampleRate = 0;
//    m_opus_mode = 0;
//    m_lastGranulePosition = 0;
    vuLeft = vuRight = 0; 		// #835
//    std::fill(std::begin(m_inputHistory), std::end(m_inputHistory), 0);
    if(m_f_reset_m3u8Codec){m_m3u8Codec = CODEC_AAC;} // reset to default
    m_f_reset_m3u8Codec = true;
}

//##################################################################
void Audio::setConnectionTimeout(uint16_t timeout_ms, uint16_t timeout_ms_ssl) {
    if(timeout_ms) m_timeout_ms = timeout_ms;
    if(timeout_ms_ssl) m_timeout_ms_ssl = timeout_ms_ssl;
}
//##################################################################
/*
    Text to speech API provides a speech endpoint based on our TTS (text-to-speech) model.
    More info: https://platform.openai.com/docs/guides/text-to-speech/text-to-speech

    Request body:
    model (string) [Required] - One of the available TTS models: tts-1 or tts-1-hd
    input (string) [Required] - The text to generate audio for. The maximum length is 4096 characters.
    instructions (string) [Optional] - A description of the desired characteristics of the generated audio.
    voice (string) [Required] - The voice to use when generating the audio. Supported voices are alloy, echo, fable, onyx, nova, and shimmer.
    response_format (string) [Optional] - Defaults to mp3. The format to audio in. Supported formats are mp3, opus, aac, and flac.
    speed (number) [Optional] - Defaults to 1. The speed of the generated audio. Select a value from 0.25 to 4.0. 1.0 is the default.

    Usage: audio.openai_speech(OPENAI_API_KEY, "tts-1", input, instructions, "shimmer", "mp3", "1");
*/
bool Audio::openai_speech(const String& api_key, const String& model, const String& input, const String& instructions, const String& voice, const String& response_format, const String& speed) {
    ps_ptr<char> host(__LINE__);
    host.assign("api.openai.com");
    char path[] = "/v1/audio/speech";

    if (input == "") {
        /*AUDIO_LOG_WARN*/AUDIO_ERROR("input text is empty");
        stopSong();
        return false;
    }
    xSemaphoreTakeRecursive(mutex_playAudioData, 0.3 * configTICK_RATE_HZ);

    setDefaults();
    m_f_ssl = true;

    m_speechtxt.assign(input.c_str());

    // Escape special characters in input
    String input_clean = "";
    for (int i = 0; i < input.length(); i++) {
        char c = input.charAt(i);
        if (c == '\"') {
            input_clean += "\\\"";
        } else if (c == '\n') {
            input_clean += "\\n";
        } else if (c == '\r') {
            input_clean += "\\r";
        } else if (c == '\t') {
            input_clean += "\\t";
        } else if (c == '\\') {
            input_clean += "\\\\";
        } else if (c == '\b') {
            input_clean += "\\b";
        } else if (c == '\f') {
            input_clean += "\\f";
        } else {
            input_clean += c;
        }
    }

    // Escape special characters in instructions
    String instructions_clean = "";
    for (int i = 0; i < instructions.length(); i++) {
        char c = instructions.charAt(i);
        if (c == '\"') {
            instructions_clean += "\\\"";
        } else if (c == '\n') {
            instructions_clean += "\\n";
        } else if (c == '\r') {
            instructions_clean += "\\r";
        } else if (c == '\t') {
            instructions_clean += "\\t";
        } else if (c == '\\') {
            instructions_clean += "\\\\";
        } else if (c == '\b') {
            instructions_clean += "\\b";
        } else if (c == '\f') {
            instructions_clean += "\\f";
        } else {
            instructions_clean += c;
        }
    }

    String post_body = "{"
        "\"model\": \"" + model + "\"," +
        "\"stream\": true," +       // add
        "\"input\": \"" + input_clean + "\"," +
        "\"instructions\": \"" + instructions_clean + "\"," +
        "\"voice\": \"" + voice + "\"," +
        "\"response_format\": \"" + response_format + "\"," +
        "\"speed\": " + speed +
    "}";

    String http_request =
    //  "POST " + String(path) + " HTTP/1.0\r\n" // UNKNOWN ERROR CODE (0050) - crashing on HTTP/1.1 need to use HTTP/1.0
        "POST " + String(path) + " HTTP/1.1\r\n"
        + "Host: " + host.get() + "\r\n"
        + "Authorization: Bearer " + api_key + "\r\n"
        + "Accept-Encoding: identity;q=1,*;q=0\r\n"
        + "User-Agent: nArija/1.0\r\n"
        + "Content-Type: application/json; charset=utf-8\r\n"
        + "Content-Length: " + post_body.length() + "\r\n"
    //  + "Connection: close\r\n" + "\r\n"
        + "\r\n"
        + post_body + "\r\n"
    ;

    bool res = true;
    int port = 443;
    m_client = static_cast<NetworkClientSecure*>(&clientsecure);

    uint32_t t = millis();
    AUDIO_INFO("Connect to: \"%s\"", host.get());
    res = m_client->connect(host.get(), port, m_timeout_ms_ssl);
    if (res) {
        uint32_t dt = millis() - t;
        m_lastHost.assign(host.get());
        m_currentHost.clone_from(host);
        AUDIO_INFO("%s has been established in %lu ms", m_f_ssl ? "SSL" : "Connection", (long unsigned int)dt);
        m_f_running = true;
    }

    m_expectedCodec = CODEC_NONE;
    m_expectedPlsFmt = FORMAT_NONE;

    if (res) {
        m_client->print(http_request);
        if (response_format == "mp3") m_expectedCodec  = CODEC_MP3;
        if (response_format == "opus") m_expectedCodec  = CODEC_OPUS;
        if (response_format == "aac") m_expectedCodec  = CODEC_AAC;
        if (response_format == "flac") m_expectedCodec  = CODEC_FLAC;

        m_dataMode = HTTP_RESPONSE_HEADER;
        m_f_tts = true;
    } else {
        /*AUDIO_LOG_WARN*/AUDIO_ERROR("Request %s failed!", host.get());
    }
    xSemaphoreGiveRecursive(mutex_playAudioData);
    return res;
}
//###################################################################
audiolib::hwoe_t Audio::dismantle_host(const char* host){
    if (!host) return {};

    audiolib::hwoe_t result;

    const char* p = host;

    // 🔐 1. SSL check
    if (strncmp(p, "https://", 8) == 0) {
        result.ssl = true;
        p += 8;
    } else if (strncmp(p, "http://", 7) == 0) {
        result.ssl = false;
        p += 7;
    } else {  // No valid scheme -> error or acceptance http
        result.ssl = false;
    }

    // ❓ 2. extract host (from p to ':' or '/' or '?')
    const char* host_start = p;
    const char* port_sep = strchr(p, ':');
    const char* path_sep = strchr(p, '/');
    const char* query_sep = strchr(p, '?');

    const char* host_end = p + strlen(p);  // default: end of string
    if (port_sep  && port_sep  < host_end) host_end = port_sep;
    if (path_sep  && path_sep  < host_end) host_end = path_sep;
    if (query_sep && query_sep < host_end) host_end = query_sep;
    result.hwoe.copy_from(host_start, host_end - host_start);
    result.rqh_host.clone_from(result.hwoe);

    // ❓ 3. extract port
    result.port = result.ssl ? 443 : 80; // default
    if (port_sep && (!path_sep || port_sep < path_sep)) {
        result.port = atoi(port_sep + 1);
        result.rqh_host.appendf(":%u", result.port);
    }

    // ❓ 4. extract extension (path)
    if (path_sep) {
        const char* path_start = path_sep + 1;
        const char* path_end = query_sep ? query_sep : host + strlen(host);
        result.extension.copy_from(path_start, path_end - path_start);
    }

    // ❓ 5. extract query string
    if (query_sep) {
        result.query_string.assign(query_sep + 1);
    }

    return result;
}
//###################################################################
bool Audio::connecttohost(const char* host, const char* user, const char* pwd) { // user and pwd for authentification only, can be empty

    if(!host) { AUDIO_ERROR("Hostaddress is empty");     stopSong(); return false;}
    if (strlen(host) > 2048) { AUDIO_ERROR("Hostaddress is too long");  stopSong(); return false;} // max length in Chrome DevTools

    bool     res           = false; // return value
    uint16_t port          = 0;     // port number
    uint16_t authLen       = 0;     // length of authorization
    uint32_t timestamp     = 0;     // timeout surveillance

    ps_ptr<char> c_host("c_host_connecttohost");             // copy of host
    ps_ptr<char> hwoe("hwoe_connecttohost");                 // host without extension
    ps_ptr<char> rqh_host("rqh_host_connecttohost");         // host for request header
    ps_ptr<char> extension("extension_connecttohost");       // extension
    ps_ptr<char> query_string("query_string_connecttohost"); // parameter
    ps_ptr<char> path("path_connecttohost");                 // extension + '?' + parameter
    ps_ptr<char> rqh("rqh_connecttohost");                   // request header

    xSemaphoreTakeRecursive(mutex_playAudioData, 0.3 * configTICK_RATE_HZ);

    c_host.copy_from(host);
    c_host.trim();
    auto dismantledHost = dismantle_host(c_host.get());

//  https://edge.live.mp3.mdn.newmedia.nacamar.net:8000/ps-charivariwb/livestream.mp3;?user=ps-charivariwb;&pwd=ps-charivariwb-------
//      |   |                                     |    |                              |
//      |   |                                     |    |                              |             (query string)
//  ssl?|   |<-----host without extension-------->|port|<----- --extension----------->|<-first parameter->|<-second parameter->.......
//                                                     |
//                                                     |<-----------------------------path------------------------------------>......

    m_f_ssl = dismantledHost.ssl;
    port = dismantledHost.port;
    if(dismantledHost.hwoe.valid()) hwoe.clone_from(dismantledHost.hwoe);
    if(dismantledHost.rqh_host.valid()) rqh_host.clone_from(dismantledHost.rqh_host);
    if(dismantledHost.extension.valid()) extension.clone_from(dismantledHost.extension);
    if(dismantledHost.query_string.valid()) query_string.clone_from(dismantledHost.query_string);

    if(extension.valid()) path.assign(extension.get());
    if(query_string.valid()){path.append("?"); path.append(query_string.get());}
    if(!hwoe.valid()) hwoe.assign("");
    if(!extension.valid()) extension.assign("");
    if(!path.valid()) path.assign("");

    path = urlencode(path.get(), true);

    // optional basic authorization
    if(user && pwd) authLen = strlen(user) + strlen(pwd);
    ps_ptr <char>authorization("authorization");
    ps_ptr<char> toEncode("toEncode");
    authorization.alloc(base64_encode_expected_len(authLen + 1) + 1);
    authorization.clear();
    if(authLen > 0) {
        toEncode.assign(user);
        toEncode.append(":");
        toEncode.append(pwd);
        b64encode((const char*)toEncode.get(), toEncode.strlen(), authorization.get());
    }

    setDefaults();

                       rqh.assign("GET /");
                       rqh.append(path.get());
                       rqh.append(" HTTP/1.1\r\n");
                       rqh.appendf("Host: %s\r\n", rqh_host.get());
                       rqh.append("Icy-MetaData:1\r\n");
                       rqh.append("Icy-MetaData:2\r\n");
                       rqh.append("Pragma: no-cache\r\n");
                       rqh.append("Cache-Control: no-cache\r\n");
                       rqh.append("Range: bytes=0-\r\n");
                       rqh.append("Accept: */*\r\n");
                       rqh.append("User-Agent: VLC/3.0.21 LibVLC/3.0.21 AppleWebKit/537.36 (KHTML, like Gecko)\r\n");
    if(authLen > 0) {  rqh.append("Authorization: Basic ");
                       rqh.append(authorization.get());
                       rqh.append("\r\n"); }
                       rqh.append("Accept-Encoding: identity;q=1,*;q=0\r\n");
                       rqh.append("Connection: keep-alive\r\n\r\n");

    if(m_f_ssl) { m_client = static_cast<NetworkClientSecure*>(&clientsecure); if(port == 80) port = 443;}
    else        { m_client = static_cast<NetworkClient*>(&client); }

    timestamp = millis();
    m_client->setTimeout(m_f_ssl ? m_timeout_ms_ssl : m_timeout_ms);

    AUDIO_INFO("connect to: \"%s\" on port %d path \"/%s\"", hwoe.get(), port, path.get());
    res = m_client->connect(hwoe.get(), port);

    m_expectedCodec = CODEC_NONE;
    m_expectedPlsFmt = FORMAT_NONE;

    if(res) {
        uint32_t dt = millis() - timestamp;
        AUDIO_INFO("%s has been established in %lu ms", m_f_ssl ? "SSL" : "Connection", (long unsigned int)dt);
        m_f_running = true;
        m_client->print(rqh.get());
        if(extension.ends_with_icase( ".mp3" ))      m_expectedCodec  = CODEC_MP3;
        if(extension.ends_with_icase( ".aac" ))      m_expectedCodec  = CODEC_AAC;
        if(extension.ends_with_icase( ".aacp" )) m_expectedCodec  = CODEC_AAC;
        if(extension.ends_with_icase( ".wav" ))      m_expectedCodec  = CODEC_WAV;
        if(extension.ends_with_icase( ".m4a" ))      m_expectedCodec  = CODEC_M4A;
        if(extension.ends_with_icase( ".ogg" ))      m_expectedCodec  = CODEC_OGG;
        if(extension.ends_with_icase( ".vorbis"))   m_expectedCodec = CODEC_VORBIS;
        if(extension.ends_with_icase( "/vorbis"))   m_expectedCodec = CODEC_VORBIS;
        if(extension.ends_with_icase( ".flac"))      m_expectedCodec  = CODEC_FLAC;
        if(extension.ends_with_icase( "-flac"))      m_expectedCodec  = CODEC_FLAC;
        if(extension.ends_with_icase( ".opus"))      m_expectedCodec  = CODEC_OPUS;
        if(extension.ends_with_icase( "/opus"))      m_expectedCodec  = CODEC_OPUS;
        if(extension.ends_with_icase( ".asx" ))      m_expectedPlsFmt = FORMAT_ASX;
        if(extension.ends_with_icase( ".m3u" ))      m_expectedPlsFmt = FORMAT_M3U;
        if(extension.ends_with_icase( ".pls" ))      m_expectedPlsFmt = FORMAT_PLS;
        if(extension.contains(".m3u8"))              m_expectedPlsFmt = FORMAT_M3U8;

        m_currentHost.clone_from(c_host);
        m_lastHost.clone_from(c_host);
//        audio_lasthost(m_lastHost.get());
//        info(evt_lasthost, m_lastHost.get());
        m_dataMode = HTTP_RESPONSE_HEADER; // Handle header
        m_streamType = ST_WEBSTREAM;
    }
    else {
        AUDIO_ERROR("Request %s failed!", c_host.get());
        m_f_running = false;
//        info(evt_name, "");
//        info(evt_streamtitle, "");
//        info(evt_icydescription, "");
//        info(evt_icyurl, "");
//        if(audio_showstation) audio_showstation("");
        if(audio_showstreamtitle) audio_showstreamtitle("");
//        if(audio_icydescription) audio_icydescription("");
        if(audio_icyurl) audio_icyurl("");
    }
    xSemaphoreGiveRecursive(mutex_playAudioData);
    return res;
}
//###################################################################
bool Audio::httpPrint(const char* host) {
    // user and pwd for authentification only, can be empty
    if(!m_f_running) return false;
    if(host == NULL) {AUDIO_ERROR("Hostaddress is empty"); stopSong(); return false;}

    uint16_t port = 0;         // port number
    ps_ptr<char> c_host;       // copy of host
    ps_ptr<char> hwoe;         // host without extension
    ps_ptr<char> rqh_host;     // host in request header
    ps_ptr<char> extension;    // extension
    ps_ptr<char> query_string; // parameter
    ps_ptr<char> path;         // extension + '?' + parameter
    ps_ptr<char> rqh;          // request header
    ps_ptr<char> cur_hwoe;     // m_currenthost without extension

    c_host.copy_from(host);
    c_host.trim();
    auto dismantledHost = dismantle_host(c_host.get());

//  https://edge.live.mp3.mdn.newmedia.nacamar.net:8000/ps-charivariwb/livestream.mp3;?user=ps-charivariwb;&pwd=ps-charivariwb-------
//      |   |                                     |    |                              |
//      |   |                                     |    |                              |             (query string)
//  ssl?|   |<-----host without extension-------->|port|<----- --extension----------->|<-first parameter->|<-second parameter->.......
//                                                     |
//                                                     |<-----------------------------path------------------------------------------->

    m_f_ssl = dismantledHost.ssl;
    port = dismantledHost.port;
    if(dismantledHost.hwoe.valid()) hwoe.clone_from(dismantledHost.hwoe);
    if(dismantledHost.rqh_host.valid()) rqh_host.clone_from(dismantledHost.rqh_host);
    if(dismantledHost.extension.valid()) extension.clone_from(dismantledHost.extension);
    if(dismantledHost.query_string.valid()) query_string.clone_from(dismantledHost.query_string);

    if(extension.valid()) path.assign(extension.get());
    if(query_string.valid()){path.append("?"); path.append(query_string.get());}
    if(!hwoe.valid()) hwoe.assign("");
    if(!extension.valid()) extension.assign("");
    if(!path.valid()) path.assign("");

    path = urlencode(path.get(), true);

    if(!m_currentHost.valid()) m_currentHost.assign("");
    auto dismantledLastHost = dismantle_host(m_currentHost.get());
    cur_hwoe.clone_from(dismantledLastHost.hwoe);

    bool f_equal = true;
    if(hwoe.equals(cur_hwoe)){f_equal = true;}
    else{                     f_equal = false;}

    rqh.assign("GET /");
    rqh.append(path.get());
    rqh.append(" HTTP/1.1\r\n");
    rqh.appendf("Host: %s\r\n", rqh_host.get());
    rqh.append("Icy-MetaData:1\r\n");
    rqh.append("Icy-MetaData:2\r\n");
    rqh.append("Accept:*/*\r\n");
    rqh.append("User-Agent: VLC/3.0.21 LibVLC/3.0.21 AppleWebKit/537.36 (KHTML, like Gecko)\r\n");
    rqh.append("Accept-Encoding: identity;q=1,*;q=0\r\n");
    rqh.append("Connection: keep-alive\r\n\r\n");

    AUDIO_INFO("next URL: \"%s\"", c_host.get());

    if(f_equal == false){
        if(m_client->connected()) m_client->stop();
    }
    if(!m_client->connected() ) {
         if(m_f_ssl) { m_client = static_cast<NetworkClientSecure*>(&clientsecure); if(m_f_ssl && port == 80) port = 443;}
         else        { m_client = static_cast<NetworkClient*>(&client); }
        if(f_equal) AUDIO_INFO("The host has disconnected, reconnecting");

        if(!m_client->connect(hwoe.get(), port)) {
            AUDIO_ERROR("connection lost %s", c_host.c_get());
            stopSong();
            return false;
        }
    }
    m_currentHost.clone_from(c_host);
    m_client->print(rqh.get());

    if(     extension.ends_with_icase(".mp3"))       m_expectedCodec  = CODEC_MP3;
    else if(extension.ends_with_icase(".aac"))       m_expectedCodec  = CODEC_AAC;
    else if(extension.ends_with_icase(".aacp"))       m_expectedCodec  = CODEC_AAC;
    else if(extension.ends_with_icase(".wav"))       m_expectedCodec  = CODEC_WAV;
    else if(extension.ends_with_icase(".m4a"))       m_expectedCodec  = CODEC_M4A;
    else if(extension.ends_with_icase(".flac"))      m_expectedCodec  = CODEC_FLAC;
    else if(extension.ends_with_icase("-flac"))   m_expectedCodec = CODEC_FLAC;
    else if(extension.ends_with_icase(".vorbis"))   m_expectedCodec = CODEC_VORBIS;
    else if(extension.ends_with_icase("/vorbis"))   m_expectedCodec = CODEC_VORBIS;
    else if(extension.ends_with_icase(".opus"))   m_expectedCodec = CODEC_OPUS;
    else if(extension.ends_with_icase("/opus"))   m_expectedCodec = CODEC_OPUS;
    else if(extension.ends_with_icase(".ogg" ))   m_expectedCodec = CODEC_OGG;
    else if(extension.ends_with_icase("/ogg" ))   m_expectedCodec = CODEC_OGG;
    else                                             m_expectedCodec  = CODEC_NONE;

    if(     extension.ends_with_icase(".asx"))       m_expectedPlsFmt = FORMAT_ASX;
    else if(extension.ends_with_icase(".m3u"))       m_expectedPlsFmt = FORMAT_M3U;
    else if(extension.contains(".m3u8"))             m_expectedPlsFmt = FORMAT_M3U8;
    else if(extension.ends_with_icase(".pls"))       m_expectedPlsFmt = FORMAT_PLS;
    else                                             m_expectedPlsFmt = FORMAT_NONE;

    m_audioFileSize = 0;
    m_dataMode = HTTP_RESPONSE_HEADER; // Handle header
    m_streamType = ST_WEBSTREAM;
    m_f_chunked = false;
    /*AUDIO_LOG_DEBUG*/AUDIO_INFO("playlistFormat %s, dataMode %s, streamType: %s", plsFmtStr[m_playlistFormat], dataModeStr[m_dataMode], streamTypeStr[m_streamType]);
    return true;
}
//###################################################################
bool Audio::httpRange(uint32_t seek, uint32_t length){

    if(!m_f_running) return false;

    uint16_t port = 0;         // port number
    ps_ptr<char> c_host;       // copy of host
    ps_ptr<char> hwoe;         // host without extension
    ps_ptr<char> rqh_host;     // host in request header
    ps_ptr<char> extension;    // extension
    ps_ptr<char> query_string; // parameter
    ps_ptr<char> path;         // extension + '?' + parameter
    ps_ptr<char> rqh;          // request header
    ps_ptr<char> cur_hwoe;     // m_currenthost without extension
    ps_ptr<char> range;        // e.g. "Range: bytes=124-"

    c_host.clone_from(m_currentHost);
    c_host.trim();
    auto dismantledHost = dismantle_host(c_host.get());

//  https://edge.live.mp3.mdn.newmedia.nacamar.net:8000/ps-charivariwb/livestream.mp3;?user=ps-charivariwb;&pwd=ps-charivariwb-------
//      |   |                                     |    |                              |
//      |   |                                     |    |                              |             (query string)
//  ssl?|   |<-----host without extension-------->|port|<----- --extension----------->|<-first parameter->|<-second parameter->.......
//                                                     |
//                                                     |<-----------------------------path------------------------------------------->

    m_f_ssl = dismantledHost.ssl;
    port = dismantledHost.port;
    if(dismantledHost.hwoe.valid()) hwoe.clone_from(dismantledHost.hwoe);
    if(dismantledHost.rqh_host.valid()) rqh_host.clone_from(dismantledHost.rqh_host);
    if(dismantledHost.extension.valid()) extension.clone_from(dismantledHost.extension);
    if(dismantledHost.query_string.valid()) query_string.clone_from(dismantledHost.query_string);

    if(extension.valid()) path.assign(extension.get());
    if(query_string.valid()){path.append("?"); path.append(query_string.get());}
    if(!hwoe.valid()) hwoe.assign("");
    if(!extension.valid()) extension.assign("");
    if(!path.valid()) path.assign("");

    path = urlencode(path.get(), true);

    if(!m_currentHost.valid()) m_currentHost.assign("");
    auto dismantledLastHost = dismantle_host(m_currentHost.get());
    cur_hwoe.clone_from(dismantledLastHost.hwoe);

    if(length == UINT32_MAX) range.assignf("Range: bytes=%li-\r\n",seek);
    else                     range.assignf("Range: bytes=%li-%li\r\n",seek, seek + length);

    rqh.assignf("GET /%s HTTP/1.1\r\n", path.get());
    rqh.appendf("Host: %s\r\n", rqh_host.get());
    rqh.append("Accept: */*\r\n");
    rqh.append("Accept-Encoding: identity;q=1,*;q=0\r\n");
    rqh.append("Cache-Control: no-cache\r\n");
    rqh.append("Connection: keep-alive\r\n");
    rqh.appendf(range.c_get());
    rqh.appendf("Referer: %s\r\n", m_currentHost.c_get());
    rqh.append("Sec-GPC: 1\r\n");
    rqh.append("User-Agent: VLC/3.0.21 LibVLC/3.0.21 AppleWebKit/537.36 (KHTML, like Gecko)\r\n\r\n");

    if(m_client->connected()) {m_client->stop();}
    if(m_f_ssl) { m_client = static_cast<NetworkClientSecure*>(&clientsecure); if(m_f_ssl && port == 80) port = 443;}
    else        { m_client = static_cast<NetworkClient*>(&client); }

    if(!m_client->connect(hwoe.get(), port)) {
        AUDIO_ERROR("connection lost %s", c_host.c_get());
        stopSong();
        return false;
    }

    // AUDIO_INFO("rqh \n%s", rqh.get());

    m_client->print(rqh.c_get());
    m_resumeFilePos = seek;  // used in processWebFile()

    m_dataMode = HTTP_RANGE_HEADER;
    m_streamType = ST_WEBFILE;
    return true;
}
//###################################################################
bool Audio::connecttoFS(fs::FS& fs, const char* path, int32_t fileStartPos) {

    xSemaphoreTakeRecursive(mutex_playAudioData, 0.3 * configTICK_RATE_HZ);
    ps_ptr<char>c_path;
//    ps_ptr<char> audioPath;
    bool res = false;
//    m_fileStartTime = fileStartPos;
    m_fileStartPos = fileStartPos;
    if(m_fileStartPos == 0) m_fileStartPos = -1;
    uint8_t codec = CODEC_NONE;

    if(!path) {AUDIO_ERROR("file path is not set"); goto exit;}  // guard
    c_path.copy_from(path); // copy from path
    c_path.trim();
    if(!c_path.contains(".")) {AUDIO_ERROR("No file extension found"); goto exit;}  // guard
    setDefaults(); // free buffers an set defaults

    if(c_path.ends_with_icase(".mp3")) { codec = CODEC_MP3; /*res = true;*/ AUDIO_INFO("format is mp3"); }
//    if(c_path.ends_with_icase(".m4a")) { codec = CODEC_M4A; /*res = true;*/ AUDIO_INFO("format is aac"); }
//    if(c_path.ends_with_icase(".aac")) { codec = CODEC_AAC; /*res = true;*/ AUDIO_INFO("format is aac"); }
//    if(c_path.ends_with_icase(".wav")) { codec = CODEC_WAV; /*res = true;*/ AUDIO_INFO("format is wav"); }
    if(c_path.ends_with_icase(".flac")) { codec = CODEC_FLAC; /*res = true;*/ AUDIO_INFO("format is flac"); }
//    if(c_path.ends_with_icase(".opus")) { codec = CODEC_OPUS; m_f_ogg = true; /*res = true;*/ AUDIO_INFO("format is opus"); }
//    if(c_path.ends_with_icase(".ogg")) { codec = CODEC_OGG; m_f_ogg = true; /*res = true;*/ AUDIO_INFO("format is ogg"); }
//    if(c_path.ends_with_icase(".oga")) { codec = CODEC_OGG; m_f_ogg = true; /*res = true;*/ AUDIO_INFO("format is ogg"); }
    if(codec == CODEC_NONE) {   // guard
        int dotPos = c_path.last_index_of('.');
        /*AUDIO_LOG_WARN*/AUDIO_ERROR("The %s format is not supported", path + dotPos); goto exit;
    }

    if(!c_path.starts_with("/")) c_path.insert("/", 0);

    if(!fs.exists(c_path.get())) {/*AUDIO_LOG_WARN*/AUDIO_ERROR("file not found: %s", c_path.get()); goto exit;}
    AUDIO_INFO("Reading file: \"%s\"", c_path.get());
    m_audiofile = fs.open(c_path.get());
    m_dataMode = AUDIO_LOCALFILE;
    m_audioFileSize = m_audiofile.size();

    res = initializeDecoder(codec);
    m_codec = codec;
    if(res) m_f_running = true;
    else m_audiofile.close();

exit:
    xSemaphoreGiveRecursive(mutex_playAudioData);
    return res;
}
//###################################################################
/*
 void Audio::printProcessLog(int r, const char* s){
    const char* e;
    const char* f = "";
    uint8_t logLevel;  // 1 Error, 2 Warn, 3 Info,
    switch(r) {
        case AUDIOLOG_PATH_IS_NULL: e = "The path or file name is empty"; logLevel = 1; break;
        case AUDIOLOG_OUT_OF_MEMORY: e = "Out of memory"; logLevel = 1; break;
        case AUDIOLOG_FILE_NOT_FOUND: e = "File doesn't exist: "; logLevel = 1; f = s; break;
        case AUDIOLOG_FILE_READ_ERR: e = "Failed to open file for reading"; logLevel = 1; break;

        default: e = "UNKNOWN EVENT"; logLevel = 3; break;
    }
    if(audio_log){
        audio_log(logLevel, e, f);
    }
    else {
        if     (logLevel == 1) AUDIO_INFO("ERROR: %s%s", e, f);}
        else if(logLevel == 2) {AUDIO_INFO("WARNING: %s%s", e, f);}
        else                   {AUDIO_INFO("INFO: %s%s", e, f);}
    }
 }	*/
//###################################################################
bool Audio::connecttospeech(const char* speech, const char* lang) {
    xSemaphoreTakeRecursive(mutex_playAudioData, 0.3 * configTICK_RATE_HZ);

    setDefaults();
    char host[] = "translate.google.com.vn";
    char path[] = "/translate_tts";

    m_speechtxt.assign(speech); // unique pointer takes care of the memory management
    auto urlStr = urlencode(speech, false); // percent encoding

    ps_ptr<char> req; // request header
    req.assign("GET ");
    req.append(path);
    req.append("?ie=UTF-8&tl=");
    req.append(lang);
    req.append("&client=tw-ob&q=");
    req.append(urlStr.get());
    req.append(" HTTP/1.1\r\n");
    req.append("Host: ");
    req.append(host);
    req.append("\r\n");
    req.append("User-Agent: Mozilla/5.0 \r\n");
    req.append("Accept-Encoding: identity\r\n");
    req.append("Accept: text/html\r\n");
    req.append("Connection: close\r\n\r\n");

    m_client = static_cast<NetworkClient*>(&client);
    AUDIO_INFO("connect to \"%s\"", host);
    if(!m_client->connect(host, 80)) {
        AUDIO_ERROR("Connection failed");
        xSemaphoreGiveRecursive(mutex_playAudioData);
        return false;
    }
    m_client->print(req.get());

    m_f_running = true;
    m_f_ssl = false;
    m_f_tts = true;
    m_dataMode = HTTP_RESPONSE_HEADER;
    m_lastHost.assign(host);
    m_currentHost.copy_from(host);
    xSemaphoreGiveRecursive(mutex_playAudioData);
    return true;
}
//###################################################################
void Audio::showID3Tag(const char* tag, const char* value) {
    ps_ptr<char>id3tag("id3tag");
    // V2.2
    if(!strcmp(tag, "CNT")) id3tag.appendf("Play counter: %s", value, "id3tag");
    if(!strcmp(tag, "COM")) id3tag.appendf("Comments: %s", value, "id3tag");
    if(!strcmp(tag, "CRA")) id3tag.appendf("Audio encryption: %s", value, "id3tag");
    if(!strcmp(tag, "CRM")) id3tag.appendf("Encrypted meta frame: %s", value, "id3tag");
    if(!strcmp(tag, "ETC")) id3tag.appendf("Event timing codes: %s", value, "id3tag");
    if(!strcmp(tag, "EQU")) id3tag.appendf("Equalization: %s", value, "id3tag");
    if(!strcmp(tag, "IPL")) id3tag.appendf("Involved people list: %s", value, "id3tag");
    if(!strcmp(tag, "PIC")) id3tag.appendf("Attached picture: %s", value, "id3tag");
    if(!strcmp(tag, "SLT")) id3tag.appendf("Synchronized lyric/text: %s", value, "id3tag");
    if(!strcmp(tag, "TAL")) { id3tag.appendf("Album/Movie/Show title: %s", value, "id3tag"); if(audio_id3album) audio_id3album(value); }
    if(!strcmp(tag, "TBP")) id3tag.appendf("BPM (Beats Per Minute): %s", value, "id3tag");
    if(!strcmp(tag, "TCM")) id3tag.appendf("Composer: %s", value, "id3tag");
    if(!strcmp(tag, "TCO")) id3tag.appendf("Content type: %s", value, "id3tag");
    if(!strcmp(tag, "TCR")) id3tag.appendf("Copyright message: %s", value, "id3tag");
    if(!strcmp(tag, "TDA")) id3tag.appendf("Date: %s", value, "id3tag");
    if(!strcmp(tag, "TDY")) id3tag.appendf("Playlist delay: %s", value, "id3tag");
    if(!strcmp(tag, "TEN")) id3tag.appendf("Encoded by: %s", value, "id3tag");
    if(!strcmp(tag, "TFT")) id3tag.appendf("File type: %s", value, "id3tag");
    if(!strcmp(tag, "TIM")) id3tag.appendf("Time: %s", value, "id3tag");
    if(!strcmp(tag, "TKE")) id3tag.appendf("Initial key: %s", value, "id3tag");
    if(!strcmp(tag, "TLA")) id3tag.appendf("Language(s): %s", value, "id3tag");
    if(!strcmp(tag, "TLE")) id3tag.appendf("Length: %s", value, "id3tag");
    if(!strcmp(tag, "TMT")) id3tag.appendf("Media type: %s", value, "id3tag");
    if(!strcmp(tag, "TOA")) { id3tag.appendf("Original artist(s)/performer(s): %s", value, "id3tag"); if(audio_id3artist) audio_id3artist(value); }
    if(!strcmp(tag, "TOF")) id3tag.appendf("Original filename: %s", value, "id3tag");
    if(!strcmp(tag, "TOL")) id3tag.appendf("Original Lyricist(s)/text writer(s): %s", value, "id3tag");
    if(!strcmp(tag, "TOR")) id3tag.appendf("Original release year: %s", value, "id3tag");
    if(!strcmp(tag, "TOT")) id3tag.appendf("Original album/Movie/Show title: %s", value, "id3tag");
    if(!strcmp(tag, "TP1")) id3tag.appendf("Lead artist(s)/Lead performer(s)/Soloist(s)/Performing group: %s", value, "id3tag");
    if(!strcmp(tag, "TP2")) id3tag.appendf("Band/Orchestra/Accompaniment: %s", value, "id3tag");
    if(!strcmp(tag, "TP3")) id3tag.appendf("Conductor/Performer refinement: %s", value, "id3tag");
    if(!strcmp(tag, "TP4")) id3tag.appendf("Interpreted, remixed, or otherwise modified by: %s", value, "id3tag");
    if(!strcmp(tag, "TPA")) id3tag.appendf("Part of a set: %s", value, "id3tag");
    if(!strcmp(tag, "TPB")) id3tag.appendf("Publisher: %s", value, "id3tag");
    if(!strcmp(tag, "TRC")) id3tag.appendf("ISRC (International Standard Recording Code): %s", value, "id3tag");
    if(!strcmp(tag, "TRD")) id3tag.appendf("Recording dates: %s", value, "id3tag");
    if(!strcmp(tag, "TRK")) id3tag.appendf("Track number/Position in set: %s", value, "id3tag");
    if(!strcmp(tag, "TSI")) id3tag.appendf("Size: %s", value, "id3tag");
    if(!strcmp(tag, "TSS")) id3tag.appendf("Software/hardware and settings used for encoding: %s", value, "id3tag");
    if(!strcmp(tag, "TT1")) id3tag.appendf("Content group description: %s", value, "id3tag");
    if(!strcmp(tag, "TT2")) { id3tag.appendf("Title/Songname/Content description: %s", value, "id3tag"); if(audio_id3album) audio_id3album(value); }
    if(!strcmp(tag, "TT3")) id3tag.appendf("Subtitle/Description refinement: %s", value, "id3tag");
    if(!strcmp(tag, "TXT")) id3tag.appendf("Lyricist/text writer: %s", value, "id3tag");
    if(!strcmp(tag, "TXX")) id3tag.appendf("User defined text information frame: %s", value, "id3tag");
    if(!strcmp(tag, "TYE")) id3tag.appendf("Year: %s", value, "id3tag");
    if(!strcmp(tag, "UFI")) id3tag.appendf("Unique file identifier: %s", value, "id3tag");
    if(!strcmp(tag, "ULT")) id3tag.appendf("Unsychronized lyric/text transcription: %s", value, "id3tag");
    if(!strcmp(tag, "WAF")) id3tag.appendf("Official audio file webpage: %s", value, "id3tag");
    if(!strcmp(tag, "WAR")) id3tag.appendf("Official artist/performer webpage: %s", value, "id3tag");
    if(!strcmp(tag, "WAS")) id3tag.appendf("Official audio source webpage: %s", value, "id3tag");
    if(!strcmp(tag, "WCM")) id3tag.appendf("Commercial information: %s", value, "id3tag");
    if(!strcmp(tag, "WCP")) id3tag.appendf("Copyright/Legal information: %s", value, "id3tag");
    if(!strcmp(tag, "WPB")) id3tag.appendf("Publishers official webpage: %s", value, "id3tag");
    if(!strcmp(tag, "WXX")) id3tag.appendf("User defined URL link frame: %s", value, "id3tag");

    // V2.3 V2.4 tags
    if(!strcmp(tag, "COMM")) id3tag.appendf("Comment: %s", value, "id3tag");
    if(!strcmp(tag, "OWNE")) id3tag.appendf("Ownership: %s", value, "id3tag");
    if(!strcmp(tag, "PRIV")) id3tag.appendf("Private: %s", value, "id3tag");
    if(!strcmp(tag, "SYLT")) id3tag.appendf("SynLyrics: %s", value, "id3tag");
    if(!strcmp(tag, "TALB")) { id3tag.appendf("Album: %s", value, "id3tag"); if(audio_id3album) audio_id3album(value); }
    if(!strcmp(tag, "TBPM")) id3tag.appendf("BeatsPerMinute: %s", value, "id3tag");
    if(!strcmp(tag, "TCAT")) id3tag.appendf("PodcastCategory: %s", value, "id3tag");
    if(!strcmp(tag, "TCMP")) id3tag.appendf("Compilation: %s", value, "id3tag");
    if(!strcmp(tag, "TCOM")) id3tag.appendf("Composer: %s", value, "id3tag");
    if(!strcmp(tag, "TCON")) id3tag.appendf("ContentType: %s", value, "id3tag");
    if(!strcmp(tag, "TCOP")) id3tag.appendf("Copyright: %s", value, "id3tag");
    if(!strcmp(tag, "TDAT")) id3tag.appendf("Date: %s", value, "id3tag");
    if(!strcmp(tag, "TDES")) id3tag.appendf("PodcastDescription: %s", value, "id3tag");
    if(!strcmp(tag, "TDOR")) id3tag.appendf("Original Release Year: %s", value, "id3tag");
    if(!strcmp(tag, "TDRC")) id3tag.appendf("Publication date: %s", value, "id3tag");
    if(!strcmp(tag, "TDRL")) id3tag.appendf("ReleaseTime: %s", value, "id3tag");
    if(!strcmp(tag, "TENC")) id3tag.appendf("Encoded by: %s", value, "id3tag");
    if(!strcmp(tag, "TEXT")) id3tag.appendf("Lyricist: %s", value, "id3tag");
    if(!strcmp(tag, "TGID")) id3tag.appendf("PodcastID: %s", value, "id3tag");
    if(!strcmp(tag, "TIME")) id3tag.appendf("Time: %s", value, "id3tag");
    if(!strcmp(tag, "TIT1")) id3tag.appendf("Grouping: %s", value, "id3tag");
    if(!strcmp(tag, "TIT2")) { id3tag.appendf("Title: %s", value, "id3tag"); if(audio_id3album) audio_id3album(value); }
    if(!strcmp(tag, "TIT3")) id3tag.appendf("Subtitle: %s", value, "id3tag");
    if(!strcmp(tag, "TLAN")) id3tag.appendf("Language: %s", value, "id3tag");
    if(!strcmp(tag, "TLEN")) id3tag.appendf("Length (ms): %s", value, "id3tag");
    if(!strcmp(tag, "TMED")) id3tag.appendf("Media: %s", value, "id3tag");
    if(!strcmp(tag, "TOAL")) id3tag.appendf("OriginalAlbum: %s", value, "id3tag");
    if(!strcmp(tag, "TOPE")) id3tag.appendf("OriginalArtist: %s", value, "id3tag");
    if(!strcmp(tag, "TOLY")) id3tag.appendf("OriginalLyricist: %s", value, "id3tag");
    if(!strcmp(tag, "TORY")) id3tag.appendf("OriginalReleaseYear: %s", value, "id3tag");
    if(!strcmp(tag, "TPE1")) { id3tag.appendf("Artist: %s", value, "id3tag"); if(audio_id3artist) audio_id3artist(value); }
    if(!strcmp(tag, "TPE2")) id3tag.appendf("Band: %s", value, "id3tag");
    if(!strcmp(tag, "TPE3")) id3tag.appendf("Conductor: %s", value, "id3tag");
    if(!strcmp(tag, "TPE4")) id3tag.appendf("InterpretedBy: %s", value, "id3tag");
    if(!strcmp(tag, "TPOS")) id3tag.appendf("PartOfSet: %s", value, "id3tag");
    if(!strcmp(tag, "TPUB")) id3tag.appendf("Publisher: %s", value, "id3tag");
    if(!strcmp(tag, "TRCK")) id3tag.appendf("Track: %s", value, "id3tag");
    if(!strcmp(tag, "TRSN")) id3tag.appendf("InternetRadioStationName: %s", value, "id3tag");
    if(!strcmp(tag, "TSSE")) id3tag.appendf("SettingsForEncoding: %s", value, "id3tag");
    if(!strcmp(tag, "TRDA")) id3tag.appendf("RecordingDates: %s", value, "id3tag");
    if(!strcmp(tag, "TSO2")) id3tag.appendf("AlbumArtistSortOrder: %s", value, "id3tag");
    if(!strcmp(tag, "TSOA")) id3tag.appendf("AlbumSortOrder: %s", value, "id3tag");
    if(!strcmp(tag, "TSOP")) id3tag.appendf("PerformerSortOrder: %s", value, "id3tag");
    if(!strcmp(tag, "TSOC")) id3tag.appendf("ComposerSortOrder: %s", value, "id3tag");
    if(!strcmp(tag, "TSOT")) id3tag.appendf("TitleSortOrder: %s", value, "id3tag");
    if(!strcmp(tag, "TXXX")) id3tag.appendf("UserDefinedText: %s", value, "id3tag");
    if(!strcmp(tag, "TYER")) id3tag.appendf("Year: %s", value, "id3tag");
    if(!strcmp(tag, "USER")) id3tag.appendf("TermsOfUse: %s", value, "id3tag");
    if(!strcmp(tag, "USLT")) id3tag.appendf("Lyrics: %s", value, "id3tag");
    if(!strcmp(tag, "WCOM")) id3tag.appendf("Commercial URL: %s", value, "id3tag");
    if(!strcmp(tag, "WFED")) id3tag.appendf("Podcast URL: %s", value, "id3tag");
    if(!strcmp(tag, "WOAF")) id3tag.appendf("File URL: %s", value, "id3tag");
    if(!strcmp(tag, "WOAR")) id3tag.appendf("OfficialArtistWebpage: %s", value, "id3tag");
    if(!strcmp(tag, "WOAS")) id3tag.appendf("Source URL: %s", value, "id3tag");
    if(!strcmp(tag, "WORS")) id3tag.appendf("InternetRadioStationURL: %s", value, "id3tag");
    if(!strcmp(tag, "WXXX")) id3tag.appendf("User defined URL link frame: %s", value, "id3tag");
    if(!strcmp(tag, "XDOR")) id3tag.appendf("OriginalReleaseTime: %s", value, "id3tag");

    if(!id3tag.valid()){/*AUDIO_LOG_DEBUG*/AUDIO_INFO("unknown tag: %s", tag); return;}
    latinToUTF8(id3tag);
    if(id3tag.contains("?xml")) {
        showstreamtitle(id3tag.get());
        return;
    }
    if(id3tag.strlen()) {
//        info(evt_id3data, id3tag.get());
        if(audio_id3data) audio_id3data(id3tag.get());
    }
}
//###################################################################
void Audio::latinToUTF8(ps_ptr<char>& buff, bool UTF8check) {
    // most stations send  strings in UTF-8 but a few sends in latin. To standardize this, all latin strings are
    // converted to UTF-8. If UTF-8 is already present, nothing is done and true is returned.
    // A conversion to UTF-8 extends the string. Therefore it is necessary to know the buffer size. If the converted
    // string does not fit into the buffer, false is returned

    uint16_t pos = 0;
    uint16_t in = 0;
    uint16_t out = 0;
    bool     isUTF8 = true;

    // We cannot detect if a given string (or byte sequence) is a UTF-8 encoded text as for example each and every series
    // of UTF-8 octets is also a valid (if nonsensical) series of Latin-1 (or some other encoding) octets.
    // However not every series of valid Latin-1 octets are valid UTF-8 series. So you can rule out strings that do not conform
    // to the UTF-8 encoding schema:

    if (UTF8check) {
        while (buff[pos] != '\0') {
            if (buff[pos] <= 0x7F) {// 0xxxxxxx: ASCII
                pos++;
            }
            else if ((buff[pos] & 0xE0) == 0xC0) {
                if (pos + 1 >= buff.strlen()) isUTF8 = false;
                // 110xxxxx 10xxxxxx: 2-byte
                if ((buff[pos + 1] & 0xC0) != 0x80) isUTF8 = false;
                if (buff[pos] < 0xC2) isUTF8 = false; // Overlong encoding
                pos += 2;
            }
            else if  ((buff[pos] & 0xF0) == 0xE0) {
                // 1110xxxx 10xxxxxx 10xxxxxx: 3-byte
                if ((buff[pos + 1] & 0xC0) != 0x80 || (buff[pos + 2] & 0xC0) != 0x80) isUTF8 = false;
                if (buff[pos] == 0xE0 && buff[pos + 1 ] < 0xA0) isUTF8 = false; // Overlong
                if (buff[pos] == 0xED && buff[pos + 1] >= 0xA0) isUTF8 = false; // UTF-16 surrogate
                pos += 3;
            }
            else if ((buff[pos] & 0xF8) == 0xF0) {
                // 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx: 4-byte
                if ((buff[pos + 1] & 0xC0) != 0x80 ||
                    (buff[pos + 2] & 0xC0) != 0x80 ||
                    (buff[pos + 3] & 0xC0) != 0x80) isUTF8 = false;
                if (buff[pos] == 0xF0 && buff[pos + 1] < 0x90) isUTF8 = false; // Overlong
                if (buff[pos] > 0xF4 || (buff[pos] == 0xF4 && buff[pos + 1] > 0x8F)) isUTF8 = false; // > U+10FFFF
                pos += 4;
            }
            else{
                isUTF8 = false; // Invalid first byte
            }
            if(!isUTF8)break;
        }
        if (isUTF8) return; // is UTF-8, do nothing
    }
    ps_ptr<char> iso8859_1("iso8859_1");
    iso8859_1.assign(buff.get());

    // Worst-case: all chars are latin1 > 0x7F became 2 Bytes → max length is twice +1
    std::size_t requiredSize = strlen(iso8859_1.get()) * 2 + 1;

    if (buff.size() < requiredSize) {
        buff.realloc(requiredSize);
    }

    // coding into UTF-8
    while (iso8859_1[in] != '\0') {
        if (iso8859_1[in] < 0x80) {
            buff[out++] = iso8859_1[in++];
        } else {
            buff[out++] = (0xC0 | (iso8859_1[in] >> 6));
            buff[out++] = (0x80 | (iso8859_1[in] & 0x3F));
            in++;
        }
    }
    buff[out] = '\0';
}
//###################################################################
void Audio::htmlToUTF8(char* str) { // convert HTML to UTF-8

    typedef struct { // --- EntityMap Definition ---
        const char *name;
        uint32_t codepoint;
    } EntityMap;

    const EntityMap entities[] = {
        {"amp",   0x0026}, // &
        {"lt",    0x003C}, // <
        {"gt",    0x003E}, // >
        {"quot",  0x0022}, // "
        {"apos",  0x0027}, // '
        {"nbsp",  0x00A0}, // non-breaking space
        {"euro",  0x20AC}, // €
        {"copy",  0x00A9}, // ©
        {"reg",   0x00AE}, // ®
        {"trade", 0x2122}, // ™
        {"hellip",0x2026}, // …
        {"ndash", 0x2013}, // –
        {"mdash", 0x2014}, // —
        {"sect",  0x00A7}, // §
        {"para",  0x00B6}  // ¶
    };

    // --- EntityMap Lookup ---
    auto find_entity = [&](const char *p, uint32_t *codepoint, int *entity_len) {
        for (size_t i = 0; i < sizeof(entities)/sizeof(entities[0]); i++) {
            const char *name = entities[i].name;
            size_t len = strlen(name);
            if (strncmp(p + 1, name, len) == 0 && p[len + 1] == ';') {
                *codepoint = entities[i].codepoint;
                *entity_len = (int)(len + 2); // &name;
                return 1;
            }
        }
        return 0;
    };


    auto codepoint_to_utf8 = [&](uint32_t cp, char *dst) { // Convert a Codepoint (Unicode) to UTF-8, writes in DST, there is number of bytes back
        if (cp <= 0x7F) {
            dst[0] = cp;
            return 1;
        } else if (cp <= 0x7FF) {
            dst[0] = 0xC0 | (cp >> 6);
            dst[1] = 0x80 | (cp & 0x3F);
            return 2;
        } else if (cp <= 0xFFFF) {
            dst[0] = 0xE0 | (cp >> 12);
            dst[1] = 0x80 | ((cp >> 6) & 0x3F);
            dst[2] = 0x80 | (cp & 0x3F);
            return 3;
        } else if (cp <= 0x10FFFF) {
            dst[0] = 0xF0 | (cp >> 18);
            dst[1] = 0x80 | ((cp >> 12) & 0x3F);
            dst[2] = 0x80 | ((cp >> 6) & 0x3F);
            dst[3] = 0x80 | (cp & 0x3F);
            return 4;
        }
        return -1; // invalid Codepoint
    };

    char *p = str;
    while (*p != '\0') {
        if(p[0] == '&'){
            uint32_t cp;
            int consumed;
            if (find_entity(p, &cp, &consumed)) { // looking for entity, such as &copy;
                char utf8[5] = {0};
                int len = codepoint_to_utf8(cp, utf8);
                if (len > 0) {
                    size_t tail_len = strlen(p + consumed);
                    memmove(p + len, p + consumed, tail_len + 1);
                    memcpy(p, utf8, len);
                    p += len;
                    continue;
                }
            }
        }
        if (p[0] == '&' && p[1] == '#') {
            char *endptr;
            uint32_t codepoint = strtol(p + 2, &endptr, 10);

            if (*endptr == ';' && codepoint <= 0x10FFFF) {
                char utf8[5] = {0};
                int utf8_len = codepoint_to_utf8(codepoint, utf8);
                if (utf8_len > 0) {
                //    size_t entity_len = endptr - p + 1;
                    size_t tail_len = strlen(endptr + 1);

                    // Show residual ring to the left
                    memmove(p + utf8_len, endptr + 1, tail_len + 1);  // +1 because of '\0'

                    // Copy UTF-8 characters
                    memcpy(p, utf8, utf8_len);

                    // weiter bei neuem Zeichen
                    p += utf8_len;
                    continue;
                }
            }
        }
        p++;
    }
}
//###################################################################
size_t Audio::readAudioHeader(uint32_t bytes) {
    size_t bytesReaded = 0;
    if(m_codec == CODEC_WAV) {
        int res = read_WAV_Header(InBuff.getReadPtr(), bytes);
        if(res >= 0) bytesReaded = res;
        else { // error, skip header
            m_controlCounter = 100;
        }
    }
    if(m_codec == CODEC_MP3) {
        int res = read_ID3_Header(InBuff.getReadPtr(), bytes);
        if(res >= 0) bytesReaded = res;
        else { // error, skip header
            m_controlCounter = 100;
        }
    }
    if(m_codec == CODEC_M4A) {
        int res = read_M4A_Header(InBuff.getReadPtr(), bytes);
        if(res >= 0) bytesReaded = res;
        else { // error, skip header
            m_controlCounter = 100;
        }
    }
    if(m_codec == CODEC_AAC) {
        // stream only, no header
        m_audioDataSize = m_audioFileSize;
        m_controlCounter = 100;
    }
    if(m_codec == CODEC_FLAC) {
        int res = read_FLAC_Header(InBuff.getReadPtr(), bytes);
        if(res >= 0) bytesReaded = res;
        else { // error, skip header
            stopSong();
            m_controlCounter = 100;
        }
    }
    if(m_codec == CODEC_OPUS)   { m_controlCounter = 100; }
    if(m_codec == CODEC_VORBIS) { m_controlCounter = 100; }
    if(m_codec == CODEC_OGG)    { m_controlCounter = 100; }
    if(!isRunning()) {
        AUDIO_ERROR("Processing stopped due to invalid audio header");
        return 0;
    }
    return bytesReaded;
}
//##################################################################
int Audio::read_WAV_Header(uint8_t* data, size_t len) {

    if(m_controlCounter == 0) {
        m_rwh.cs = 0;
        m_rwh.bts = 0;
        m_controlCounter++;
        if((*data != 'R') || (*(data + 1) != 'I') || (*(data + 2) != 'F') || (*(data + 3) != 'F')) {
            AUDIO_ERROR("file has no RIFF tag");
            m_rwh.headerSize = 0;
            return -1; // false;
        }
        else {
            m_rwh.headerSize = 4;
            return 4; // ok
        }
    }

    if(m_controlCounter == 1) {
        m_controlCounter++;
        m_rwh.cs = (uint32_t)(*data + (*(data + 1) << 8) + (*(data + 2) << 16) + (*(data + 3) << 24) - 8);
        m_rwh.headerSize += 4;
        return 4; // ok
    }

    if(m_controlCounter == 2) {
        m_controlCounter++;
        if((*data != 'W') || (*(data + 1) != 'A') || (*(data + 2) != 'V') || (*(data + 3) != 'E')) {
            AUDIO_ERROR("format tag is not WAVE");
            return -1; // false;
        }
        else {
            m_rwh.headerSize += 4;
            return 4;
        }
    }

    if(m_controlCounter == 3) {
        if((*data == 'f') && (*(data + 1) == 'm') && (*(data + 2) == 't')) {
            m_controlCounter++;
            m_rwh.headerSize += 4;
            return 4;
        }
        else {
            m_rwh.headerSize += 4;
            return 4;
        }
    }

    if(m_controlCounter == 4) {
        m_controlCounter++;
        m_rwh.cs = (uint32_t)(*data + (*(data + 1) << 8));
        if(m_rwh.cs > 40) return -1; // false, something going wrong
        m_rwh.bts = m_rwh.cs - 16;         // bytes to skip if fmt chunk is >16
        m_rwh.headerSize += 4;
        return 4;
    }

    if(m_controlCounter == 5) {
        m_controlCounter++;
        uint16_t fc = (uint16_t)(*(data + 0) + (*(data + 1) << 8));                                               // Format code
        uint16_t nic = (uint16_t)(*(data + 2) + (*(data + 3) << 8));                                              // Number of interleaved channels
        uint32_t sr = (uint32_t)(*(data + 4) + (*(data + 5) << 8) + (*(data + 6) << 16) + (*(data + 7) << 24));   // Samplerate
        uint32_t dr = (uint32_t)(*(data + 8) + (*(data + 9) << 8) + (*(data + 10) << 16) + (*(data + 11) << 24)); // Datarate
        uint16_t dbs = (uint16_t)(*(data + 12) + (*(data + 13) << 8));                                            // Data block size
        uint16_t bps = (uint16_t)(*(data + 14) + (*(data + 15) << 8));                                            // Bits per sample

        AUDIO_INFO("FormatCode: %u", fc);
        // AUDIO_INFO("Channel: %u", nic);
        // AUDIO_INFO("SampleRate: %u (Hz)", sr);
        AUDIO_INFO("DataRate: %lu", (long unsigned int)dr);
        AUDIO_INFO("DataBlockSize: %u", dbs);
        AUDIO_INFO("BitsPerSample: %u", bps);

        if((bps != 8) && (bps != 16)) {
            AUDIO_ERROR("BitsPerSample is %u,  must be 8 or 16", bps);
            stopSong();
            return -1;
        }
        if((nic != 1) && (nic != 2)) {
            AUDIO_INFO("num channels is %u,  must be 1 or 2", nic);
            stopSong();
            return -1;
        }
        if(fc != 1) {
            AUDIO_ERROR("format code is not 1 (PCM)");
            stopSong();
            return -1; // false;
        }
        m_BitsPerSample = bps;
        m_SampleRate = sr;
        m_channels = nic;
        m_nominal_bitrate = nic * sr * bps;
        AUDIO_INFO("BitRate: %lu", m_nominal_bitrate);
        m_rwh.headerSize += 16;
        return 16; // ok
    }

    if(m_controlCounter == 6) {
        m_controlCounter++;
        m_rwh.headerSize += m_rwh.bts;
        return m_rwh.bts; // skip to data
    }

    if(m_controlCounter == 7) {
        if((*(data + 0) == 'd') && (*(data + 1) == 'a') && (*(data + 2) == 't') && (*(data + 3) == 'a')) {
            m_controlCounter++;
            //    vTaskDelay(30);
            m_rwh.headerSize += 4;
            return 4;
        }
        else {
            m_rwh.headerSize++;
            return 1;
        }
    }

    if(m_controlCounter == 8) {
        m_controlCounter++;
        size_t cs = *(data + 0) + (*(data + 1) << 8) + (*(data + 2) << 16) + (*(data + 3) << 24); // read chunkSize
        m_rwh.headerSize += 4;
        if(cs) { m_audioDataSize = cs - 44; }
        else { // sometimes there is nothing here
            m_audioDataSize = m_audioFileSize -m_rwh. headerSize;
        }
        AUDIO_INFO("Audio-Length: %u", m_audioDataSize);
        m_audioFileDuration = m_audioDataSize  / m_SampleRate * m_channels;
        if(m_BitsPerSample == 16) m_audioFileDuration /= 2;
        AUDIO_INFO("Duration: %u (s)", m_audioFileDuration);
        AUDIO_INFO("BitRate: %lu", m_nominal_bitrate);
//        audio_bitrate(m_nominal_bitrate);
        return 4;
    }
    m_controlCounter = 100; // header succesfully read
    m_audioDataStart = m_rwh.headerSize;
    return 0;
}
//##################################################################
int Audio::read_FLAC_Header(uint8_t* data, size_t len) {

    if(m_rflh.retvalue) {
        if(m_rflh.retvalue > len) { // if returnvalue > bufferfillsize
            if(len > InBuff.getMaxBlockSize()) len = InBuff.getMaxBlockSize();
            m_rflh.retvalue -= len; // and wait for more bufferdata
            return len;
        }
        else {
            size_t tmp = m_rflh.retvalue;
            m_rflh.retvalue = 0;
            return tmp;
        }
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_BEGIN) { // init
        memset(&m_rflh,  0, sizeof(audiolib::rflh_t));
        m_controlCounter = FLAC_MAGIC;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_MAGIC) {            /* check MAGIC STRING */
        if(specialIndexOf(data, "OggS", 10) == 0) { // is ogg
            m_rflh.headerSize = 0;
            m_rflh.retvalue = 0;
            m_controlCounter = FLAC_OKAY;
            return 0;
        }
        if(specialIndexOf(data, "fLaC", 10) != 0) {
            AUDIO_ERROR("Magic String 'fLaC' not found in header");
            stopSong();
            return -1;
        }
        m_controlCounter = FLAC_MBH; // METADATA_BLOCK_HEADER
        m_rflh.headerSize = 4;
        m_rflh.retvalue = 4;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_MBH) { /* METADATA_BLOCK_HEADER */
        uint8_t blockType = *data;
        if(!m_rflh.f_lastMetaBlock) {
            if(blockType & 128) {m_rflh.f_lastMetaBlock = true; }
            blockType &= 127;
            if(blockType == 0) m_controlCounter = FLAC_SINFO;
            if(blockType == 1) m_controlCounter = FLAC_PADDING;
            if(blockType == 2) m_controlCounter = FLAC_APP;
            if(blockType == 3) m_controlCounter = FLAC_SEEK;
            if(blockType == 4) m_controlCounter = FLAC_VORBIS;
            if(blockType == 5) m_controlCounter = FLAC_CUESHEET;
            if(blockType == 6) m_controlCounter = FLAC_PICTURE;
            m_rflh.headerSize += 1;
            m_rflh.retvalue = 1;
            return 0;
        }
        m_controlCounter = FLAC_OKAY;
        m_audioDataStart =m_rflh. headerSize;
        m_audioDataSize = m_audioFileSize - m_audioDataStart;
        FLACSetRawBlockParams(m_rflh.numChannels, m_rflh.sampleRate, m_rflh.bitsPerSample, m_rflh.totalSamplesInStream, m_audioDataSize);
        if(m_rflh.picLen) {
            size_t pos = m_audioFilePosition;
            std::vector<uint32_t> vec;
            vec.push_back(m_rflh.picPos);
            vec.push_back(m_rflh.picLen);
//            info(evt_image, vec);
            audioFileSeek(pos); // the filepointer could have been changed by the user, set it back
            vec.clear();
        }
        AUDIO_INFO("Audio-Length: %u", m_audioDataSize);
        if(m_rflh.duration){
            m_rflh.nominalBitrate =  (m_audioDataSize * 8) / m_rflh.duration;
            m_nominal_bitrate = m_rflh.nominalBitrate;
            m_audioFileDuration = m_rflh.duration;
            AUDIO_INFO("Duration: %u (s)", m_rflh.duration);
            AUDIO_INFO("nominal bitrate : %u (b/s)", m_nominal_bitrate);
            AUDIO_INFO("BitRate: %lu", m_nominal_bitrate);
//            audio_bitrate(m_nominal_bitrate);
        }
        if(audio_progress) audio_progress(m_audioDataStart, m_audioDataSize);
        m_rflh.retvalue = 0;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_SINFO) { /* Stream info block */
        size_t l = bigEndian(data, 3);
        vTaskDelay(2);
        m_rflh.maxBlockSize = bigEndian(data + 5, 2);
        AUDIO_INFO("FLAC maxBlockSize: %u", m_rflh.maxBlockSize );
        vTaskDelay(2);
        m_rflh.maxFrameSize = bigEndian(data + 10, 3);
        if(m_rflh.maxFrameSize) { AUDIO_INFO("FLAC maxFrameSize: %u", m_rflh.maxFrameSize); }
        else { AUDIO_INFO("FLAC maxFrameSize: N/A"); }
        if(m_rflh.maxFrameSize > InBuff.getMaxBlockSize()) {
            AUDIO_ERROR("FLAC maxFrameSize too large!");
            stopSong();
            return -1;
        }
        //        InBuff.changeMaxBlockSize(m_rflh.maxFrameSize);
        vTaskDelay(2);
        uint32_t nextval = bigEndian(data + 13, 3);
        m_rflh.sampleRate = nextval >> 4;
        AUDIO_INFO("FLAC sampleRate: %lu (Hz)", (long unsigned int)m_rflh.sampleRate);
        vTaskDelay(2);
        m_rflh.numChannels = ((nextval & 0x06) >> 1) + 1;
        AUDIO_INFO("FLAC numChannels: %u", m_rflh.numChannels);
        vTaskDelay(2);
        uint8_t bps = (nextval & 0x01) << 4;
        bps += (*(data + 16) >> 4) + 1;
        m_rflh.bitsPerSample = bps;
        if((bps != 8) && (bps != 16)) {
            AUDIO_ERROR("bits per sample must be 8 or 16, is %i", bps);
            stopSong();
            return -1;
        }
        AUDIO_INFO("FLAC bitsPerSample: %u", m_rflh.bitsPerSample);
        m_rflh.totalSamplesInStream = bigEndian(data + 17, 4);
        if(m_rflh.totalSamplesInStream) { AUDIO_INFO("total samples in stream: %lu", (long unsigned int)m_rflh.totalSamplesInStream); }
        else { AUDIO_INFO("total samples in stream: N/A"); }
        if(bps != 0 && m_rflh.totalSamplesInStream && m_rflh.sampleRate) {
            m_rflh.duration = (long unsigned int)m_rflh.totalSamplesInStream / (long unsigned int)m_rflh.sampleRate;
        }
        m_controlCounter = FLAC_MBH; // METADATA_BLOCK_HEADER
        m_rflh.retvalue = l + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_PADDING) { /* PADDING */
        size_t l = bigEndian(data, 3);
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = l + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_APP) { /* APPLICATION */
        size_t l = bigEndian(data, 3);
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = l + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_SEEK) { /* SEEKTABLE */
        size_t l = bigEndian(data, 3);
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = l + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_VORBIS) { /* VORBIS COMMENT */ // field names

        auto parse_flac_timestamp = [&](const char* s){
            if (!s || *s != '[') return -1;
            int mm = 0, ss = 0, hh = 0;
            if (sscanf(s, "[%d:%d.%d]", &mm, &ss, &hh) == 3) {
                return mm * 60000 + ss * 1000 + hh * 10;
            }
            return -1;
        };

        ps_ptr<char>vendorString("vendorString");
        ps_ptr<char>commentString("commentString");
        ps_ptr<char>lyricsBuffer("lyricsBuffer");
        size_t vendorLength = bigEndian(data, 3);
        size_t idx = 0;
        data += 3; idx += 3;
        size_t vendorStringLength = data[0] + (data[1] << 8) + (data[2] << 16) + (data[3] << 24);
        if(vendorStringLength) {data += 4; idx += 4;}
        if(vendorStringLength > 495) vendorStringLength = 495; // guard
        vendorString.assign((const char*)data, vendorStringLength);
        vendorString.insert("VENDOR_STRING: ", 0);
        /*info(evt_id3data,*/ audio_id3data(vendorString.get());
        data += vendorStringLength; idx += vendorStringLength;
        size_t commentListLength = data[0] + (data[1] << 8) + (data[2] << 16) + (data[3] << 24);
        data += 4; idx += 4;

        char* album = NULL;
        char* artist = NULL;
        char* title  = NULL;

        for(int i = 0; i < commentListLength; i++) {
            (void)i;
            size_t commentLength = data[0] + (data[1] << 8) + (data[2] << 16) + (data[3] << 24);
            data += 4; idx += 4;
            if(commentLength) { // guard
                commentString.assign((const char*)data , commentLength);
                if(commentString.starts_with("LYRICS=")) lyricsBuffer.clone_from(commentString);
                else /*info(evt_id3data,*/ audio_id3data(commentString.get());

            if(startsWith(commentString.get(), "album") || startsWith(commentString.get(), "ALBUM")){
                album = strdup(commentString.get() + 6);
                audio_id3album(album); }

            if(startsWith(commentString.get(), "artist") || startsWith(commentString.get(), "ARTIST")){
                artist = strdup(commentString.get() + 7);
//                audio_id3artist(artist);
                strcpy(album, " / ");
                strcpy(album, artist); }

            if(startsWith(commentString.get(), "title") || startsWith(commentString.get(), "TITLE")){
                title = strdup(commentString.get() + 6);
                strcpy(album, " - ");
                strcpy(album, title);
                audio_id3album(album); }

            }
            data += commentLength; idx += commentLength;
            if(idx > vendorLength + 3) {AUDIO_ERROR("VORBIS COMMENT section is too long");}

        }
        ps_ptr<char> tmp(__LINE__);
        ps_ptr<char> timestamp(__LINE__);
        timestamp.alloc(12);
        if(lyricsBuffer.valid()){
            lyricsBuffer.remove_prefix("LYRICS=");
            idx = 0;
            while(idx < lyricsBuffer.size()){
                int pos = lyricsBuffer.index_of('\n', idx);
                if(pos == - 1) break;
                int len = pos - idx + 1;
                tmp.copy_from(lyricsBuffer.get() + idx, len);
                idx += len;
                if(tmp.ends_with("\n")) tmp.truncate_at('\n');
                // tmp content e.g.: [00:27.07]Jetzt kommt die Zeit
                //                   [00:28.84]Auf die ihr euch freut
                timestamp.copy_from(tmp.get(), 10);

                int ms = parse_flac_timestamp(timestamp.c_get());

                // timestamp.remove_chars("[]:.");
                // timestamp.append("0"); // to ms 0028840
                tmp.remove_before(10, true);
                if(tmp.strlen() > 0){
                    m_syltLines.push_back(std::move(tmp));
                    m_syltTimeStamp.push_back(ms);
                }
            }
            AUDIO_INFO("audiofile contains synchronized lyrics");
            // for(int i = 0; i < m_syltLines.size(); i++){
            //     info(evt_lyrics, "%07i ms,   %s", m_syltTimeStamp[i], m_syltLines[i].c_get());
            // }
        }
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = vendorLength + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_CUESHEET) { /* CUESHEET */
        size_t l = bigEndian(data, 3);
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = l + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == FLAC_PICTURE) { /* PICTURE */
        m_rflh.picLen = bigEndian(data, 3);
        m_rflh.picPos = m_rflh.headerSize;
        // AUDIO_INFO("FLAC PICTURE, size %i, pos %i", picLen, picPos);
        m_controlCounter = FLAC_MBH;
        m_rflh.retvalue = m_rflh.picLen + 3;
        m_rflh.headerSize += m_rflh.retvalue;
        return 0;
    }
    return 0;
}
//##################################################################
int Audio::read_ID3_Header(uint8_t* data, size_t len) {
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 0) { /* read ID3 tag and ID3 header size */
        m_controlCounter++;

        m_ID3Hdr.id3Size = 0;
        m_ID3Hdr.totalId3Size = 0; // if we have more header, id3_1_size + id3_2_size + ....
        m_ID3Hdr.remainingHeaderBytes = 0;
        m_ID3Hdr.universal_tmp = 0;
        m_ID3Hdr.ID3version = 0;
        m_ID3Hdr.ehsz = 0;
        m_ID3Hdr.framesize = 0;
        m_ID3Hdr.compressed = false;
        m_ID3Hdr.SYLT.size = 0;
        m_ID3Hdr.SYLT.pos = 0;
        m_ID3Hdr.numID3Header = 0;
        m_ID3Hdr.iBuffSize = 4096;
        m_ID3Hdr.iBuff.alloc(m_ID3Hdr.iBuffSize + 10, "m_ID3Hdr.iBuff");
        memset(m_ID3Hdr.tag, 0, sizeof(m_ID3Hdr.tag));
        memset(m_ID3Hdr.APIC_size, 0, sizeof(m_ID3Hdr.APIC_size));
        memset(m_ID3Hdr.APIC_pos, 0, sizeof(m_ID3Hdr.APIC_pos));
        memset(m_ID3Hdr.tag, 0, sizeof(m_ID3Hdr.tag));

        AUDIO_INFO("File-Size: %lu", m_audioFileSize);

        m_ID3Hdr.remainingHeaderBytes = 0;
        m_ID3Hdr.ehsz = 0;
        if(specialIndexOf(data, "ID3", 4) != 0) { // ID3 not found
            if(!m_f_m3u8data) {AUDIO_INFO("file has no ID3 tag, skip metadata");}
            m_audioDataSize = m_audioFileSize;
//            if(!m_f_m3u8data) AUDIO_INFO("Audio-Length: %u", m_audioDataSize);
            m_controlCounter = 99; // have xing?
            if(audio_progress) audio_progress(m_audioDataStart, m_audioDataSize);
            return 0; // error, no ID3 signature found
        }
        m_ID3Hdr.ID3version = *(data + 3);
        switch(m_ID3Hdr.ID3version) {
            case 2:
                m_f_unsync = (*(data + 5) & 0x80);
                m_f_exthdr = false;
                break;
            case 3:
            case 4:
                m_f_unsync = (*(data + 5) & 0x80); // bit7
                m_f_exthdr = (*(data + 5) & 0x40); // bit6 extended header
                break;
        };
        m_ID3Hdr.id3Size = bigEndian(data + 6, 4, 7); //  ID3v2 size  4 * %0xxxxxxx (shift left seven times!!)
        m_ID3Hdr.id3Size += 10;

        // Every read from now may be unsync'd
        if(!m_f_m3u8data) AUDIO_INFO("ID3 framesSize: %i", m_ID3Hdr.id3Size);
        if(!m_f_m3u8data) AUDIO_INFO("ID3 version: 2.%i", m_ID3Hdr.ID3version);

        if(m_ID3Hdr.ID3version == 2) { m_controlCounter = 10; }
        m_ID3Hdr.remainingHeaderBytes = m_ID3Hdr.id3Size;
        m_ID3Size = m_ID3Hdr.id3Size;
        m_ID3Hdr.remainingHeaderBytes -= 10;

        return 10;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 1) { // compute extended header size if exists
        m_controlCounter++;
        if(m_f_exthdr) {
            AUDIO_INFO("ID3 extended header");
            m_ID3Hdr.ehsz = bigEndian(data, 4);
            m_ID3Hdr.remainingHeaderBytes -= 4;
            m_ID3Hdr.ehsz -= 4;
            return 4;
        }
        else {
            // if(!m_f_m3u8data) AUDIO_INFO("ID3 normal frames");
            return 0;
        }
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 2) { // skip extended header if exists
        if(m_ID3Hdr.ehsz > len) {
            m_ID3Hdr.ehsz -= len;
            m_ID3Hdr.remainingHeaderBytes -= len;
            return len;
        } // Throw it away
        else {
            m_controlCounter++;
            m_ID3Hdr.remainingHeaderBytes -= m_ID3Hdr.ehsz;
            return m_ID3Hdr.ehsz;
        } // Throw it away
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 3) { // read a ID3 frame, get the tag
        if(m_ID3Hdr.remainingHeaderBytes == 0) {
            m_controlCounter = 99;
            return 0;
        }
        m_controlCounter++;
        m_ID3Hdr.frameid[0] = *(data + 0);
        m_ID3Hdr.frameid[1] = *(data + 1);
        m_ID3Hdr.frameid[2] = *(data + 2);
        m_ID3Hdr.frameid[3] = *(data + 3);
        m_ID3Hdr.frameid[4] = 0;
        for(uint8_t i = 0; i < 4; i++) m_ID3Hdr.tag[i] = m_ID3Hdr.frameid[i]; // tag = frameid

        m_ID3Hdr.remainingHeaderBytes -= 4;
        if(m_ID3Hdr.frameid[0] == 0 && m_ID3Hdr.frameid[1] == 0 && m_ID3Hdr.frameid[2] == 0 && m_ID3Hdr.frameid[3] == 0) {
            // We're in padding
            m_controlCounter = 98; // all ID3 metadata processed
        }
        return 4;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 4) { // get the frame size
        m_controlCounter = 6;

        if(m_ID3Hdr.ID3version == 4) {
            m_ID3Hdr.framesize = bigEndian(data, 4, 7); // << 7
        }
        else {
            m_ID3Hdr.framesize = bigEndian(data, 4); // << 8
        }
        m_ID3Hdr.remainingHeaderBytes -= 4;
        uint8_t frameFlag_0 = *(data + 4);
        uint8_t frameFlag_1 = *(data + 5);
        (void)frameFlag_0;
        m_ID3Hdr.remainingHeaderBytes--;
        m_ID3Hdr.compressed = frameFlag_1 & 0x80; // Frame is compressed using [#ZLIB zlib] with 4 bytes for 'decompressed
        m_ID3Hdr.remainingHeaderBytes--;
        uint32_t decompsize = 0;
        if(m_ID3Hdr.compressed) {
            // AUDIO_INFO("iscompressed");
            decompsize = bigEndian(data + 6, 4);
            m_ID3Hdr.remainingHeaderBytes -= 4;
            (void)decompsize;
            // AUDIO_INFO("decompsize=%u", decompsize);
            return 6 + 4;
        }
        return 6;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 5) { // If the frame is larger than m_ID3Hdr.framesize, skip the rest
        if(m_ID3Hdr.framesize > len) {
            m_ID3Hdr.framesize -= len;
            m_ID3Hdr.remainingHeaderBytes -= len;
            return len;
        }
        else {
            m_controlCounter = 3; // check next frame
            m_ID3Hdr.remainingHeaderBytes -= m_ID3Hdr.framesize;
            return m_ID3Hdr.framesize;
        }
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 6) { // Read the value
        m_controlCounter = 5;   // only read 256 bytes

        uint8_t textEncodingByte = *(data + 0);  // ID3v2 Text-Encoding-Byte
        // $00 – ISO-8859-1 (LATIN-1, Identical to ASCII for values smaller than 0x80).
        // $01 – UCS-2 encoded Unicode with BOM (Byte Order Mark), in ID3v2.2 and ID3v2.3.
        // $02 – UTF-16BE encoded Unicode without BOM (Byte Order Mark) , in ID3v2.4.
        // $03 – UTF-8 encoded Unicode, in ID3v2.4.

        if(startsWith(m_ID3Hdr.tag, "APIC")) { // a image embedded in file, passing it to external function
        //    if(m_dataMode == AUDIO_LOCALFILE) {
                m_ID3Hdr.APIC_pos[m_ID3Hdr.numID3Header] = m_ID3Hdr.totalId3Size + m_ID3Hdr.id3Size - m_ID3Hdr.remainingHeaderBytes;
                m_ID3Hdr.APIC_size[m_ID3Hdr.numID3Header] = m_ID3Hdr.framesize;
                //    AUDIO_ERROR("APIC_pos %i APIC_size %i", APIC_pos[numID3Header], APIC_size[numID3Header]);
        //    }
            return 0;
        }

        if(startsWith(m_ID3Hdr.tag, "SYLT") || startsWith(m_ID3Hdr.tag, "USLT")) { // any lyrics embedded in file, passing it to external function
            m_controlCounter = 7;
            return 0;
        }


        if( // proprietary not standard information
            startsWith(m_ID3Hdr.tag, "PRIV")) {
                ;//AUDIO_ERROR("PRIV");
                return 0;
        }

        if(m_ID3Hdr.framesize == 0) return 0;

        ps_ptr<char> tmp(__LINE__);
        ps_ptr<char> content_descriptor(__LINE__);
        size_t fs = m_ID3Hdr.framesize; // fs = size of the frame data field as read from header
        size_t bytesToCopy = fs;
        size_t textDataLength = 0;
        uint16_t idx = 0;

        if (bytesToCopy >= m_ID3Hdr.iBuffSize) { bytesToCopy = m_ID3Hdr.iBuffSize - 1;} // make sure a zero terminator fits
        if (bytesToCopy > 0) { textDataLength = bytesToCopy - 1;}                       // Only if there are data that we can shorten
        for (int i = 0; i < textDataLength; i++) {
            m_ID3Hdr.iBuff[i] = *(data + i + 1);                                        // Skipped the first byte (Encoding)
        }

        if (textEncodingByte == 1 || textEncodingByte == 2) {                           // is UTF-16LE or UTF-16BE
            m_ID3Hdr.iBuff[textDataLength] = 0;                                         // UTF-16: set double zero terminator
            m_ID3Hdr.iBuff[textDataLength + 1] = 0;                                     // second '\0' for UTF-16
        } else {
            m_ID3Hdr.iBuff[textDataLength] = 0;                                         // only one '\0' for ISO-8859-1 or UTF-8
        }

        m_ID3Hdr.framesize -= fs;
        m_ID3Hdr.remainingHeaderBytes -= fs;
        uint16_t dataLength = fs - 1;
        bool isBigEndian = (textEncodingByte == 2);

        char encodingTab [4][12] = {"ISO-8859-1", "UTF-16", "UTF-16BE", "UTF-8"};

        if(startsWith(m_ID3Hdr.tag, "COMM")){ // language code
            m_ID3Hdr.lang[0] = m_ID3Hdr.iBuff[0];
            m_ID3Hdr.lang[1] = m_ID3Hdr.iBuff[1];
            m_ID3Hdr.lang[2] = m_ID3Hdr.iBuff[2];
            m_ID3Hdr.lang[3] = '\0';

            idx = 4;
            if(textEncodingByte == 1 || textEncodingByte == 2) idx++;

            uint16_t cd_len = 0;
            if     (textEncodingByte == 0) cd_len = 1 + content_descriptor.copy_from_iso8859_1((const uint8_t*)(m_ID3Hdr.iBuff.get() + idx));         // iso8859_1
            else if(textEncodingByte == 3) cd_len = 1 + content_descriptor.copy_from((const char*)(m_ID3Hdr.iBuff.get() + idx));                      // utf-8
            else                           cd_len = 2 + content_descriptor.copy_from_utf16((const uint8_t*)(m_ID3Hdr.iBuff.get() + idx), isBigEndian);// utf-16
            if(cd_len > 2) AUDIO_INFO("Comment: text encoding; %s, language %s, content_descriptor: %s", encodingTab[textEncodingByte], m_ID3Hdr.lang, content_descriptor.c_get());

            idx += cd_len;
        }

        // AUDIO_INFO("Tag: %s, Length: %i, Format: %s", m_ID3Hdr.tag, textDataLength, encodingTab[textEncodingByte]);

        if      (textEncodingByte == 0)                          {tmp.copy_from_iso8859_1((const uint8_t*)m_ID3Hdr.iBuff.get() + idx);} // ISO-8859-1
        else if (textEncodingByte == 1 || textEncodingByte == 2) {tmp.copy_from_utf16((const uint8_t*)m_ID3Hdr.iBuff.get() + idx, isBigEndian);} // UTF-16LE oder UTF-16BE
        else if (textEncodingByte == 3)                          {tmp.copy_from(m_ID3Hdr.iBuff.get() + idx);} // UTF-8 copy directly because no conversion is necessary

        showID3Tag(m_ID3Hdr.tag, tmp.c_get());

        return fs;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 7) { // SYLT
        m_controlCounter = 5;
        if(m_dataMode == AUDIO_LOCALFILE || (m_streamType == ST_WEBFILE && m_f_acceptRanges))  {
            ps_ptr<char> tmp(__LINE__);
            ps_ptr<char> content_descriptor(__LINE__);
            ps_ptr<char> syltBuff("syltBuff");
            bool isBigEndian = true;
            size_t len = 0;
            int idx = 0;
            m_ID3Hdr.SYLT.pos = m_ID3Hdr.id3Size - m_ID3Hdr.remainingHeaderBytes;
            m_ID3Hdr.SYLT.size = m_ID3Hdr.framesize;
            syltBuff.alloc(m_ID3Hdr.SYLT.size + 1);
            if((m_streamType == ST_WEBFILE && m_f_acceptRanges) || (m_dataMode == AUDIO_LOCALFILE)){
                uint32_t pos = m_audioFilePosition;
            //    AUDIO_INFO("m_audioFilePosition %i, m_ID3Hdr.SYLT.pos %i", pos, m_ID3Hdr.SYLT.pos);
                audioFileSeek(m_ID3Hdr.SYLT.pos, m_ID3Hdr.SYLT.pos + m_ID3Hdr.SYLT.size);
                uint16_t bytesWritten = 0;
                while(bytesWritten < m_ID3Hdr.SYLT.size){
                    bytesWritten += audioFileRead((uint8_t*)syltBuff.get() + bytesWritten, m_ID3Hdr.SYLT.size);
                }
                audioFileSeek(pos);
            }
        //    syltBuff.hex_dump(10);
            m_ID3Hdr.SYLT.text_encoding = syltBuff[0]; // 0=ISO-8859-1, 1=UTF-16, 2=UTF-16BE, 3=UTF-8
            if(m_ID3Hdr.SYLT.text_encoding == 1) isBigEndian = false;
            if(m_ID3Hdr.SYLT.text_encoding > 3){AUDIO_ERROR("unknown text encoding: %i", m_ID3Hdr.SYLT.text_encoding); m_ID3Hdr.SYLT.text_encoding = 0;}
            char encodingTab [4][12] = {"ISO-8859-1", "UTF-16", "UTF-16BE", "UTF-8"};
            memcpy(m_ID3Hdr.SYLT.lang, syltBuff.get() + 1, 3); m_ID3Hdr.SYLT.lang[3] = '\0';
            AUDIO_INFO("Lyrics: text_encoding: %s, language: %s, size %i", encodingTab[m_ID3Hdr.SYLT.text_encoding], m_ID3Hdr.SYLT.lang, m_ID3Hdr.SYLT.size);
            m_ID3Hdr.SYLT.time_stamp_format =  syltBuff[4];
            m_ID3Hdr.SYLT.content_type =       syltBuff[5];
            idx = 6;
            uint16_t cd_len = 0;
            if     (m_ID3Hdr.SYLT.text_encoding == 0) cd_len = 1 + content_descriptor.copy_from_iso8859_1((const uint8_t*)(syltBuff.get() + idx));         // iso8859_1
            else if(m_ID3Hdr.SYLT.text_encoding == 3) cd_len = 1 + content_descriptor.copy_from((const char*)(syltBuff.get() + idx));                      // utf-8
            else                                      cd_len = 2 + content_descriptor.copy_from_utf16((const uint8_t*)(syltBuff.get() + idx), isBigEndian);// utf-16
            if(cd_len > 2) AUDIO_INFO("Lyrics: content_descriptor: %s", content_descriptor.c_get());

            idx += cd_len;
            while (idx < m_ID3Hdr.SYLT.size) {
                if      (m_ID3Hdr.SYLT.text_encoding == 0) idx += 1 + tmp.copy_from_iso8859_1((const uint8_t*)syltBuff.get() + idx);            // ISO8859_1
                else if (m_ID3Hdr.SYLT.text_encoding == 3) idx += 1 + tmp.copy_from((const char*)syltBuff.get() + idx);                         // UTF-8
                else                                       idx += 2 + tmp.copy_from_utf16((const uint8_t*)(syltBuff.get() + idx), isBigEndian); // UTF-16LE, UTF-16BE

                if (tmp.starts_with("\n")) tmp.remove_before(1);
                m_syltLines.push_back(std::move(tmp));
                if (idx + 4 > m_ID3Hdr.SYLT.size) break; // no more 4 bytes?
                uint32_t timestamp = bigEndian((uint8_t*)syltBuff.get() + idx, 4);
                m_syltTimeStamp.push_back(timestamp);
                idx += 4;
            }
            AUDIO_INFO("audiofile contains synchronized lyrics");
            // for(int i = 0; i < m_syltLines.size(); i++){
            //     info(evt_lyrics, "%07i ms,   %s", m_syltTimeStamp[i], m_syltLines[i].c_get());
            // }
        }
        return 0;
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    // --- section V2.2 only , higher Vers above ----
    // see https://mutagen-specs.readthedocs.io/en/latest/id3/id3v2.2.html
    if(m_controlCounter == 10) { // frames in V2.2, 3bytes identifier, 3bytes size descriptor

        if(m_ID3Hdr.universal_tmp > 0) {
            if(m_ID3Hdr.universal_tmp > len) {
                m_ID3Hdr.universal_tmp -= len;
                return len;
            } // Throw it away
            else {
                uint32_t t = m_ID3Hdr.universal_tmp;
                m_ID3Hdr.universal_tmp = 0;
                return t;
            } // Throw it away
        }

        m_ID3Hdr.frameid[0] = *(data + 0);
        m_ID3Hdr.frameid[1] = *(data + 1);
        m_ID3Hdr.frameid[2] = *(data + 2);
        m_ID3Hdr.frameid[3] = 0;
        for(uint8_t i = 0; i < 4; i++) m_ID3Hdr.tag[i] = m_ID3Hdr.frameid[i]; // tag = frameid
        m_ID3Hdr.remainingHeaderBytes -= 3;
        size_t dataLen = bigEndian(data + 3, 3);
        m_ID3Hdr.universal_tmp = dataLen;
        m_ID3Hdr.remainingHeaderBytes -= 3;
        char value[256];
        if(dataLen > 249) { dataLen = 249; }
        memcpy(value, (data + 7), dataLen);
        value[dataLen + 1] = 0;
        if(startsWith(m_ID3Hdr.tag, "PIC")) { // image embedded in header
            if(m_dataMode == AUDIO_LOCALFILE) {
                m_ID3Hdr.APIC_pos[m_ID3Hdr.numID3Header] = m_ID3Hdr.id3Size - m_ID3Hdr.remainingHeaderBytes;
                m_ID3Hdr.APIC_size[m_ID3Hdr.numID3Header] = m_ID3Hdr.universal_tmp;
                // AUDIO_INFO("Attached picture seen at pos %d length %d", APIC_pos[0], APIC_size[0]);
            }
        }
        else if(startsWith(m_ID3Hdr.tag, "SLT")) { // lyrics embedded in header
            if(m_dataMode == AUDIO_LOCALFILE) {

                ps_ptr<char> tmp(__LINE__);
                ps_ptr<char> content_descriptor(__LINE__);
                ps_ptr<char> syltBuff("syltBuff");
                bool isBigEndian = true;
                size_t len = 0;
                int idx = 0;

                m_ID3Hdr.SYLT.pos = m_ID3Hdr.id3Size - m_ID3Hdr.remainingHeaderBytes;
                m_ID3Hdr.SYLT.size = m_ID3Hdr.universal_tmp;
                syltBuff.alloc(m_ID3Hdr.SYLT.size);
                uint32_t pos = m_audioFilePosition;
                audioFileSeek(m_ID3Hdr.SYLT.pos);
                uint16_t bytesWritten = 0;
                while(bytesWritten < m_ID3Hdr.SYLT.size){
                    bytesWritten += audioFileRead((uint8_t*)syltBuff.get() + bytesWritten, m_ID3Hdr.SYLT.size);
                }
                audioFileSeek(pos);
                m_ID3Hdr.SYLT.text_encoding = syltBuff[0];
                memcpy(m_ID3Hdr.SYLT.lang, syltBuff.get() + 1, 3); m_ID3Hdr.SYLT.lang[3] = '\0';
                AUDIO_INFO("Lyrics: text_encoding: %s, language: %s, size %i", m_ID3Hdr.SYLT.text_encoding == 0 ? "ASCII" : m_ID3Hdr.SYLT.text_encoding == 3 ? "UTF-8" : "?", m_ID3Hdr.SYLT.lang, m_ID3Hdr.SYLT.size);
                m_ID3Hdr.SYLT.time_stamp_format =  syltBuff[4];
                m_ID3Hdr.SYLT.content_type =       syltBuff[5];

                idx = 6;

                if(m_ID3Hdr.SYLT.text_encoding == 0 || m_ID3Hdr.SYLT.text_encoding == 3){ // utf-8
                    len = content_descriptor.copy_from((const char*)(syltBuff.get() + idx));
                }
                else{ // utf-16
                    len = content_descriptor.copy_from_utf16((const uint8_t*)(syltBuff.get() + idx), isBigEndian);
                }
                if(len > 2) AUDIO_INFO("Lyrics: content_descriptor: %s", content_descriptor.c_get());
                idx += len;

                while (idx < m_ID3Hdr.SYLT.size) {
                        // UTF-16LE, UTF-16BE
                    if (m_ID3Hdr.SYLT.text_encoding == 1 || m_ID3Hdr.SYLT.text_encoding == 2) {
                        idx += tmp.copy_from_utf16((const uint8_t*)(syltBuff.get() + idx), isBigEndian);
                    } else {
                        // ISO-8859-1 / UTF-8
                        idx += tmp.copy_from((const char*)syltBuff.get() + idx);
                    }
                    if (tmp.starts_with("\n")) tmp.remove_before(1);
                    m_syltLines.push_back(std::move(tmp));

                    if (idx + 4 > m_ID3Hdr.SYLT.size) break; // no more 4 bytes?

                    uint32_t timestamp = bigEndian((uint8_t*)syltBuff.get() + idx, 4);
                    m_syltTimeStamp.push_back(timestamp);

                    idx += 4;
                }
                AUDIO_INFO("audiofile contains synchronized lyrics");
                // for(int i = 0; i < m_syltLines.size(); i++){
                //     info(evt_lyrics, "%07i ms,   %s", m_syltTimeStamp[i], m_syltLines[i].c_get());
                // }
            }
        }
        else { showID3Tag(m_ID3Hdr.tag, value);}
        m_ID3Hdr.remainingHeaderBytes -= m_ID3Hdr.universal_tmp;
        m_ID3Hdr.universal_tmp -= dataLen;

        if(dataLen == 0) m_controlCounter = 98;
        if(m_ID3Hdr.remainingHeaderBytes == 0) m_controlCounter = 98;

        return 3 + 3 + dataLen;
    }
    // -- end section V2.2 -----------

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 98) { // skip all ID3 metadata (mostly spaces)
        if(m_ID3Hdr.remainingHeaderBytes > len) {
            m_ID3Hdr.remainingHeaderBytes -= len;
            return len;
        } // Throw it away
        else {
            m_controlCounter = 99;
            return m_ID3Hdr.remainingHeaderBytes;
        } // Throw it away
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == 99) { //  exist another ID3tag?

        static const int samplerate_table[4][3] = {
            {11025, 12000, 8000},   // MPEG 2.5
            {0, 0, 0},              // reserved
            {22050, 24000, 16000},  // MPEG 2
            {44100, 48000, 32000}   // MPEG 1
        };

        static const int samples_per_frame[4][4] = {
        // layer:   0    1      2      3
        /* V2.5 */ {0,   576, 1152,   384},
        /* res. */ {0,     0,    0,     0},
        /* V2   */ {0,   576, 1152,   384},
        /* V1   */ {0,  1152, 1152,   384}
        };

        m_audioDataStart += m_ID3Hdr.id3Size;
        //    vTaskDelay(30);
        if((*(data + 0) == 'I') && (*(data + 1) == 'D') && (*(data + 2) == '3')) {
            m_controlCounter = 0;
            m_ID3Hdr.numID3Header++;
            m_ID3Hdr.totalId3Size += m_ID3Hdr.id3Size;
            return 0;
        }
        else {
            m_controlCounter = 100; // ok
            m_audioDataSize = m_audioFileSize - m_audioDataStart;
            if(!m_f_m3u8data) AUDIO_INFO("Audio-Length: %u", m_audioDataSize);
            if(audio_progress) audio_progress(m_audioDataStart, m_audioDataSize);

            uint32_t hdr = bigEndian(data, 4);
            if ((hdr & 0xFFE00000) != 0xFFE00000) AUDIO_INFO("Syncword not found"); // check sync
            int versionID   = (hdr >> 19) & 0x3;   // 0=MPEG2.5, 2=MPEG2, 3=MPEG1
            int layerIndex  = (hdr >> 17) & 0x3;   // 1=Layer3
            int bitrateIdx  = (hdr >> 12) & 0xF;
            int samplerateIdx = (hdr >> 10) & 0x3;
            int mode        = (hdr >> 6) & 0x3;   // 0=stereo,3=mono
            int samplerate = samplerate_table[versionID][samplerateIdx];
            int spf = samples_per_frame[versionID][layerIndex];

            // Xing or Info Header present?
            int8_t mp3_xing = specialIndexOf(data, "Xing", 50);
            int8_t mp3_info = specialIndexOf(data, "Info", 50);

            uint8_t xingPos = 0;
            if(mp3_xing > 0) xingPos = mp3_xing;
            if(mp3_info > 0) xingPos = mp3_info;

            if(xingPos >0 && layerIndex == 1){ // layer III only
                uint32_t frames = bigEndian(data + xingPos + 8, 4);
                AUDIO_INFO("frames %i", frames);
                uint32_t bytes = bigEndian(data + xingPos + 12, 4);
                AUDIO_INFO("bytes %i", bytes);
                uint32_t duration = frames * spf / samplerate;
                AUDIO_INFO("Duration: %u (s)", duration);
                m_audioFileDuration = duration;
                uint32_t bitrate = bytes * 8 / duration;
                m_nominal_bitrate = bitrate;
                AUDIO_INFO("BitRate: %lu", bitrate);
            }

            if(m_ID3Hdr.APIC_pos[0]) { // if we have more than one APIC, output the first only
                std::vector<uint32_t> vec;
                vec.push_back(m_ID3Hdr.APIC_pos[0]);
                vec.push_back(m_ID3Hdr.APIC_size[0]);
//                info(evt_image, vec);
                vec.clear();

                size_t pos = m_audioFilePosition;
                audioFileSeek(pos); // the filepointer could have been changed by the user, set it back
            }
            m_ID3Hdr.numID3Header = 0;
            m_ID3Hdr.totalId3Size = 0;
            for(int i = 0; i < 3; i++) m_ID3Hdr.APIC_pos[i] = 0;  // delete all
            for(int i = 0; i < 3; i++) m_ID3Hdr.APIC_size[i] = 0; // delete all
            m_ID3Hdr.iBuff.reset();
            return 0;
        }
    }
    return 0;
}
//###################################################################
int Audio::read_M4A_Header(uint8_t* data, size_t len) {

    ps_ptr<char>atom_name("atom_name");
    ps_ptr<char>atom_size("atom_size");
    uint32_t idx = 0;

    /*
         ftyp
           | - moov  -> trak -> ... -> mp4a contains raw block parameters
           |    L... -> ilst  contains artist, composer ....
         free (optional) // jump to another atoms at the end of mdat
           |
         mdat contains the audio data                                                      */

    if(m_m4aHdr.retvalue) {
        if(m_m4aHdr.retvalue > UINT16_MAX){
            int res = audioFileSeek(m_m4aHdr.headerSize);
            if(res >= 0){
                AUDIO_INFO("skip %li bytes", m_m4aHdr.retvalue);
                InBuff.resetBuffer();
                m_m4aHdr.retvalue = 0;
               return 0;
            }
        }
        if(m_m4aHdr.retvalue > len) {
            m_m4aHdr.retvalue -= len;
            m_m4aHdr.cnt += len;
            return len;
        }
        else {
            size_t tmp = m_m4aHdr.retvalue;
            m_m4aHdr.retvalue = 0;
            m_m4aHdr.cnt += tmp;
            return tmp;
        }
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_BEGIN) { // init
        memset(&m_m4aHdr, 0, sizeof(audiolib::m4aHdr_t));

        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);

        if(atom_name.equals("ftyp")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_ftyp = atom_size.to_uint32(16);
            m_controlCounter = M4A_FTYP;
        }
        else{
            AUDIO_ERROR("begin: ftyp not found");
            stopSong();
            return -1;
        }
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_FTYP) { /* check_m4a_file */

        int m4a  = specialIndexOf(data, "M4A ", 20);
        int isom = specialIndexOf(data, "isom", 20);
        int mp42 = specialIndexOf(data, "mp42", 20);

        if((m4a != 8) && (isom != 8) && (mp42 != 8)) {
            AUDIO_ERROR("subtype 'MA4 ', 'isom' or 'mp42' expected, but found '%s '", (data + 8));
            stopSong();
            return -1;
        }

        m_m4aHdr.retvalue += m_m4aHdr.sizeof_ftyp;
        m_m4aHdr.headerSize += m_m4aHdr.sizeof_ftyp;
        m_controlCounter = M4A_CHK;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_CHK) {  /* check  Tag */
        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);

        if(atom_name.equals("moov")){
            m_m4aHdr.progressive = true;
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_moov = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MOOV;
            return 0;
        }

        if(atom_name.equals("mdat")){
            if(!m_m4aHdr.progressive){
//                /*AUDIO_LOG_DEBUG*/AUDIO_INFO("non progressive file can't be played yet"); // mdat before moov, todo: skip mdat
                stopSong();
                return -1;
            }
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_mdat = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MDAT;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        m_m4aHdr.sizeof_moov -= atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_MOOV) { // moov
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("moov size remain %i", m_m4aHdr.sizeof_moov);
        if(m_m4aHdr.sizeof_moov == 0) {m_controlCounter = M4A_CHK; return 0;} // go back

        atom_name.copy_from((const char*)data + 4, 4);
        atom_size.big_endian(data, 4);
        m_m4aHdr.sizeof_moov -= atom_size.to_uint32(16);

        if(atom_name.equals("trak")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_trak = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_TRAK;
            return 0;
        }

        if(atom_name.equals("udta")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_udta = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_UDTA;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_TRAK) { // trak
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("trak size remain %i", m_m4aHdr.sizeof_trak);
        if(m_m4aHdr.sizeof_trak == 0){ m_controlCounter = M4A_MOOV; return 0;}// go back

        atom_name.copy_from((const char*)data + 4, 4);
        atom_size.big_endian(data, 4);
        m_m4aHdr.sizeof_trak -= atom_size.to_uint32(16);

        if(atom_name.equals("mdia")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_mdia = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MDIA;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_MDIA) { // mdia
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("mdia size remain %i", m_m4aHdr.sizeof_mdia);
        if(m_m4aHdr.sizeof_mdia == 0) {m_controlCounter = M4A_TRAK; return 0;} // go back

        atom_name.copy_from((const char*)data + 4, 4);
        atom_size.big_endian(data, 4);
        m_m4aHdr.sizeof_mdia -= atom_size.to_uint32(16);

        if(atom_name.equals("mdhd")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_mdhd = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MDHD;
            return 0;
        }

        if(atom_name.equals("minf")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_minf = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MINF;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_MINF) { // minf
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("minf size remain %i", m_m4aHdr.sizeof_minf);
        if(m_m4aHdr.sizeof_minf == 0) {m_controlCounter = M4A_MDIA; return 0;} // go back

        atom_name.copy_from((const char*)data + 4, 4);
        atom_size.big_endian(data, 4);
        m_m4aHdr.sizeof_minf -= atom_size.to_uint32(16);

        if(atom_name.equals("stbl")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_stbl = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_STBL;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_MDHD) { // mdhd
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("mdhd size remain %i", m_m4aHdr.sizeof_mdhd);
        if(m_m4aHdr.sizeof_mdhd == 0) {m_controlCounter = M4A_MDIA; return 0;} // go back

        ps_ptr<char> mdhd_buffer("mdhd_buffer"); // read ESDS content in a buffer
        mdhd_buffer.copy_from((char*)data, m_m4aHdr.sizeof_mdhd); // read MDHD content (without header)
    //    mdhd_buffer.hex_dump(m_m4aHdr.sizeof_mdhd);
         /* version;           1 Byte  offset 0   0 -> 32 bit, 1 -> 64 bit
            flags[3];          3 Bytes offset 1
            creation_time;     4 Bytes offset 4
            modification_time; 4 Bytes offset 8
            timescale;         4 Bytes offset 12
            duration;          4 Bytes offset 16
            language;          2 Bytes offset 20
            pre_defined;       2 Bytes offset 22 */
        m_m4aHdr.timescale = bigEndian((uint8_t*)mdhd_buffer.get() + 12, 4);
        m_m4aHdr.duration  = bigEndian((uint8_t*)mdhd_buffer.get() + 16, 4);
        if(m_m4aHdr.timescale){
            m_audioFileDuration = m_m4aHdr.duration / m_m4aHdr.timescale;
            AUDIO_INFO("Duration: %u (s)", m_audioFileDuration);
        }
        m_m4aHdr.retvalue += m_m4aHdr.sizeof_mdhd;
        m_m4aHdr.headerSize += m_m4aHdr.sizeof_mdhd;
        m_controlCounter = M4A_MDIA;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_STBL) { // minf
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("stbl size remain %i", m_m4aHdr.sizeof_stbl);
        if(m_m4aHdr.sizeof_stbl == 0) {m_controlCounter = M4A_MINF; return 0;} // go back

        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);
        m_m4aHdr.sizeof_stbl -= atom_size.to_uint32(16);

        if(atom_name.equals("stsd")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            uint8_t header_size = 8;
            m_m4aHdr.sizeof_stsd = atom_size.to_uint32(16) - 8 - header_size;
            m_m4aHdr.retvalue += 8 + header_size;
            m_m4aHdr.headerSize += 8 + header_size;
            m_controlCounter = M4A_STSD;
            return 0;
        }

        if(atom_name.equals("stsz")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            uint8_t header_size = 8;
            m_m4aHdr.sizeof_stsz = atom_size.to_uint32(16) - 8 - header_size;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_STSZ;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_STSD){
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("stsd size remain %i", m_m4aHdr.sizeof_stsd);
        if(m_m4aHdr.sizeof_stsd == 0) {m_controlCounter = M4A_STBL; return 0;} // go back

        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);
        m_m4aHdr.sizeof_stsd -= atom_size.to_uint32(16);

        if(atom_name.equals("mp4a")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_mp4a = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_MP4A;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_MP4A){
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("mp4a size remain %i", m_m4aHdr.sizeof_mp4a);
        if(m_m4aHdr.sizeof_mp4a == 0) {m_controlCounter = M4A_STSD; return 0;} // go back

        if(!m_m4aHdr.sample_rate){ // read the header first
            // data[0]...[5] reserved
            // data[6] & [7] Data reference index
            // data[8]...[15] reserved
            m_m4aHdr.channel_count = data[16] * 256 + data[17]; // /*AUDIO_LOG_DEBUG*/AUDIO_INFO("channels %i", m_m4aHdr.channel_count);
            m_m4aHdr.sample_size = data [18] *256 + data[19]; // /*AUDIO_LOG_DEBUG*/AUDIO_INFO("bit per sample %i", m_m4aHdr.sample_size);
            // data[20]...data[23] reserved
            m_m4aHdr.sample_rate = data[24] * 256 + data[25]; // /*AUDIO_LOG_DEBUG*/AUDIO_INFO("sample rate %i", m_m4aHdr.sample_rate);
            // data[26]...data[27] sample rate fixed point is 0x00, 0x00
            m_m4aHdr.offset = 28;
            m_m4aHdr.retvalue += m_m4aHdr.offset;
            m_m4aHdr.headerSize += m_m4aHdr.offset;
            m_m4aHdr.sizeof_mp4a -= m_m4aHdr.offset;
            return 0;
        }
        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);
        m_m4aHdr.sizeof_mp4a -= atom_size.to_uint32(16);

        if(atom_name.equals("esds")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_esds = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_ESDS;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_UDTA){ // udta
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("udta size remain %i", m_m4aHdr.sizeof_udta);
        if(m_m4aHdr.sizeof_udta == 0) {m_controlCounter = M4A_MOOV; return 0;} // go back

        atom_size.big_endian(data, 4);
        atom_name.copy_from((const char*)data + 4, 4);
        m_m4aHdr.sizeof_udta -= atom_size.to_uint32(16);

       if(atom_name.equals("meta")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_meta = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_META;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_META){ // meta
//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("meta size remain %i", m_m4aHdr.sizeof_meta);
        if(m_m4aHdr.sizeof_meta == 0) {m_controlCounter = M4A_UDTA; return 0;} // go back,  4bytes typ + 4 bytes size

        if(!m_m4aHdr.version_flags){
            //0x00, 0x00, 0x00, 0x94, 0x6D, 0x65, 0x74, 0x61, 0x00, 0x00, 0x00, 0x00,
            // size                 |   m    e     t     a  |     flags
            m_m4aHdr.version_flags = true;
            m_m4aHdr.sizeof_meta -= 4;
            m_m4aHdr.retvalue += 4;
            m_m4aHdr.headerSize += 4;
            idx += 4;
        }
        atom_size.big_endian(data + idx, 4);
        atom_name.copy_from((const char*)data + 4 + idx, 4);
        m_m4aHdr.sizeof_meta -= atom_size.to_uint32(16);

       if(atom_name.equals("ilst")){
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
            m_m4aHdr.sizeof_ilst = atom_size.to_uint32(16) - 8;
            m_m4aHdr.retvalue += 8;
            m_m4aHdr.headerSize += 8;
            m_controlCounter = M4A_ILST;
            return 0;
        }

//        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), m_m4aHdr.headerSize, atom_size.to_uint32(16), m_m4aHdr.headerSize + atom_size.to_uint32(16));
        m_m4aHdr.retvalue += atom_size.to_uint32(16);
        m_m4aHdr.headerSize += atom_size.to_uint32(16);
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_ESDS){ // Elementary Stream Descriptor
        ps_ptr<char> esds_buffer("esds_buffer"); // read ESDS content in a buffer
        esds_buffer.copy_from((char*)data, m_m4aHdr.sizeof_esds); // read ESDS content (without header)
        // esds_buffer.hex_dump(m_m4aHdr.sizeof_esds);

        // search for decoderConfigDescriptor (tag 0x04)
        int32_t dec_config_descriptor_offset = esds_buffer.special_index_of("\x04\x80\x80\x80", 4, (uint32_t) m_m4aHdr.sizeof_esds);
        if(dec_config_descriptor_offset > 0){ //decoderConfigDescriptor found
            uint8_t  dec_config_descriptor_length = ((uint8_t*)esds_buffer.get())[dec_config_descriptor_offset + 4]; // Length after Tag + 3 Extended Length Bytes
            m_m4aHdr.objectTypeIndicator = ((uint8_t*)esds_buffer.get())[dec_config_descriptor_offset + 5];  // 0x40 (AAC)
            m_m4aHdr.streamType = ((uint8_t*)esds_buffer.get())[dec_config_descriptor_offset + 6]; // 0x05 (Audio)
            m_m4aHdr.bufferSizeDB = bigEndian((uint8_t*)esds_buffer.get() + dec_config_descriptor_offset + 7, 3); // 24 bit
            m_m4aHdr.maxBitrate = bigEndian((uint8_t*)esds_buffer.get() + dec_config_descriptor_offset + 10, 4); // 32 bit
            m_m4aHdr.nomBitrate = bigEndian((uint8_t*)esds_buffer.get() + dec_config_descriptor_offset + 14, 4); // 32 bit
            // AUDIO_INFO("maxBitrate %u, nominalBitrate %u", m_m4aHdr.maxBitrate, m_m4aHdr.nomBitrate);
        }

        // search for decoderspecificinfo (tag 0x05)
        int32_t dec_specific_offset = esds_buffer.special_index_of("\x05\x80\x80\x80", 4, m_m4aHdr.sizeof_esds);
        if (dec_specific_offset >= 0) {// decoderSpecificInfo found
            uint8_t dec_specific_length = ((uint8_t*)esds_buffer.get())[dec_specific_offset + 4]; // Länge nach Tag + 3 Extended Length Bytes
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("DecoderSpecificInfo found at offset %d, length: %u", dec_specific_offset, dec_specific_length);

            // extract decoderSpecificInfo-data
            ps_ptr<char> dec_specific_data("dec_specific_data");
            dec_specific_data.alloc(dec_specific_length);
            memcpy(dec_specific_data.get(), (uint8_t*)esds_buffer.get() + dec_specific_offset + 5, dec_specific_length);
            m_m4aHdr.aac_profile = (uint8_t)dec_specific_data.get()[0] >> 3;
            if(m_m4aHdr.aac_profile > 4) {AUDIO_ERROR("unsupported AAC Profile %i", m_m4aHdr.aac_profile); stopSong(); return 0;}
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("DecoderSpecificInfo data: 0x%02X 0x%02X", (uint8_t)dec_specific_data.get()[0], (uint8_t)dec_specific_data.get()[1]);
            char profile[5][33] = {"unknown", "AAC Main", "AAC LC (Low Complexity)", "AAC SSR (Scalable Sample Rate)", "AAC LTP (Long Term Prediction)"};
            AUDIO_INFO("AAC Profile: %s", profile[m_m4aHdr.aac_profile]);
            AUDIO_INFO("AAC Channels; %i", m_m4aHdr.channel_count);
            AUDIO_INFO("AAC Sample Rate: %i", m_m4aHdr.sample_rate);
            AUDIO_INFO("AAC Bits Per Sample: %i", m_m4aHdr.sample_size);
            m_M4A_chConfig = m_m4aHdr.channel_count;
            m_M4A_sampleRate = m_m4aHdr.sample_rate;
            m_M4A_objectType = m_m4aHdr.aac_profile;
        } else {
            AUDIO_ERROR("No DecoderSpecificInfo found in esds");
        }
        m_m4aHdr.retvalue += m_m4aHdr.sizeof_esds;
        m_m4aHdr.headerSize += m_m4aHdr.sizeof_esds;
        m_controlCounter = M4A_MP4A;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_ILST){

        auto parse_m4a_timestamp = [&](const char* s){
            if (!s || *s != '[') return -1;
            int mm = 0, ss = 0, hh = 0;
            if (sscanf(s, "[%d:%d.%d]", &mm, &ss, &hh) == 3) {
                return mm * 60000 + ss * 1000 + hh * 10;
            }
            return -1;
        };

        struct TagInfo { // Definition of the Taginfo structure for iTunes-style metadata
            const uint8_t tag[4];
            const char* name;
            const char* descr;
        };
        const TagInfo tags[] = { // List of all usual tags
            {{ 0xA9, 0x6E, 0x61, 0x6D }, "©nam", "Title"},
            {{ 0xA9, 0x41, 0x52, 0x54 }, "©ART", "Artist"},
            {{ 0xA9, 0x61, 0x72, 0x74 }, "©art", "Artist"},
            {{ 0xA9, 0x61, 0x6C, 0x62 }, "©alb", "Album"},
            {{ 0xA9, 0x74, 0x6F, 0x6F }, "©too", "Encoder"},
            {{ 0xA9, 0x63, 0x6D, 0x74 }, "©cmt", "Comment"},
            {{ 0xA9, 0x77, 0x72, 0x74 }, "©wrt", "Composer"},
            {{ 0x74, 0x6D, 0x70, 0x6F }, "tmpo", "Tempo (BPM)"},
            {{ 0x74, 0x72, 0x6B, 0x6E }, "trkn", "Track-Number"},
            {{ 0xA9, 0x64, 0x61, 0x79 }, "©day", "Year"},
            {{ 0x63, 0x70, 0x69, 0x6C }, "cpil", "Compilation-Flag"},
            {{ 0x61, 0x41, 0x52, 0x54 }, "aART", "Album Artist"},
            {{ 0xA9, 0x67, 0x65, 0x6E }, "©gen", "Genre"},
            {{ 0x63, 0x6F, 0x76, 0x72 }, "covr", "Cover Art"},
            {{ 0x64, 0x69, 0x73, 0x6B }, "disk", "Disk-Nummer"},
            {{ 0xA9, 0x6C, 0x79, 0x72 }, "©lyr", "Songtext"},
            {{ 0xA9, 0x70, 0x72, 0x74 }, "cprt", "Copyright"},
            {{ 0x67, 0x6E, 0x72, 0x65 }, "gnre", "Genre-ID"},
            {{ 0x72, 0x74, 0x6E, 0x67 }, "rtng", "Evaluation"},
            {{ 0x70, 0x67, 0x61, 0x70 }, "pgap", "Gapless Playback"},
        };
        const size_t tags_count = sizeof(tags) / sizeof(tags[0]); // Number of tags

        ps_ptr<char>id3tag("id3tag");
        ps_ptr<char>lyricsBuffer("lyricsBuffer");
        uint32_t pos = m_m4aHdr.headerSize;
        uint32_t consumed = 0;
        while(true){
            atom_size.big_endian(data + consumed, 4);
            atom_name.copy_from((const char*)data + 4 + consumed, 4);
            uint32_t as = atom_size.to_uint32(16);
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("atom %s @ %i, size: %i, ends @ %i", atom_name.c_get(), pos, as, pos + as);
            m_m4aHdr.ilst_pos += as;
            pos += as;
            consumed += as;


            // 0x00, 0x00, 0x00, 0x1C, 0xA9, 0x64, 0x61, 0x79, 0x00, 0x00, 0x00, 0x14, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x32, 0x30, 0x32, 0x32,
            //     sub atom length   |   ©    d     a     y  |  sub sub atom length  |  d     a     t     a  | data type   1->UTF-8  |   reserved            |  2     0     2     2

            ps_ptr<char>sa("sa"); // sub atom
//            sa.copy_from((const char*)data + consumed - as, min(as, 1024));
            sa.copy_from((const char*)data + consumed - as, (as<1024?as:1024));

            char san [5] = {0}; // aub atom name
            char ssan[5] = {0}; // sub sub atom name (should be 'data')
            strncpy(san, &sa[4], 4);
            strncpy(ssan, &sa[12],4);
            uint32_t ssal = bigEndian((uint8_t*)&sa[8], 4); // sub sub atom length
            uint32_t dty  = bigEndian((uint8_t*)&sa[16], 4); // data type 1-UTF8
            if(strncmp(ssan, "data", 4) == 0){
                for(int i = 0; i < tags_count; i++){
                    if(memcmp(san, tags[i].tag, 4) == 0){
                        id3tag.reset();
                        if     (dty == 0 && strlen(&sa[24]) > 0) id3tag.assignf("%s: %i", tags[i].descr, &sa[24]); // binary
                        else if(dty == 1 && strlen(&sa[24]) > 0) id3tag.assignf("%s: %s", tags[i].descr, &sa[24]); // UTF-8 Text
                        else if(dty == 0x0D) {m_m4aHdr.picLen = as - 24; m_m4aHdr.picPos = pos + 24 - as; /*AUDIO_LOG_DEBUG*/AUDIO_INFO("cover jpeg start: %lu, len %lu", m_m4aHdr.picPos, m_m4aHdr.picLen);}  // jpeg
                        else if(dty == 0x0E) {m_m4aHdr.picLen = as - 24; m_m4aHdr.picPos = pos + 24 - as; /*AUDIO_LOG_DEBUG*/AUDIO_INFO("cover png start: %lu, len %lu", m_m4aHdr.picPos, m_m4aHdr.picLen);}   // png
                        else if(dty == 21){
                            if(memcmp(tags[i].tag, "cpil", 4) == 0) {break;} // Compilation Flag
                            if(memcmp(tags[i].tag, "pgap", 4) == 0) {break;} // Gapless Playback
                            if(memcmp(tags[i].tag, "rtng", 4) == 0) {break;} // Evaluation
                        }
                        if(id3tag.valid()) {/*info(evt_id3data,*/ audio_id3data(id3tag.get());}
                        if(strcmp(tags[i].descr, "Songtext") == 0){
                            lyricsBuffer.copy_from(&sa[24]);
                        }
                        break;
                    }
                }
            }
            else  /*AUDIO_LOG_DEBUG*/AUDIO_INFO("%s tag not supported", san);

            if(consumed > len) {
                m_m4aHdr.retvalue = consumed;
                m_m4aHdr.headerSize += consumed;
                return 0;
            }

            if(m_m4aHdr.sizeof_ilst <= m_m4aHdr.ilst_pos){

                ps_ptr<char> tmp(__LINE__);   // last todo if we have lyrics
                ps_ptr<char> timestamp(__LINE__);
                timestamp.alloc(12);
                if(lyricsBuffer.valid()){
                    lyricsBuffer.remove_prefix("LYRICS=");
                    idx = 0;
                    while(idx < lyricsBuffer.size()){
                        int pos = lyricsBuffer.index_of('\n', idx);
                        if(pos == - 1) break;
                        int len = pos - idx + 1;
                        tmp.copy_from(lyricsBuffer.get() + idx, len);
                        idx += len;
                        if(tmp.ends_with("\n")) tmp.truncate_at('\n');
                        // tmp content e.g.: [00:27.07]Jetzt kommt die Zeit
                        //                   [00:28.84]Auf die ihr euch freut
                        timestamp.copy_from(tmp.get(), 10);

                        int ms = parse_m4a_timestamp(timestamp.c_get());

                        // timestamp.remove_chars("[]:.");
                        // timestamp.append("0"); // to ms 0028840
                        tmp.remove_before(10, true);
                        if(tmp.strlen() > 0){
                            m_syltLines.push_back(std::move(tmp));
                            m_syltTimeStamp.push_back(ms);
                        }
                    }
                    AUDIO_INFO("audiofile contains synchronized lyrics");
                    // for(int i = 0; i < m_syltLines.size(); i++){
                    //     info(evt_lyrics, "%07i ms,   %s", m_syltTimeStamp[i], m_syltLines[i].c_get());
                    // }
                }

                m_m4aHdr.retvalue = consumed;
                m_m4aHdr.headerSize += consumed;
                m_controlCounter = M4A_META;
                break;
            }
        }
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_controlCounter == M4A_STSZ){
        uint8_t version = data[0]; (void)version;
        uint32_t flags = bigEndian(data + 1, 3); (void)flags;
        uint32_t sample_size = bigEndian(data + 4, 4); (void)sample_size;
        m_m4aHdr.stsz_num_entries = bigEndian(data + 8, 4);
        m_m4aHdr.stsz_table_pos = m_m4aHdr.headerSize + 12;
        m_m4aHdr.retvalue += m_m4aHdr.sizeof_stsz + 8;
        m_m4aHdr.headerSize += m_m4aHdr.sizeof_stsz + 8;
        m_controlCounter = M4A_STBL;
        return 0;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    uint8_t extLen = 0;
    if(m_controlCounter == M4A_MDAT) {            // mdat
        m_audioDataSize = m_m4aHdr.sizeof_mdat; // length of this atom

        // Extended Size
        // 00 00 00 01 6D 64 61 74 00 00 00 00 00 00 16 64
        //        0001  m  d  a  t                    5732

        if(m_audioDataSize == 1){ // Extended Size
            m_audioDataSize = bigEndian(data + 8, 8);
            m_audioDataSize -= 16;
            extLen = 8;
        }
        else m_audioDataSize -= 8;
        AUDIO_INFO("Audio-Length: %i", m_audioDataSize);
        m_m4aHdr.retvalue = extLen;
        m_m4aHdr.headerSize += extLen;
        m_controlCounter = M4A_AMRDY; // last step before starting the audio
        return 0;
    }

    if(m_controlCounter == M4A_AMRDY) { // almost ready
        m_audioDataStart = m_m4aHdr.headerSize;
        if(m_m4aHdr.picLen) {
            size_t pos = m_audioFilePosition;
            std::vector<uint32_t> vec;
            vec.push_back(m_m4aHdr.picPos);
            vec.push_back(m_m4aHdr.picLen);
//            info(evt_image, vec);
            vec.clear();
            audioFileSeek(pos); // the filepointer could have been changed by the user, set it back
        }
        m_stsz_numEntries = m_m4aHdr.stsz_num_entries;
        m_stsz_position = m_m4aHdr.stsz_table_pos;
        if(m_audioFileDuration){
            m_nominal_bitrate = (m_audioDataSize * 8) / m_audioFileDuration;
        AUDIO_INFO("Duration: %u (s)", m_audioFileDuration);
        AUDIO_INFO("BitRate: %lu", m_nominal_bitrate);
//        audio_bitrate(m_nominal_bitrate);
        }

        m_controlCounter = M4A_OKAY; // that's all
        return 0;
    }
    // this section should never be reached
    AUDIO_ERROR("error");
    return 0;
}
//###################################################################
size_t Audio::process_m3u8_ID3_Header(uint8_t* packet) {
    uint8_t  ID3version;
    size_t   id3Size;
    bool     m_f_unsync = false, m_f_exthdr = false;
    uint64_t current_timestamp = 0;

    (void)m_f_unsync;        // suppress -Wunused-variable
    (void)current_timestamp; // suppress -Wunused-variable

    if(specialIndexOf(packet, "ID3", 4) != 0) { // ID3 not found
        // AUDIO_INFO("m3u8 file has no mp3 tag");
        return 0; // error, no ID3 signature found
    }
    ID3version = *(packet + 3);
    switch(ID3version) {
        case 2:
            m_f_unsync = (*(packet + 5) & 0x80);
            m_f_exthdr = false;
            break;
        case 3:
        case 4:
            m_f_unsync = (*(packet + 5) & 0x80); // bit7
            m_f_exthdr = (*(packet + 5) & 0x40); // bit6 extended header
            break;
    };
    id3Size = bigEndian(&packet[6], 4, 7); //  ID3v2 size  4 * %0xxxxxxx (shift left seven times!!)
    id3Size += 10;
    // AUDIO_INFO("ID3 framesSize: %i", id3Size);
    // AUDIO_INFO("ID3 version: 2.%i", ID3version);

    if(m_f_exthdr) {
        AUDIO_ERROR("ID3 extended header in m3u8 files not supported");
        return 0;
    }
    // AUDIO_INFO("ID3 normal frames");

    if(specialIndexOf(&packet[10], "PRIV", 5) != 0) { // tag PRIV not found
        AUDIO_ERROR("tag PRIV in m3u8 Id3 Header not found");
        return 0;
    }
    // if tag PRIV exists assume content is "com.apple.streaming.transportStreamTimestamp"
    // a time stamp is expected in the header.

    current_timestamp = (double)bigEndian(&packet[69], 4) / 90000; // seconds

    return id3Size;
}
//###################################################################
uint32_t Audio::stopSong() {
    m_f_lockInBuffer = true; // wait for the decoding to finish
        uint8_t maxWait = 0;
        while(m_f_audioTaskIsDecoding) {vTaskDelay(1); maxWait++; if(maxWait > 100) break;} // in case of error wait max 100ms
        uint32_t currTime = getAudioCurrentTime();
        uint32_t pos = 0;
        if(m_f_running) {
            m_f_running = false;
            if(m_client->connected()){
                AUDIO_INFO("Closing web file \"%s\"", m_lastHost.c_get());
                m_client->stop();
            }
            if(m_audiofile) {
               AUDIO_INFO("Closing audio file \"%s\"", m_audiofile.name());
               pos = m_audioFilePosition - inBufferFilled();
               m_audiofile.close();
            }
        }
    uint16_t modereg; 					// Read from mode register
    int i; 							// Loop control

    sdi_send_fillers(2052); 			//  sdi_send_fillers(vs1053_chunk_size * 54);
    delay(10);
    write_register(SCI_MODE, _BV (SM_SDINEW) | _BV(SM_CANCEL));
    for(i=0; i < 200; i++) {
        sdi_send_fillers(32);
        modereg = read_register(SCI_MODE);  			// Read status
        if((modereg & _BV(SM_CANCEL)) == 0) {
            sdi_send_fillers(2052);
            AUDIO_INFO("Song stopped correctly after %d msec", i * 10);
//            return;
            goto exit;
        }
        delay(10);
    }
    AUDIO_INFO("Song stopped incorrectly!");
    printDetails("after song stopped incorrectly");

exit:
        if(m_codec == CODEC_MP3) MP3Decoder_FreeBuffers();
//        if(m_codec == CODEC_AAC) AACDecoder_FreeBuffers();
//        if(m_codec == CODEC_M4A) AACDecoder_FreeBuffers();
        if(m_codec == CODEC_FLAC) FLACDecoder_FreeBuffers();
//        if(m_codec == CODEC_OPUS) OPUSDecoder_FreeBuffers();
        if(m_codec == CODEC_VORBIS) VORBISDecoder_FreeBuffers();
        m_validSamples = 0;
        m_audioCurrentTime = 0;
        m_audioFileDuration = 0;
        m_codec = CODEC_NONE;
        m_dataMode = AUDIO_NONE;
        m_streamType = ST_NONE;
        m_playlistFormat = FORMAT_NONE;
        m_f_lockInBuffer = false;
//    return currTime;
    return pos;
}
//###################################################################
bool Audio::pauseResume() {
    xSemaphoreTake(mutex_audioTask, 0.3 * configTICK_RATE_HZ);
    bool retVal = false;
    if(m_dataMode == AUDIO_LOCALFILE || m_streamType == ST_WEBSTREAM || m_streamType == ST_WEBFILE) {
        m_f_running = !m_f_running;
        retVal = true;
        if(!m_f_running) {
            memset(m_outBuff.get(), 0, m_outbuffSize * sizeof(int16_t)); // Clear OutputBuffer
//            memset(m_samplesBuff48K.get(), 0, m_samplesBuff48KSize * sizeof(int16_t)); // Clear SamplesBuffer
            m_validSamples = 0;
        }
    }
    xSemaphoreGive(mutex_audioTask);
    return retVal;
}
//###################################################################
void Audio::startSong(){
    sdi_send_fillers(2052);
//    sdi_send_fillers(vs1053_chunk_size * 54);
}
//###################################################################
void Audio::printDetails(const char* str){

    if(strlen(str) && audio_info) AUDIO_INFO(str);

    char decbuf[16][6];
    char hexbuf[16][5];
    char binbuf[16][17];
    uint8_t i;

    const char regName[16][12] = {
        "MODE       ", "STATUS     ", "BASS       ", "CLOCKF     ",
        "DECODE_TIME", "AUDATA     ", "WRAM       ", "WRAMADDR   ",
        "HDAT0      ", "HDAT1      ", "AIADDR     ", "VOL        ",
        "AICTRL0    ", "AICTRL1    ", "AICTRL2    ", "AICTRL3    ",
    };

    for(i=0; i <= SCI_AICTRL3; i++){
        sprintf(hexbuf[i], "%04X", read_register(i));
        sprintf(decbuf[i], "%05d", read_register(i));

        uint16_t tmp   = read_register(i);
        uint16_t shift = 0x8000;
        for(int8_t j = 0; j < 16; j++){
            binbuf[i][j] = (tmp & shift ? '1' : '0');
            shift >>= 1;
        }
        binbuf[i][16] = '\0';
    }

    if(audio_info) AUDIO_INFO("REG            dec      bin               hex");
    if(audio_info) AUDIO_INFO("-----------  -------  ----------------  -------");

    for(i=0; i <= SCI_AICTRL3; i++){
        if(audio_info) AUDIO_INFO("%s   %s   %s   %s", regName[i], decbuf[i], binbuf[i], hexbuf[i]);
    }
}
//###################################################################
uint8_t Audio::printVersion(){
    uint16_t reg = wram_read(0x1E02) & 0xFF;
    return reg;
}

uint32_t Audio::printChipID(){
    uint32_t chipID = 0;
    chipID =  wram_read(0x1E00) << 16;
    chipID += wram_read(0x1E01);
    return chipID;
}
//###################################################################
void Audio::loop() {
    if(!m_f_running) return;

    if(m_playlistFormat != FORMAT_M3U8) { // normal process
        switch(m_dataMode) {
            case AUDIO_LOCALFILE:
                processLocalFile(); break;
            case HTTP_RESPONSE_HEADER:
                if(!parseHttpResponseHeader()) {
                    if(m_f_timeout && m_lVar.count < 3) {m_f_timeout = false; m_lVar.count++; connecttohost(m_lastHost.get());}
                }
                else{
                    m_lVar.count = 0;
                }
                break;
            case AUDIO_PLAYLISTINIT: readPlayListData(); break;
            case AUDIO_PLAYLISTDATA:
                if(m_playlistFormat == FORMAT_M3U) httpPrint(parsePlaylist_M3U());
                if(m_playlistFormat == FORMAT_PLS) httpPrint(parsePlaylist_PLS());
                if(m_playlistFormat == FORMAT_ASX) httpPrint(parsePlaylist_ASX());
                break;
            case AUDIO_DATA:
                if(m_streamType == ST_WEBSTREAM) processWebStream();
                if(m_streamType == ST_WEBFILE)   processWebFile();
                break;
        }
    }
    else { // m3u8 datastream only
        ps_ptr<char> host("host");
        if(m_lVar.no_host_timer > millis()) {return;}
        switch(m_dataMode) {
            case HTTP_RESPONSE_HEADER:
                if(!parseHttpResponseHeader()) {
                    if(m_f_timeout && m_lVar.count < 3) {m_f_timeout = false; m_lVar.count++; m_f_reset_m3u8Codec = false; connecttohost(m_lastHost.get());}
                }
                else{
                    m_lVar.count = 0;
                    m_f_firstCall  = true;
                }
                break;
            case AUDIO_PLAYLISTINIT:
                if(readPlayListData()) break;
                else { // readPlayListData == false means connect to m3u8 URL
                    if(m_lastM3U8host.valid()) {m_f_reset_m3u8Codec = false; httpPrint(m_lastM3U8host.get());}
                    else                       {httpPrint(m_lastHost.get());}      // if url has no first redirection
                    m_dataMode = HTTP_RESPONSE_HEADER;                             // we have a new playlist now
                   break;
                }
            case AUDIO_PLAYLISTDATA:
                host = parsePlaylist_M3U8();
                if(!host.valid()) m_lVar.no_host_cnt++;
                else {m_lVar.no_host_cnt = 0; m_lVar.no_host_timer = millis();}

                if(m_lVar.no_host_cnt == 2){m_lVar.no_host_timer = millis() + 2000;} // no new url? wait 2 seconds
                if(host.valid()) { // host contains the next playlist URL
                    httpPrint(host.get());
                    m_dataMode = HTTP_RESPONSE_HEADER;
                }
                else { // host == NULL means connect to m3u8 URL
                    if(m_lastM3U8host.valid()) {m_f_reset_m3u8Codec = false; httpPrint(m_lastM3U8host.get());}
                    else                       {httpPrint(m_lastHost.get());}      // if url has no first redirection
                    m_dataMode = HTTP_RESPONSE_HEADER;               // we have a new playlist now
                }
                break;
            case AUDIO_DATA:
                if(m_f_ts) { processWebStreamTS(); } // aac or aacp with ts packets
                else { processWebStreamHLS(); }      // aac or aacp normal stream

                if(m_f_continue) { // at this point m_f_continue is true, means processWebStream() needs more data
                    m_dataMode = AUDIO_PLAYLISTDATA;
                    m_f_continue = false;
                }
                break;
        }
    }
}
//###################################################################
bool Audio::readPlayListData() {

    uint32_t     chunksize = 0;
    uint16_t     readedBytes = 0;
    ps_ptr<char> pl("pl");
    uint32_t     ctl = 0;
    uint16_t     plSize = 0;

    auto detectTimeout = [&]() -> bool{
        uint32_t t = millis();
        while(!m_client->available()) {
            vTaskDelay(2);
            if(t + 1000 < millis()) {
                /*AUDIO_LOG_WARN*/AUDIO_INFO("Playlist is incomplete, fetch again");
                if(m_f_chunked) getChunkSize(0, true);
                return true;
            }
        }
        return false;
    };

    if(m_dataMode != AUDIO_PLAYLISTINIT) {AUDIO_ERROR("wrong datamode %s", dataModeStr[m_dataMode]); goto exit;}

    getChunkSize(0, true);
    if(m_f_chunked) chunksize = getChunkSize(&readedBytes);
    plSize = max(m_audioFileSize, chunksize);

    if(!plSize){ // maybe playlist without contentLength or chunkSize
        if(detectTimeout()) goto exit;
        plSize = m_client->available();
    }

    // delete all memory in m_playlistContent
    if(m_playlistFormat == FORMAT_M3U8 && !psramFound()) { AUDIO_ERROR("m3u8 playlists requires PSRAM enabled!"); }
    vector_clear_and_shrink(m_playlistContent);

    while(true) { // outer while
        uint32_t ctime = millis();
        uint32_t timeout = 2000; // ms
        pl.alloc(1024); pl.clear(); // playlistLine

        while(true) { // inner while
            uint16_t pos = 0;
            while(true) { // super inner while :-))
                uint32_t t = millis();
                if(ctl == plSize) break;
                if(detectTimeout()) goto exit;
                pl[pos] = audioFileRead();
                ctl++;
                if(pl[pos] == '\n') {pl[pos] = '\0'; pos++; break;}
                if(pl[pos] == '\r') {pl[pos] = '\0'; pos++; continue;}
                pos++;
                if(pos == 1022)   {pos--; continue;}
                if(ctl == plSize) {pl[pos] = '\0'; break;}
            }
            if(pos) {
                pl[pos] = '\0';
                break;
            }
            if(ctl == plSize) break;
            if(detectTimeout()) goto exit;
        } // inner while

        if(pl.starts_with_icase("<!DOCTYPE")) {
            AUDIO_ERROR("url is a webpage!");
            goto exit;
        }
        if(pl.starts_with_icase("<html")) {
            AUDIO_ERROR("url is a webpage!");
            goto exit;
        }
        // AUDIO_INFO("current playlist line: %s", pl.get());
        if(pl.size() > 0) m_playlistContent.emplace_back(std::move(pl));


        // termination conditions
        // 1. The http response header returns a value for contentLength -> read chars until contentLength is reached
        // 2. no contentLength, but Transfer-Encoding:chunked -> compute chunksize and read until chunksize is reached
        // 3. no chunksize and no contentlengt, but Connection: close -> read all available chars
        if(ctl == plSize) {
            break;
        }
    } // outer while

    if(m_f_chunked) getChunkSize(&readedBytes); // expected: "\r\n\0\r\n\r\n"
    m_dataMode = AUDIO_PLAYLISTDATA;
    return true;

exit:
    vector_clear_and_shrink(m_playlistContent);
    getChunkSize(0, true);
    return false;
}
//##################################################################
const char* Audio::parsePlaylist_M3U() {

    uint8_t lines = m_playlistContent.size();
    int     pos = 0;
    char*   host = nullptr;

    for(int i = 0; i < lines; i++) {
       // m_playlistContent[i].println();
        if(m_playlistContent[i].contains("#EXTINF:")) { // Info?
            pos = m_playlistContent[i].index_of(",");        // Comma in this line?
            if(pos > 0) {
                // Show artist and title if present in metadata
                /*info(evt_id3data,*/ audio_id3data(m_playlistContent[i].get() + pos + 1);
            }
            continue;
        }
        if(m_playlistContent[i].starts_with("#")) { // Commentline?
            continue;
        }

        pos = m_playlistContent[i].index_of("http://:@", 0); // ":@"??  remove that!
        if(pos >= 0) {
            AUDIO_INFO("Entry in playlist found: %s", (m_playlistContent[i].get() + pos + 9));
            host = m_playlistContent[i].get() + pos + 9;
            break;
        }
        // AUDIO_INFO("Entry in playlist found: %s", pl);
        pos = m_playlistContent[i].index_of("http", 0); // Search for "http"
        if(pos >= 0) {                                  // Does URL contain "http://"?
                                                        //    AUDIO_ERROR(""%s pos=%i", m_playlistContent[i], pos);
            host = m_playlistContent[i].get() + pos;          // Yes, set new host
            break;
        }
    }
    //    vector_clear_and_shrink(m_playlistContent);
    return host;
}
//###################################################################
const char* Audio::parsePlaylist_PLS() {
    uint8_t lines = m_playlistContent.size();
    int     pos = 0;
    char*   host = nullptr;

    for(int i = 0; i < lines; i++) {
        if(i == 0) {
            if(m_playlistContent[0].strlen() == 0) goto exit;     // empty line
            if(!m_playlistContent[0].starts_with("[playlist]")) { // first entry in valid pls
                m_dataMode = HTTP_RESPONSE_HEADER;                // pls is not valid
                AUDIO_INFO("Playlist is not valid, switch to HTTP_RESPONSE_HEADER");
                goto exit;
            }
            continue;
        }
        if(m_playlistContent[i].starts_with("File1")) {
            if(host) continue;                              // we have already a url
            pos = m_playlistContent[i].index_of("http", 0); // File1=http://streamplus30.leonex.de:14840/;
            if(pos >= 0) {                                  // yes, URL contains "http"?
                host = m_playlistContent[i].get() + pos;          // Now we have an URL for a stream in host.
            }
            continue;
        }
        if(m_playlistContent[i].starts_with("Title1")) { // Title1=Antenne Tirol
            const char* plsStationName = (m_playlistContent[i].get() + 7);
//            info(evt_name, plsStationName);
            continue;
        }
        if(m_playlistContent[i].starts_with("Length1")) { continue; }
        if(m_playlistContent[i].contains("Invalid username")) { // Unable to access account:
            goto exit;                                          // Invalid username or password
        }
    }
    return host;

exit:
    m_f_running = false;
    stopSong();
    vector_clear_and_shrink(m_playlistContent);
    m_dataMode = AUDIO_NONE;
    return nullptr;
}
//##################################################################
const char* Audio::parsePlaylist_ASX() { // Advanced Stream Redirector
    uint8_t lines = m_playlistContent.size();
    bool    f_entry = false;
    int     pos = 0;
    char*   host = nullptr;

    for(int i = 0; i < lines; i++) {
        int p1 = m_playlistContent[i].index_of("<", 0);
        int p2 = m_playlistContent[i].index_of(">", 1);
        if(p1 >= 0 && p2 > p1) { // #196 set all between "< ...> to lowercase
            for(uint8_t j = p1; j < p2; j++) { m_playlistContent[i][j] = toLowerCase(m_playlistContent[i][j]); }
        }
        if(m_playlistContent[i].contains("<entry>")) f_entry = true; // found entry tag (returns -1 if not found)
        if(f_entry) {
            if(m_playlistContent[i].contains("ref href")) { //  <ref href="http://87.98.217.63:24112/stream" />
                pos = m_playlistContent[i].index_of("http", 0);
                if(pos > 0) {
                    host = (m_playlistContent[i].get() + pos); // http://87.98.217.63:24112/stream" />
                    int pos1 = indexOf(host, "\"", 0);   // http://87.98.217.63:24112/stream
                    if(pos1 > 0) host[pos1] = '\0';      // Now we have an URL for a stream in host.
                }
            }
        }
        pos = m_playlistContent[i].index_of("<title>", 0);
        if(pos >= 0) {
            char* plsStationName = (m_playlistContent[i].get() + pos + 7); // remove <Title>
            pos = indexOf(plsStationName, "</", 0);
            if(pos >= 0) {
                *(plsStationName + pos) = 0; // remove </Title>
            }
//            info(evt_name, plsStationName);
        }

        if(m_playlistContent[i].starts_with("http") && !f_entry) { // url only in asx
            host = m_playlistContent[i].get();
        }
    }
    return host;
}


//###################################################################
uint16_t Audio::accomplish_m3u8_url() {

    for(uint16_t i = 0; i < m_linesWithURL.size(); i++) {

        ps_ptr<char> tmp(__LINE__);

        if(!m_linesWithURL[i].starts_with("http")) {     //  playlist:   http://station.com/aaa/bbb/xxx.m3u8
                                                                 //  chunklist:  http://station.com/aaa/bbb/ddd.aac
                                                                 //  result:     http://station.com/aaa/bbb/ddd.aac
            if(m_lastM3U8host.valid()) {tmp.clone_from(m_lastM3U8host);}
            else {                      tmp.clone_from(m_lastHost);}

            if(m_linesWithURL[i][0] != '/'){             //  playlist:   http://station.com/aaa/bbb/xxx.m3u8  // tmp
                                                                 //  chunklist:  ddd.aac                              // m_linesWithURL[i]
                                                                 //  result:     http://station.com/aaa/bbb/ddd.aac   // m_linesWithURL[i]
                int idx = tmp.last_index_of('/');
                tmp[idx  + 1] = '\0';
                tmp.append(m_linesWithURL[i].get());
                m_linesWithURL[i].clone_from(tmp);
                continue;
            }
            else{                                                //  playlist:   http://station.com/aaa/bbb/xxx.m3u8
                                                                 //  chunklist:  /aaa/bbb/ddd.aac
                                                                 //  result:     http://station.com/aaa/bbb/ddd.aac
                int idx = tmp.index_of('/', 8);
                tmp[idx] = '\0';
                tmp.append(m_linesWithURL[i].get());
                m_linesWithURL[i].clone_from(tmp);
                continue;
            }
        }
        else { /* nothing todo*/
            continue;
        }
    }
    // for(uint16_t i = 0; i < m_linesWithURL.size(); i++) m_linesWithURL[i].println();
    return 0;
}
//###################################################################
int16_t Audio::prepare_first_m3u8_url(ps_ptr<char>& playlistBuff){
    // in m_lineswithURL, searches for the first new URL through the recent URL.
    // URLs that have already been used are removed from the DEQUE
    // If all URLs are new, there is nothing to do and 0 is returned.
    // no new URL is found -1 returned
    int idx = -1;
    for(int i = 0; i < m_linesWithURL.size(); i++){
        if(playlistBuff.equals(m_linesWithURL[i].get())) idx = i;
    }
    if(idx == -1){
        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("nothing found, all entries are new");
        return 0;
    }
    if(idx == m_linesWithURL.size()){
        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("only last entry found, nothing is new");
        return -1;
    }
    for(int j = 0; j < idx + 1; j++){
         m_linesWithURL.pop_front();
    }
    /*AUDIO_LOG_DEBUG*/AUDIO_INFO("%i entries are known and removed", idx + 1);
    return idx  + 1;
}
//###################################################################
ps_ptr<char> Audio::parsePlaylist_M3U8() {
    // example: audio chunks
    // #EXTM3U
    // #EXT-X-TARGETDURATION:10
    // #EXT-X-MEDIA-SEQUENCE:163374040
    // #EXT-X-DISCONTINUITY
    // #EXTINF:10,title="text=\"Spot Block End\" amgTrackId=\"9876543\"",artist=" ",url="length=\"00:00:00\""
    // http://n3fa-e2.revma.ihrhls.com/zc7729/63_sdtszizjcjbz02/main/163374038.aac
    // #EXTINF:10,title="text=\"Spot Block End\" amgTrackId=\"9876543\"",artist=" ",url="length=\"00:00:00\""
    // http://n3fa-e2.revma.ihrhls.com/zc7729/63_sdtszizjcjbz02/main/163374039.aac


    // #EXTM3U
    // #EXT-X-VERSION:3
    // #EXT-X-MEDIA-SEQUENCE:0
    // #EXT-X-TARGETDURATION:4
    // #EXTINF:3.997,90s90s - Rock
    // #EXT-X-PROGRAM-DATE-TIME:2025-08-17T14:08:21.088877044Z
    // https://hz71.streamabc.net/hls/d2gu4l4peavc72tgotd0/regc-90s90srock1436287-mp3-192-2191420/0.mp3
    // #EXTINF:3.997,90s90s - Rock
    // #EXT-X-PROGRAM-DATE-TIME:2025-08-17T14:08:24.088877044Z
    // https://hz71.streamabc.net/hls/d2gu4l4peavc72tgotd0/regc-90s90srock1436287-mp3-192-2191420/1.mp3
    // #EXTINF:3.997,90s90s - Rock
    // #EXT-X-PROGRAM-DATE-TIME:2025-08-17T14:08:28.088877044Z
    // https://hz71.streamabc.net/hls/d2gu4l4peavc72tgotd0/regc-90s90srock1436287-mp3-192-2191420/2.mp3
    // #EXTINF:3.997,90s90s - Rock
    // #EXT-X-PROGRAM-DATE-TIME:2025-08-17T14:08:32.088877044Z
    // https://hz71.streamabc.net/hls/d2gu4l4peavc72tgotd0/regc-90s90srock1436287-mp3-192-2191420/3.mp3


    if(!m_lastHost.valid())      {AUDIO_ERROR("last Host is NULL");     return {};} // guard

    uint8_t lines = m_playlistContent.size();
    bool    f_haveRedirection = false;
    char    llasc[21]; // uint64_t max = 18,446,744,073,709,551,615  thats 20 chars + \0

    if(lines){
        bool addNextLine = false;
        deque_clear_and_shrink(m_linesWithURL);
        vector_clear_and_shrink(m_linesWithEXTINF);
        for(uint8_t i = 0; i < lines; i++) {
            // AUDIO_INFO("pl%i = %s", i, m_playlistContent[i].get());
            if(m_playlistContent[i].starts_with("#EXT-X-STREAM-INF:")) { f_haveRedirection = true; /*AUDIO_ERROR("we have a redirection");*/}
            if(addNextLine) {
                if(startsWith(m_playlistContent[i].get(), "#EXT-X-PROGRAM-DATE-TIME:")) continue; // skip this line
                addNextLine = false;
                // size_t len = strlen(linesWithSeqNr[idx].get()) + strlen(m_playlistContent[i].get()) + 1;
                m_linesWithURL.emplace_back().clone_from(m_playlistContent[i]);
            }
            if(startsWith(m_playlistContent[i].get(), "#EXTINF:")) {
                m_linesWithEXTINF.emplace_back().clone_from(m_playlistContent[i]);
                addNextLine = true;
            }
        }
        if(!f_haveRedirection) {
            accomplish_m3u8_url();
            prepare_first_m3u8_url(m_playlistBuff);
            vector_clear_and_shrink(m_playlistContent);
        }
    }

    for(int i = 0; i < m_linesWithURL.size(); i++) {/*AUDIO_INFO("%s", m_linesWithURL[i].get())*/;}
    for(int i = 0; i < m_linesWithEXTINF.size(); i++)      {/*AUDIO_INFO("%s", m_linesWithEXTINF[i].get());*/ showstreamtitle(m_linesWithEXTINF[i].get());}

    if(f_haveRedirection) {
        m_lastM3U8host.clone_from(m3u8redirection(&m_m3u8Codec));
        vector_clear_and_shrink(m_playlistContent);
        return {};
    }

    if(m_f_firstM3U8call) {
        m_f_firstM3U8call = false;
        m_pplM3U8.xMedSeq = 0;
        m_pplM3U8.f_mediaSeq_found = false;
    }

    if(m_codec == CODEC_NONE) {m_codec = CODEC_AAC; if(m_m3u8Codec == CODEC_MP3) m_codec = CODEC_MP3;}  // if we have no redirection
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    if(m_linesWithURL.size() > 0) {
        ps_ptr<char>playlistBuff;
        if(m_linesWithURL[0].valid()) {
            playlistBuff.assign(m_linesWithURL[0].get());
            m_linesWithURL.pop_front();
            m_linesWithURL.shrink_to_fit();
        }
        /*AUDIO_LOG_DEBUG*/AUDIO_INFO("now playing %s", playlistBuff.get());
        if(endsWith(playlistBuff.get(), "ts")) m_f_ts = true;
        if(playlistBuff.contains(".ts?") > 0)  m_f_ts = true;
        m_playlistBuff.clone_from(playlistBuff);
        return playlistBuff;
    }
    return {};
}
//##################################################################

ps_ptr<char>Audio::m3u8redirection(uint8_t* codec) {
    // example: redirection
    // #EXTM3U
    // #EXT-X-STREAM-INF:BANDWIDTH=117500,AVERAGE-BANDWIDTH=117000,CODECS="mp4a.40.2"
    // 112/playlist.m3u8?hlssid=7562d0e101b84aeea0fa35f8b963a174
    // #EXT-X-STREAM-INF:BANDWIDTH=69500,AVERAGE-BANDWIDTH=69000,CODECS="mp4a.40.5"
    // 64/playlist.m3u8?hlssid=7562d0e101b84aeea0fa35f8b963a174
    // #EXT-X-STREAM-INF:BANDWIDTH=37500,AVERAGE-BANDWIDTH=37000,CODECS="mp4a.40.29"
    // 32/playlist.m3u8?hlssid=7562d0e101b84aeea0fa35f8b963a174

    if(!m_lastHost.valid()) {AUDIO_ERROR("last Host is empty"); return {};} // guard
    const char codecString[9][11]={
        "mp4a.40.34", // mp3 stream
        "mp4a.40.01", // AAC Main
        "mp4a.40.2",  // MPEG-4 AAC LC
        "mp4a.40.02", // MPEG-4 AAC LC, leading 0 for Aud-OTI compatibility
        "mp4a.40.29", // MPEG-4 HE-AAC v2 (AAC LC + SBR + PS)
        "mp4a.40.42", // xHE-AAC
        "mp4a.40.5",  // MPEG-4 HE-AAC v1 (AAC LC + SBR)
        "mp4a.40.05", // MPEG-4 HE-AAC v1 (AAC LC + SBR), leading 0 for Aud-OTI compatibility
        "mp4a.67",    // MPEG-2 AAC LC
    };

    uint16_t choosenLine = 0;
    uint16_t plcSize = m_playlistContent.size();
    int8_t   cS = 100;

    for(uint16_t i = 0; i < plcSize; i++) { // looking for lowest codeString
        if(m_playlistContent[i].contains("CODECS=\"mp4a")){
            for (uint8_t j = 0; j < 9; j++) {
                if (m_playlistContent[i].contains(codecString[j])) {
                    if (j < cS) {
                        cS = j;
                        choosenLine = i;
                    }
                }
            }
        }
    }
    if (cS == 0)            *codec = CODEC_MP3;
    else if (cS < 100)      *codec = CODEC_AAC;



    if(cS == 100) {                             // "mp4a.xx.xx" not found
        *codec = CODEC_AAC;                     // assume AAC
        for(uint16_t i = 0; i < plcSize; i++) { // we have no codeString, looking for "http"
            if(m_playlistContent[i].contains("#EXT-X-STREAM-INF")){
                choosenLine = i;
            }
        }
    }

    choosenLine++; // next line is the redirection url

    ps_ptr<char> result("result");
    ps_ptr<char>line; line.clone_from(m_playlistContent[choosenLine]);

    if(line.starts_with("../")){
        // ../../2093120-b/RISMI/stream01/streamPlaylist.m3u8
        while (line.starts_with("../")){
            line.remove_prefix("../");
        }
        result.clone_from(m_currentHost);
        int idx = result.last_index_of('/');
        if(idx > 0 && (size_t)idx != result.strlen() - 1) result.truncate_at((size_t)idx + 1);
        result.append(line.get());
    }
    else if(!line.starts_with_icase("http")) {

        // http://arcast.com.ar:1935/radio/radionar.stream/playlist.m3u8               m_lastHost
        // chunklist_w789468022.m3u8                                                   line
        // http://arcast.com.ar:1935/radio/radionar.stream/chunklist_w789468022.m3u8   --> result

        result.clone_from(m_currentHost);
        int pos = m_currentHost.last_index_of('/');
        if(pos > 0){
            result.truncate_at((size_t)pos + 1);
            result.append(line.get());
        }
    }
    else {
        result.clone_from(line);
    }

    return result; // it's a redirection, a new m3u8 playlist
}
//##################################################################
void Audio::processLocalFile() {
    if(!(m_audiofile && m_f_running && m_dataMode == AUDIO_LOCALFILE)) return; // guard
    m_prlf.maxFrameSize = InBuff.getMaxBlockSize(); // every mp3/aac frame is not bigger maxFrameSize = InBuff.getMaxBlockSize(); // every mp3/aac frame is not bigger
    m_prlf.availableBytes = 0;
    m_prlf.bytesAddedToBuffer = 0;

    if(m_f_firstCall) { // runs only one time per connection, prepare for start
        m_f_firstCall = false;
        m_f_stream = false;
        m_prlf.audioHeaderFound = false;
        m_prlf.newFilePos = 0;
        m_prlf.ctime = millis();
        m_audioFilePosition = 0;
        m_audioDataSize = m_audioFileSize;
        m_audioDataStart = 0;
        m_f_allDataReceived = false;
        m_prlf.timeout = 8000; // ms
    }

    if(m_resumeFilePos >= 0 ) {  // we have a resume file position
        m_prlf.newFilePos = newInBuffStart(m_resumeFilePos);
        if(m_prlf.newFilePos < 0) /*AUDIO_LOG_WARN*/AUDIO_INFO("skip to new position was not successful");
        m_haveNewFilePos  = m_prlf.newFilePos;
        m_resumeFilePos = -1;
        m_f_allDataReceived = false;
        return;
    }

//    m_prlf.availableBytes = min(InBuff.writeSpace(), m_audioFileSize - m_audioFilePosition);
    m_prlf.availableBytes = (InBuff.writeSpace() < (m_audioFileSize - m_audioFilePosition)) ? InBuff.writeSpace() : (m_audioFileSize - m_audioFilePosition);

//    m_prlf.bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), min(m_prlf.availableBytes, UINT16_MAX));
    m_prlf.bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), (m_prlf.availableBytes < UINT16_MAX) ? m_prlf.availableBytes : UINT16_MAX);
    if(m_prlf.bytesAddedToBuffer > 0) {InBuff.bytesWritten(m_prlf.bytesAddedToBuffer);}
    if(m_audioDataSize && m_audioFilePosition >= m_audioDataSize){if(!m_f_allDataReceived) m_f_allDataReceived = true;}
    if(!m_audioDataSize && m_audioFilePosition == m_audioFileSize){if(!m_f_allDataReceived) m_f_allDataReceived = true;}
    // AUDIO_ERROR("m_audioFilePosition %u >= m_audioDataSize %u, m_f_allDataReceived % i", m_audioFilePosition, m_audioDataSize, m_f_allDataReceived);

    if(!m_f_stream) {
        if(m_codec == CODEC_OGG) { // AUDIO_ERROR("determine correct codec here");
            uint8_t codec = determineOggCodec(InBuff.getReadPtr(), m_prlf.maxFrameSize);
            if     (codec == CODEC_FLAC)   {/*initializeDecoder(codec);*/ m_codec = CODEC_FLAC; AUDIO_INFO("format is flac"); return;}
//            else if(codec == CODEC_OPUS)   {initializeDecoder(codec); m_codec = CODEC_OPUS; AUDIO_INFO("format is opus"); return;}
//            else if(codec == CODEC_VORBIS) {initializeDecoder(codec); m_codec = CODEC_VORBIS; AUDIO_INFO("format is vorbis"); return;}
            else                           {stopSong(); return;}
//            m_lastGranulePosition = getLastGranulePosition();
            m_controlCounter = 100;
//            log_w("%lu, lastGranulePosition %llu", __LINE__, m_lastGranulePosition);
            return;
        }
        if(m_controlCounter != 100) {
            if((millis() - m_prlf.ctime) > m_prlf.timeout) {
                AUDIO_ERROR("audioHeader reading timeout");
                m_f_running = false;
                goto exit;
            }
            if(InBuff.bufferFilled() > m_prlf.maxFrameSize || (InBuff.bufferFilled() == m_audioFileSize) || m_f_allDataReceived) { // at least one complete frame or the file is smaller
                InBuff.bytesWasRead(readAudioHeader(InBuff.getMaxAvailableBytes()));
            }
            if(m_controlCounter == 100){
                if(m_audioDataStart > 0){ m_prlf.audioHeaderFound = true; }
                if(!m_audioDataSize) m_audioDataSize = m_audioFileSize;
            }
            return;
        }
        else {
            m_f_stream = true;
            AUDIO_INFO("stream ready");
        }
    }

/*    if(m_fileStartTime > 0 && m_nominal_bitrate){
        if(getBitRate() > 0) setAudioPlayTime(m_fileStartTime);
        else AUDIO_INFO("can't set audio play time directly");
        m_fileStartTime = -1;
    }*/

    if(m_fileStartPos > 0){
        setFilePos(m_fileStartPos);
        m_fileStartPos = -1;
    }

    // end of file reached? - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_eof){ // m_f_eof and m_f_ID3v1TagFound will be set in playAudioData()
        if(m_f_ID3v1TagFound) readID3V1Tag();

exit:
        ps_ptr<char>afn; 	//  ("afn")audio file name
        if(m_audiofile) afn.assign(m_audiofile.name()); // store temporary the name
//        m_audioCurrentTime = 0;			// present in stopSong()
//        m_audioFileDuration = 0;			// present in stopSong()
//        m_resumeFilePos = -1;			// present in stopSong()
//        m_haveNewFilePos = 0;			// present in stopSong()
//        m_codec = CODEC_NONE;			// present in stopSong()
        stopSong();

        if(afn.valid()) {
//            AUDIO_INFO("End of file \"%s\"", afn.c_get());
            /*info(evt_eof,*/ if(audio_eof_mp3) audio_eof_mp3(afn.c_get());
            afn.clear();
        }
        return;
    }
}
//##################################################################
void Audio::processWebStream() {
    if(m_dataMode != AUDIO_DATA) return; // guard
    uint16_t readedBytes = 0;

    m_pwst.maxFrameSize = InBuff.getMaxBlockSize(); // every mp3/aac frame is not bigger
    m_pwst.availableBytes = 0; // available from stream
    m_pwst.f_clientIsConnected = m_client->connected();

    // first call, set some values to default  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_firstCall) { // runs only ont time per connection, prepare for start
        m_f_firstCall = false;
        m_f_stream = false;
        m_pwst.chunkSize = 0;
        m_metacount = m_metaint;
        m_f_allDataReceived = false;
        readMetadata(0, &readedBytes, true);
        getChunkSize(0, true);
        m_audioFilePosition = 0;
    }
    if(m_pwst.f_clientIsConnected) m_pwst.availableBytes = m_client->available(); // available from stream

    // chunked data tramsfer
    if(m_f_chunked && m_pwst.availableBytes){
        if(m_pwst.chunkSize == 0) {
            int chunkLen = getChunkSize(&m_pwst.readedBytes);
            if(chunkLen < 0) return;
            if(chunkLen == 0) m_f_allDataReceived = true;
            m_pwst.chunkSize = chunkLen;
            m_pwst.readedBytes = 0; // readedBytes is not a part of chunkSize
        }
        m_pwst.availableBytes = min(m_pwst.availableBytes, m_pwst.chunkSize);
    }

    // we have metadata  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_metadata && (m_metacount == 0)) {
        if(!m_pwst.availableBytes) return;
        readedBytes = 0;
        bool res = readMetadata(m_pwst.availableBytes, &readedBytes);
        m_pwst.readedBytes += readedBytes;
        if(m_f_chunked) m_pwst.chunkSize -= readedBytes; // reduce chunkSize by metadata length
        if (res == false) return;
        m_metacount = m_metaint;
        return;
    }
    if(m_f_metadata) m_pwst.availableBytes = min(m_pwst.availableBytes, m_metacount);

    // if the buffer is often almost empty issue a warning - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_stream) {
        if(!m_f_allDataReceived) if(streamDetection(m_pwst.availableBytes)) return;
        if(!m_pwst.f_clientIsConnected) {if(m_f_tts && !m_f_allDataReceived) m_f_allDataReceived = true;} // connection closed (OpenAi)
    }

    // buffer fill routine - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_pwst.availableBytes) {
//        m_pwst.availableBytes = min(m_pwst.availableBytes, (uint32_t)InBuff.writeSpace());
        m_pwst.availableBytes = (m_pwst.availableBytes < (uint32_t)InBuff.writeSpace()) ? m_pwst.availableBytes : (uint32_t)InBuff.writeSpace();
//        int32_t bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), min(m_pwst.availableBytes, UINT16_MAX));
        int32_t bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), (m_pwst.availableBytes < UINT16_MAX) ? m_pwst.availableBytes : UINT16_MAX);
        if(bytesAddedToBuffer > 0) {
            if(m_f_metadata) m_metacount -= bytesAddedToBuffer;
            if(m_f_chunked) m_pwst.chunkSize -= bytesAddedToBuffer;
            InBuff.bytesWritten(bytesAddedToBuffer);
        }
    }

    // start audio decoding - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(InBuff.bufferFilled() > m_pwst.maxFrameSize && !m_f_stream) { // waiting for buffer filled
        if(m_codec == CODEC_OGG) { // AUDIO_INFO("determine correct codec here");
            uint8_t codec = determineOggCodec(InBuff.getReadPtr(), m_pwst.maxFrameSize);
            if(codec == CODEC_FLAC) {initializeDecoder(codec); m_codec = codec; AUDIO_INFO("format is flac");}
            if(codec == CODEC_OPUS) {initializeDecoder(codec); m_codec = codec; AUDIO_INFO("format is opus"); AUDIO_ERROR("can't play OPUS yet"); stopSong();}
            if(codec == CODEC_VORBIS) {initializeDecoder(codec); m_codec = codec; AUDIO_INFO("format is vorbis");}
        }
        AUDIO_INFO("stream ready");
        m_f_stream = true;  // ready to play the audio data
    }

    if(m_f_eof) {
        /*info(evt_eof,*/ if(audio_eof_stream) audio_eof_stream(m_lastHost.c_get());
        stopSong();
    }
}
//###################################################################
void Audio::processWebFile() {
    if(!m_lastHost.valid()) {AUDIO_ERROR("m_lastHost is empty"); return;}  // guard
    m_pwf.maxFrameSize = InBuff.getMaxBlockSize();        // every frame is not bigger
    uint32_t availableBytes = 0;
    int32_t bytesAddedToBuffer = 0;
    // m_pwf.f_clientIsConnected = m_client->connected();     // we are not connected

    if(m_f_firstCall) { // runs only ont time per connection, prepare for start
        m_f_firstCall = false;
        m_f_stream = false;
        m_pwf.audioHeaderFound = false;
        m_pwf.newFilePos = 0;
        m_pwf.ctime = millis();
        m_audioFilePosition = 0;
        m_audioDataSize = m_audioFileSize;
        m_audioDataStart = 0;
        m_f_allDataReceived = false;
        m_pwf.timeout = 5000; // ms
    }

/*    if(m_resumeFilePos >= 0 ) {  // we have a resume file position
        m_pwf.newFilePos = newInBuffStart(m_resumeFilePos);
        if(m_pwf.newFilePos < 0) AUDIO_INFO("skip to new position was not successful");
        m_haveNewFilePos  = m_pwf.newFilePos;
        m_resumeFilePos = -1;
        m_f_allDataReceived = false;
        return;
    }*/

//    m_pwf.availableBytes = min(m_client->available(), InBuff.writeSpace());
    m_pwf.availableBytes = (m_client->available() < InBuff.writeSpace()) ? m_client->available() : InBuff.writeSpace();
//    m_pwf.bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), min(m_pwf.availableBytes, UINT16_MAX));
    m_pwf.bytesAddedToBuffer = audioFileRead(InBuff.getWritePtr(), (m_pwf.availableBytes < UINT16_MAX) ? m_pwf.availableBytes : UINT16_MAX);
    if(m_pwf.bytesAddedToBuffer > 0) {InBuff.bytesWritten(m_pwf.bytesAddedToBuffer);}
    if(m_audioDataSize && m_audioFilePosition >= m_audioDataSize){if(!m_f_allDataReceived) m_f_allDataReceived = true;}
    if(!m_audioDataSize && m_audioFilePosition == m_audioFileSize){if(!m_f_allDataReceived) m_f_allDataReceived = true;}
    // AUDIO_ERROR("m_audioFilePosition %u >= m_audioDataSize %u, m_f_allDataReceived % i", m_audioFilePosition, m_audioDataSize, m_f_allDataReceived);

    if(!m_f_stream) {
        if(m_codec == CODEC_OGG) { // AUDIO_ERROR("determine correct codec here");
            uint8_t codec = determineOggCodec(InBuff.getReadPtr(), m_pwf.maxFrameSize);
            if     (codec == CODEC_FLAC)   {/*initializeDecoder(codec);*/ m_codec = CODEC_FLAC; AUDIO_INFO("format is flac");   return;}
            else if(codec == CODEC_VORBIS) {/*initializeDecoder(codec);*/ m_codec = CODEC_VORBIS; AUDIO_INFO("format is vorbis"); return;}
            else if(codec == CODEC_OPUS)   {/*initializeDecoder(codec);*/ m_codec = CODEC_OPUS; AUDIO_INFO("format is opus");
							AUDIO_ERROR("can't play OPUS yet"); /*stopSong();*/  return;}
            else                           {stopSong(); return;}
//            m_lastGranulePosition = getLastGranulePosition(); // to calculate the duration
            m_controlCounter = 100;
//            log_w("%lu, lastGranulePosition %llu", __LINE__, m_lastGranulePosition);
            return;
        }
        if(m_controlCounter != 100) {
            if((millis() - m_pwf.ctime) > m_pwf.timeout) {
                AUDIO_ERROR("audioHeader reading timeout");
                m_f_running = false;
                goto exit;
            }
            if(InBuff.bufferFilled() > m_pwf.maxFrameSize || (InBuff.bufferFilled() == m_audioFileSize) || m_f_allDataReceived) { // at least one complete frame or the file is smaller
                InBuff.bytesWasRead(readAudioHeader(InBuff.getMaxAvailableBytes()));
            }
            if(m_controlCounter == 100){
                if(m_audioDataStart > 0){ m_pwf.audioHeaderFound = true; }
                if(!m_audioDataSize) m_audioDataSize = m_audioFileSize;
            }
            return;
        }
        else {
            m_f_stream = true;
            AUDIO_INFO("stream ready");
        }
    }

/*    if(m_fileStartTime > 0 && m_nominal_bitrate){
        if(getBitRate() > 0) setAudioPlayTime(m_fileStartTime);
        else AUDIO_INFO("can't set audio play time directly");
        m_fileStartTime = -1;
    }*/

    if(m_fileStartPos > 0){
        setFilePos(m_fileStartPos);
        m_fileStartPos = -1;
    }

    // end of file reached? - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_eof){ // m_f_eof and m_f_ID3v1TagFound will be set in playAudioData()
        if(m_f_ID3v1TagFound) readID3V1Tag();
exit:
        stopSong();
        /*info(evt_eof,*/ audio_eof_mp3(m_lastHost.c_get());

//        m_audioCurrentTime = 0;			// present in stopSong()
//        m_audioFileDuration = 0;			// present in stopSong()
//        m_resumeFilePos = -1;			// present in stopSong()
//        m_haveNewFilePos = 0;			// present in stopSong()
//        m_codec = CODEC_NONE;			// present in stopSong()
        return;
    }
}
//##################################################################
void Audio::processWebStreamTS() {
    uint32_t        availableBytes;     // available bytes in stream
    uint8_t         ts_packetStart = 0;
    uint8_t         ts_packetLength = 0;


    // first call, set some values to default ———————————————————————————————————
    if(m_f_firstCall) {   // runs only one time per connection, prepare for start
        m_f_firstCall = false;
        m_f_m3u8data = true;
        m_audioFilePosition = 0;
        m_pwsst.f_firstPacket = true;
        m_pwsst.f_chunkFinished = false;
        m_pwsst.f_nextRound = false;
        m_pwsst.byteCounter = 0;
        m_pwsst.chunkSize = 0;
        m_pwsst.ts_packetPtr = 0;
        m_t0 = millis();
        getChunkSize(0, true);
        ts_parsePacket(0, 0, 0);
        if(!m_pwsst.ts_packet.valid()) m_pwsst.ts_packet.alloc_array(m_pwsst.ts_packetsize, "m_pwsst.ts_packet"); // first init
    } //—————————————————————————————————————————————————————————————————————————

    if(m_dataMode != AUDIO_DATA) return; // guard

nextRound:
    availableBytes = m_client->available();
    if(availableBytes) {
        /* If the m3u8 stream uses 'chunked data transfer' no content length is supplied. Then the chunk size determines the audio data to be processed.
           However, the chunk size in some streams is limited to 32768 bytes, although the chunk can be larger. Then the chunk size is
           calculated again. The data used to calculate (here readedBytes) the chunk size is not part of it.
        */
        uint16_t readedBytes = 0;
        uint32_t minAvBytes = 0;
        if(m_pwsst.f_chunkFinished ) goto chunkFinished;
        if(m_f_chunked && m_pwsst.chunkSize == m_pwsst.byteCounter) {
            int cs = getChunkSize(&readedBytes);
            if(cs == -1) return;
            m_pwsst.chunkSize += cs; /*AUDIO_LOG_DEBUG AUDIO_INFO("cs %i, rb %i", cs, readedBytes);*/
            if(cs == 0){
                m_pwsst.f_chunkFinished = true;
                m_pwsst.chunkSize = 0;
                m_pwsst.byteCounter = 0;
                goto chunkFinished;
            }
        }
        if(m_pwsst.chunkSize) minAvBytes = min3(availableBytes, m_pwsst.ts_packetsize - m_pwsst.ts_packetPtr, m_pwsst.chunkSize - m_pwsst.byteCounter);
        else          minAvBytes = min(availableBytes, (uint32_t)(m_pwsst.ts_packetsize - m_pwsst.ts_packetPtr));

        int res = audioFileRead(m_pwsst.ts_packet.get() + m_pwsst.ts_packetPtr, minAvBytes);
        if(res > 0) {
            m_pwsst.ts_packetPtr += res;
            m_pwsst.byteCounter += res;
            if(m_pwsst.ts_packetPtr < m_pwsst.ts_packetsize) return; // not enough data yet, the process must be repeated if the packet size (188 bytes) is not reached
            m_pwsst.ts_packetPtr = 0;
            if(m_pwsst.f_firstPacket) { // search for ID3 Header in the first packet
                m_pwsst.f_firstPacket = false;
                uint8_t ID3_HeaderSize = process_m3u8_ID3_Header(m_pwsst.ts_packet.get());
                if(ID3_HeaderSize > m_pwsst.ts_packetsize) {
                    AUDIO_ERROR("ID3 Header is too big");
                    stopSong();
                    return;
                }
                if(ID3_HeaderSize) {
                    memcpy(m_pwsst.ts_packet.get(), &m_pwsst.ts_packet.get()[ID3_HeaderSize], m_pwsst.ts_packetsize - ID3_HeaderSize);
                    m_pwsst.ts_packetPtr = m_pwsst.ts_packetsize - ID3_HeaderSize;
                    return;
                }
            }
            if(!ts_parsePacket(&m_pwsst.ts_packet.get()[0], &ts_packetStart, &ts_packetLength)){
                stopSong();
                AUDIO_ERROR("song stopped");
                return;
            };

            if(ts_packetLength) {
                size_t ws = InBuff.writeSpace();
                if(ws >= ts_packetLength) {
                    memcpy(InBuff.getWritePtr(), m_pwsst.ts_packet.get() + ts_packetStart, ts_packetLength);
                    InBuff.bytesWritten(ts_packetLength);
                    m_pwsst.f_nextRound = true;
                }
                else {
                    memcpy(InBuff.getWritePtr(), m_pwsst.ts_packet.get() + ts_packetStart, ws);
                    InBuff.bytesWritten(ws);
                    memcpy(InBuff.getWritePtr(), &m_pwsst.ts_packet.get()[ws + ts_packetStart], ts_packetLength - ws);
                    InBuff.bytesWritten(ts_packetLength - ws);
                }
            }
            if(m_audioFileSize && m_pwsst.byteCounter > m_audioFileSize) {AUDIO_ERROR("byteCounter overflow, byteCounter: %d, contentlength: %d", m_pwsst.byteCounter, m_audioFileSize); return;}
            if(m_pwsst.chunkSize       && m_pwsst.byteCounter > m_pwsst.chunkSize)       {AUDIO_ERROR("byteCounter overflow, byteCounter: %d, chunkSize: %d", m_pwsst.byteCounter, m_pwsst.chunkSize); return;}
        }
    }
    if(m_audioFileSize && m_pwsst.byteCounter == m_audioFileSize){
        if(InBuff.bufferFilled() < 120000) {
            m_f_continue = true;
            m_pwsst.byteCounter = 0;
            m_pwsst.ts_packetPtr = 0;
            m_pwsst.f_nextRound = false;
        }
        goto exit;
    }



chunkFinished:
    if(m_pwsst.f_chunkFinished) {
        if(InBuff.bufferFilled() < 120000) {
            m_pwsst.f_chunkFinished = false;
            m_f_continue = true;
            m_pwsst.byteCounter = 0;
            m_pwsst.chunkSize = 0;
            m_pwsst.ts_packetPtr = 0;
        }
        goto exit;
    }


    // if the buffer is often almost empty issue a warning - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_stream) {
        if(streamDetection(availableBytes)) goto exit;
    }

    // buffer fill routine  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(true) {                                                  // statement has no effect
        if(InBuff.bufferFilled() > 60000 && !m_f_stream) {     // waiting for buffer filled
            m_f_stream = true;                                  // ready to play the audio data
            uint16_t filltime = millis() - m_t0;
            AUDIO_INFO("stream ready");
//            AUDIO_INFO("buffer filled in %d ms", filltime);
        }
    }
    if(m_pwsst.f_nextRound){goto nextRound;}
exit:
    return;
}
//##################################################################
void Audio::processWebStreamHLS() {

    // first call, set some values to default - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(m_f_firstCall) { // runs only ont time per connection, prepare for start
        m_f_firstCall = false;
        m_f_m3u8data = true;
        m_t0 = millis();
        m_controlCounter = 0;
        m_audioFilePosition = 0;

        m_pwsHLS.maxFrameSize = InBuff.getMaxBlockSize(); // every mp3/aac frame is not bigger
        m_pwsHLS.ID3BuffSize = 4096;
        m_pwsHLS.availableBytes = 0;
        m_pwsHLS.firstBytes = true;
        m_pwsHLS.f_chunkFinished = false;
        m_pwsHLS.byteCounter = 0;
        m_pwsHLS.chunkSize = 0;
        m_pwsHLS.ID3WritePtr = 0;
        m_pwsHLS.ID3ReadPtr = 0;
        m_pwsHLS.ID3Buff.alloc(m_pwsHLS.ID3BuffSize, "m_pwsHLS.ID3Buff");
        getChunkSize(0, true);
    }

    if(m_dataMode != AUDIO_DATA) return; // guard

    m_pwsHLS.availableBytes = m_client->available();
    if(m_pwsHLS.availableBytes) { // an ID3 header could come here
        uint16_t readedBytes = 0;

        if(m_f_chunked && !m_pwsHLS.chunkSize) {
            m_pwsHLS.chunkSize = getChunkSize(&readedBytes);
            m_pwsHLS.byteCounter += readedBytes;
        }

        if(m_pwsHLS.firstBytes) {
            if(m_pwsHLS.ID3WritePtr < m_pwsHLS.ID3BuffSize) {
                m_pwsHLS.ID3WritePtr += audioFileRead(&m_pwsHLS.ID3Buff[m_pwsHLS.ID3WritePtr], m_pwsHLS.ID3BuffSize - m_pwsHLS.ID3WritePtr);
                return;
            }
            if(m_controlCounter < 100) {
                int res = read_ID3_Header(&m_pwsHLS.ID3Buff[m_pwsHLS.ID3ReadPtr], m_pwsHLS.ID3BuffSize - m_pwsHLS.ID3ReadPtr);
                if(res >= 0) m_pwsHLS.ID3ReadPtr += res;
                if(m_pwsHLS.ID3ReadPtr > m_pwsHLS.ID3BuffSize) {
                    AUDIO_ERROR("buffer overflow");
                    stopSong();
                    return;
                }
                return;
            }
            if(m_controlCounter != 100) return;

            size_t ws = InBuff.writeSpace();
            if(ws >= m_pwsHLS.ID3BuffSize - m_pwsHLS.ID3ReadPtr) {
                memcpy(InBuff.getWritePtr(), &m_pwsHLS.ID3Buff[m_pwsHLS.ID3ReadPtr], m_pwsHLS.ID3BuffSize - m_pwsHLS.ID3ReadPtr);
                InBuff.bytesWritten(m_pwsHLS.ID3BuffSize - m_pwsHLS.ID3ReadPtr);
            }
            else {
                memcpy(InBuff.getWritePtr(), &m_pwsHLS.ID3Buff[m_pwsHLS.ID3ReadPtr], ws);
                InBuff.bytesWritten(ws);
                memcpy(InBuff.getWritePtr(), &m_pwsHLS.ID3Buff[ws + m_pwsHLS.ID3ReadPtr], m_pwsHLS.ID3BuffSize - (m_pwsHLS.ID3ReadPtr + ws));
                InBuff.bytesWritten(m_pwsHLS.ID3BuffSize - (m_pwsHLS.ID3ReadPtr + ws));
            }
            m_pwsHLS.ID3Buff.reset();
            m_pwsHLS.byteCounter += m_pwsHLS.ID3BuffSize;
            m_pwsHLS.firstBytes = false;
        }

        size_t bytesWasWritten = 0;
        if(InBuff.writeSpace() >= m_pwsHLS.availableBytes) {
        //    if(availableBytes > 1024) availableBytes = 1024; // 1K throttle
            bytesWasWritten = audioFileRead(InBuff.getWritePtr(), m_pwsHLS.availableBytes);
        }
        else { bytesWasWritten = audioFileRead(InBuff.getWritePtr(), InBuff.writeSpace()); }
        InBuff.bytesWritten(bytesWasWritten);

        m_pwsHLS.byteCounter += bytesWasWritten;

        if(m_pwsHLS.byteCounter == m_audioFileSize || m_pwsHLS.byteCounter == m_pwsHLS.chunkSize) {
            m_pwsHLS.f_chunkFinished = true;
            m_pwsHLS.byteCounter = 0;
        }
    }

    if(m_pwsHLS.f_chunkFinished) {
        if(InBuff.bufferFilled() < 50000) {
            m_pwsHLS.f_chunkFinished = false;
            m_f_continue = true;
        }
    }

    // if the buffer is often almost empty issue a warning or try a new connection - - - - - - - - - - - - - - - - - - -
    if(m_f_stream) {
        if(streamDetection(m_pwsHLS.availableBytes)) return;
    }

    if(InBuff.bufferFilled() > m_pwsHLS.maxFrameSize && !m_f_stream) { // waiting for buffer filled
        m_f_stream = true;                                    // ready to play the audio data
        //uint16_t filltime = millis() - m_t0;
        AUDIO_INFO("stream ready");
        // AUDIO_INFO("buffer filled in %u ms", filltime);
    }
    return;
}
//##################################################################
void Audio::playAudioData() {

    if(!m_f_stream || m_f_eof || m_f_lockInBuffer || !m_f_running){m_validSamples = 0; return;} // guard, stream not ready or eof reached or InBuff is locked or not running
//    if(m_validSamples) {playChunk();                               return;} // guard, play samples first
    //--------------------------------------------------------------------------------
    m_pad.count = 0;
    m_pad.bytesToDecode = InBuff.bufferFilled();
    m_pad.bytesDecoded = 0;

    if(m_f_firstPlayCall) {
        m_f_firstPlayCall = false;
        m_pad.count = 0;
        m_pad.oldAudioDataSize = 0;
        m_bytesNotConsumed = 0;
        m_pad.lastFrames = false;
        m_f_eof = false;
    }
    //--------------------------------------------------------------------------------

    m_f_audioTaskIsDecoding = true;

    if((m_dataMode == AUDIO_LOCALFILE || m_streamType == ST_WEBFILE) && m_playlistFormat != FORMAT_M3U8)  { // local file or webfile but not m3u8 file
        if(!m_audioDataSize) goto exit; // no data to decode if filesize is 0
        if(m_audioDataSize != m_pad.oldAudioDataSize) { // Special case: Metadata in ogg files are recognized by the decoder,
            if(m_f_ogg)m_bytesNotConsumed = 0;
            m_pad.oldAudioDataSize = m_audioDataSize;
        }

//        m_pad.bytesToDecode = min(m_audioFileSize - m_audioFilePosition + InBuff.bufferFilled(), InBuff.getMaxBlockSize());
        m_pad.bytesToDecode = (m_audioFileSize - m_audioFilePosition + InBuff.bufferFilled()) < InBuff.getMaxBlockSize() ? (m_audioFileSize - m_audioFilePosition + InBuff.bufferFilled()) : InBuff.getMaxBlockSize();

        if(m_audioFileSize - m_audioFilePosition == 0) m_f_allDataReceived = true;
        if(m_f_allDataReceived && InBuff.bufferFilled() < InBuff.getMaxBlockSize()){ // last frames to decode
            m_pad.lastFrames = true;
        }
        if(m_pad.bytesToDecode == 0)            {m_f_eof = true; goto exit;} // file end reached

        if(m_codec == CODEC_MP3 && m_pad.lastFrames && m_pad.bytesToDecode == 128){
            m_f_ID3v1TagFound = true; m_f_eof = true;
            goto exit;
        }
    }
    else{
        if(InBuff.bufferFilled() < InBuff.getMaxBlockSize() && m_f_allDataReceived) {m_pad.lastFrames = true;}
//        m_pad.bytesToDecode = min(InBuff.bufferFilled(), InBuff.getMaxBlockSize());
        m_pad.bytesToDecode = (InBuff.bufferFilled() < InBuff.getMaxBlockSize()) ? InBuff.bufferFilled() : InBuff.getMaxBlockSize();
    }

    if(m_pad.lastFrames){
        m_pad.bytesDecoded = sendBytes(InBuff.getReadPtr(), m_pad.bytesToDecode);
    }
    else{
        if(InBuff.bufferFilled() >= InBuff.getMaxBlockSize()) m_pad.bytesDecoded = sendBytes(InBuff.getReadPtr(), m_pad.bytesToDecode);
        else m_pad.bytesDecoded = 0; // Inbuff not filled enough
    }

    if(m_pad.bytesDecoded <= 0) {
        if(m_pad.lastFrames) {m_f_eof = true; goto exit;} // end of file reached
        m_pad.count++;
        vTaskDelay(20); // wait for data
        if(m_pad.count == 30) {if(m_f_allDataReceived) m_f_eof = true;}  // maybe slow stream
        goto exit; // syncword at pos0
    }
    m_pad.count = 0;

    if(m_pad.bytesDecoded > 0) {
        InBuff.bytesWasRead(m_pad.bytesDecoded);

        if(m_f_allDataReceived && InBuff.bufferFilled() == 0) {
            m_f_eof = true; // end of file reached
        }
    }

exit:
    m_f_audioTaskIsDecoding = false;
    return;
}
//##################################################################
bool Audio::parseHttpResponseHeader() { // this is the response to a GET / request

    if(m_dataMode != HTTP_RESPONSE_HEADER) return false;
    if(!m_currentHost.valid()) {AUDIO_ERROR("m_currentHost is empty"); return false;}

    memset(&m_phreh, 0, sizeof(m_phreh));
    m_phreh.ctime = millis();
    m_phreh.timeout = 4500; // ms	(HEADER_TIMEOUT))

    if(m_client->available() == 0) {
        if(!m_phreh.f_time) {
            m_phreh.stime = millis();
            m_phreh.f_time = true;
        }
        if((millis() - m_phreh.stime) > m_phreh.timeout) {
            AUDIO_ERROR("timeout");
            m_phreh.f_time = false;
            return false;
        }
    }
    m_phreh.f_time = false;

    ps_ptr<char>rhl;
    rhl.alloc(1024, "rhl"); // responseHeaderline
    rhl.clear();
    bool ct_seen = false;

    while(true) { // outer while
        uint16_t pos = 0;
        if((millis() - m_phreh.ctime) > m_phreh.timeout) {
            AUDIO_ERROR("timeout");
            m_f_timeout = true;
            goto exit;
        }
        while(m_client->available()) {
            uint8_t b = audioFileRead();
            if(b == '\n') {
                if(!pos) { // empty line received, is the last line of this responseHeader
                    if(ct_seen) goto lastToDo;
                    else {if(!m_client->available())  goto exit;}
                }
                break;
            }
            if(b == '\r') rhl[pos] = 0;
            if(b < 0x20) continue;
            rhl[pos] = b;
            pos++;
            if(pos == 1023) {
                pos = 1022;
                continue;
            }
            if(pos == 1022) {
                rhl[pos] = '\0';
                /*AUDIO_LOG_WARN*/AUDIO_ERROR("responseHeaderline overflow");
            }
        } // inner while
        if(!pos) {
            vTaskDelay(5);
            continue;
        }

        // rhl.println();
        if(rhl.starts_with_icase("icy-")){
            m_phreh.f_icy_data = true; // is webstrean
        }

        if(rhl.starts_with_icase("HTTP/")) { // HTTP status error code
            char statusCode[5];
            statusCode[0] = rhl[9];
            statusCode[1] = rhl[10];
            statusCode[2] = rhl[11];
            statusCode[3] = '\0';
            int sc = atoi(statusCode);
            if(sc > 310) { // e.g. HTTP/1.1 301 Moved Permanently
//                info(evt_streamtitle, rhl.get());
                AUDIO_ERROR(rhl.get());
                goto exit;
            }
        }
        else if(rhl.starts_with_icase("content-type:")) { // content-type: text/html; charset=UTF-8
            int idx = rhl.index_of(';', 13);
            if(idx > 0) rhl[idx] = '\0';
            if(parseContentType(rhl.get() + 13)) ct_seen = true;
            else{
                /*AUDIO_LOG_WARN*/AUDIO_ERROR("unknown contentType %s", rhl.get() + 13);
                goto exit;
            }
        }

        else if(rhl.starts_with_icase("location:")) {
            int pos = rhl.index_of_icase("http", 0);
            if(pos >= 0) {
                const char* c_host = (rhl.get() + pos);
                if(!m_currentHost.equals(c_host)) { // prevent a loop
                    int pos_slash = indexOf(c_host, "/", 9);
                    if(pos_slash > 9) {
                        if(!strncmp(c_host, m_currentHost.get(), pos_slash)) {
                            AUDIO_INFO("redirect to new extension at existing host \"%s\"", c_host);
                            if(m_playlistFormat == FORMAT_M3U8) {
                            //    m_lastHost.assign(c_host);
                                m_f_m3u8data = true;
                            }
                            httpPrint(c_host);
                            while(m_client->available()) audioFileRead(); // empty client buffer
                            return true;
                        }
                    }
                    AUDIO_INFO("redirect to new host \"%s\"", c_host);
                    m_f_reset_m3u8Codec = false;
                    httpPrint(c_host);
                    return true;
                }
            }
            else{
                /*AUDIO_LOG_WARN*/AUDIO_ERROR("unknown redirection: %s", rhl.c_get());
            }
        }

        else if(rhl.starts_with_icase("content-encoding:")) {
            AUDIO_INFO(rhl.get());
            if(rhl.contains("gzip")) {
                AUDIO_ERROR("can't extract gzip");
                goto exit;
            }
        }

        else if(rhl.starts_with_icase("content-disposition:")) { // e.g we have this headerline:  content-disposition: attachment; filename=stream.asx
            int idx = rhl.index_of_icase("filename=");
            if (idx >= 0)  {
                ps_ptr<char> fn("fn");
                fn.assign(rhl.get() + idx + 9); // Position directly after "filename="
                fn.replace("\"", ""); // remove '\"' around filename if present
                AUDIO_INFO("Filename is %s", fn.get());
            }
        }
        else if(rhl.starts_with_icase("connection:")) {
            if(rhl.contains_with_icase("close")) {m_f_connectionClose = true; /* AUDIO_ERROR("connection will be closed"); */} // ends after ogg last Page is set
        }

        else if(rhl.starts_with_icase("icy-genre:")) {
            AUDIO_INFO("icy-genre: %s", rhl.get() + 10 ); // Ambient, Rock, etc
        }

        else if(rhl.starts_with_icase("icy-logo:")) {
            ps_ptr<char> icyLogo("icyLogo");
            icyLogo.assign(rhl.get() + 9); // Get logo URL
            icyLogo.trim();
            if(icyLogo.strlen() > 0){
                AUDIO_INFO("icy-logo: %s", icyLogo.get());
//                info(evt_icylogo, icyLogo.get());
            }
        }

        else if(rhl.starts_with_icase("icy-br:")) {
            ps_ptr<char>c_bitRate("c_bitRate"); c_bitRate.assign(rhl.get() + 7);
            c_bitRate.trim();
            c_bitRate.append("000"); // Found bitrate tag, read the bitrate in Kbit
            if(m_phreh.bitrate == c_bitRate.to_uint32(10)) continue; // avoid doubles
            else m_phreh.bitrate = c_bitRate.to_uint32(10);
            m_nominal_bitrate = c_bitRate.to_uint32(10);
            AUDIO_INFO("icy-bitrate : %lu (b/s)", m_nominal_bitrate);
//            info(evt_bitrate, c_bitRate.c_get());
            AUDIO_INFO("BitRate: %lu", m_nominal_bitrate);
//            audio_bitrate(c_bitRate.c_get());
//            audio_bitrate(m_nominal_bitrate);
        }

        else if(rhl.starts_with_icase("icy-metaint:")) {
            const char* c_metaint = (rhl.get() + 12);
            int32_t     i_metaint = atoi(c_metaint);
            m_metaint = i_metaint;
            if(m_metaint) m_f_metadata = true; // Multimediastream
        }

        else if(rhl.starts_with_icase("icy-name:")) {
            //  AUDIO_INFO("%s", rhl.get());
            ps_ptr<char> icyName("icyName");
            icyName.assign(rhl.get() + 9); // Get station name
            icyName.trim();
            if(icyName.strlen() > 0) {
                AUDIO_INFO("icy-name: %s", icyName.get());
//                info(evt_name, icyName.get());
            }
        }

        else if(rhl.starts_with_icase("content-length:")) {
            const char* c_cl = (rhl.get() + 15);
            int32_t     i_cl = atoi(c_cl);
            m_audioFileSize = i_cl;
            // AUDIO_INFO("content-length: %lu", (long unsigned int)m_audioFileSize);
        }

        else if(rhl.starts_with_icase("icy-description:")) {
            const char* c_idesc = (rhl.get() + 16);
            while(c_idesc[0] == ' ') c_idesc++;
            latinToUTF8(rhl); // if already UTF-8 do nothing, otherwise convert to UTF-8
            if(strlen(c_idesc) > 0 && specialIndexOf((uint8_t*)c_idesc, "24bit", 0) > 0) {
                AUDIO_ERROR("icy-description: %s has to be 8 or 16", c_idesc);
                stopSong();
            }
//            /*info(evt_icydescription,*/ audio_icydescription(c_idesc);
        }

        else if(rhl.starts_with_icase("transfer-encoding:")) {
            if(rhl.ends_with_icase("chunked")) { // Station provides chunked transfer
                m_f_chunked = true;
//                AUDIO_INFO("chunked data transfer");
                m_chunkcount = 0; // Expect chunkcount in DATA
            }
        }

        else if(rhl.starts_with_icase("accept-ranges:")) {
            if(rhl.ends_with_icase("bytes")) m_f_acceptRanges = true;
        //    AUDIO_INFO("%s", rhl.c_get());
        }

        else if(rhl.starts_with_icase("content-range:")) {
            AUDIO_INFO("%s", rhl.c_get());
        }

        else if(rhl.starts_with_icase("icy-url:")) {
            char* icyurl = (rhl.get() + 8);
            trim(icyurl);
//            /*info(evt_icyurl,*/ audio_icyurl(icyurl);
        }

        else if(rhl.starts_with_icase("www-authenticate:")) {
            AUDIO_ERROR("authentification failed, wrong credentials?");
            goto exit;
        }
        else { ; }
    } // outer while

exit: // termination condition
//    info(evt_name, "");
//    info(evt_icydescription, "");
//    info(evt_icyurl, "");
//        if(audio_showstation) audio_showstation("");
//        if(audio_icydescription) audio_icydescription("");
        if(audio_icyurl) audio_icyurl("");


    m_dataMode = AUDIO_NONE;
    stopSong();
    return false;

lastToDo:
    m_streamType = ST_WEBSTREAM;
    if(m_audioFileSize > 0)          m_streamType = ST_WEBFILE;  // content length found
    if(m_phreh.f_icy_data)           m_streamType = ST_WEBSTREAM;
    if(m_f_tts)                      m_streamType = ST_WEBSTREAM; // this is from AI or GoogleTTS(AI response)

    if(m_codec != CODEC_NONE) {
        m_dataMode = AUDIO_DATA; // Expecting data now

        if(m_nominal_bitrate == 0){
           if(!m_avr_bitrate) {
               m_avr_bitrate = (wram_read(0x1e05) & 0xFF) * 1000; 		// Read average bitRate from WRAM register
               AUDIO_INFO("BitRate: %lu", m_avr_bitrate);
//                audio_bitrate(m_avr_bitrate);
           }
        }

        if(!(m_codec == CODEC_OGG)){
            if(!initializeDecoder(m_codec)) return false;
        }
    }
    else if(m_playlistFormat != FORMAT_NONE) {
        m_dataMode = AUDIO_PLAYLISTINIT; // playlist expected
        // AUDIO_INFO("now parse playlist");
    }
    else {
        AUDIO_ERROR("unknown content found at: %s", m_currentHost.c_get());
        goto exit;
    }

    /*AUDIO_LOG_DEBUG*/AUDIO_INFO("playlistFormat %s, dataMode %s, streamType: %s", plsFmtStr[m_playlistFormat], dataModeStr[m_dataMode], streamTypeStr[m_streamType]);
    return true;
}
//##################################################################
bool Audio::parseHttpRangeHeader() { // this is the response to a Range request

    ps_ptr<char>rhl("rhl");
    rhl.alloc(1024); // responseHeaderline
    bool ct_seen = false;

    if(m_dataMode != HTTP_RANGE_HEADER){
        AUDIO_ERROR("wrong datamode %i", m_dataMode);
        goto exit;
    }

    m_phrah.ctime = millis();
    m_phrah.timeout = 4500; // ms

    if(m_client->available() == 0) {
        if(!m_phrah.f_time) {
            m_phrah.stime = millis();
            m_phrah.f_time = true;
        }
        if((millis() - m_phrah.stime) > m_phrah.timeout) {
            AUDIO_ERROR("timeout");
            m_phrah.f_time = false;
            return false;
        }
    }
    m_phrah.f_time = false;

    rhl.clear();

    while(true) { // outer while
        uint16_t pos = 0;
        if((millis() - m_phrah.ctime) > m_phrah.timeout) {
            AUDIO_ERROR("timeout");
            m_f_timeout = true;
            goto exit;
        }
        while(m_client->available()) {
            uint8_t b = audioFileRead();
            if(b == '\n') {
                if(!pos) { // empty line received, is the last line of this responseHeader
                    goto lastToDo;
                }
                break;
            }
            if(b == '\r') rhl[pos] = 0;
            if(b < 0x20) continue;
            rhl[pos] = b;
            pos++;
            if(pos == 1023) {
                pos = 1022;
                continue;
            }
            if(pos == 1022) {
                rhl[pos] = '\0';
                /*AUDIO_LOG_WARN*/AUDIO_ERROR("responseHeaderline overflow");
            }
        } // inner while
        if(!pos) {
            vTaskDelay(5);
            continue;
        }
        // /*AUDIO_LOG_WARN*/AUDIO_ERROR("rh %s", rhl.c_get());
        if(rhl.starts_with_icase("HTTP/")) { // HTTP status error code
            char statusCode[5];
            statusCode[0] = rhl[9];
            statusCode[1] = rhl[10];
            statusCode[2] = rhl[11];
            statusCode[3] = '\0';
            int sc = atoi(statusCode);
            if(sc > 310) { // e.g. HTTP/1.1 301 Moved Permanently
//                info(evt_name, rhl.get());
                AUDIO_ERROR(rhl.get());
                goto exit;
            }
        }
        if(rhl.starts_with_icase("Server:")) {
            AUDIO_INFO("%s", rhl.c_get());
        }
        if(rhl.starts_with_icase("Content-Length:")) {
        //    AUDIO_INFO("%s", rhl.c_get());
        }
        if(rhl.starts_with_icase("Content-Range:")) {
            AUDIO_INFO("%s", rhl.c_get());
        }
        if(rhl.starts_with_icase("Content-Type:")) {
        //    AUDIO_INFO("%s", rhl.c_get());
        }
    }
exit:
    return false;
lastToDo:
    m_dataMode = AUDIO_DATA;
    m_streamType = ST_WEBFILE;
return true;
}
//##################################################################
bool Audio::initializeDecoder(uint8_t codec) {
    switch(codec) {
        case CODEC_MP3: InBuff.changeMaxBlockSize(m_frameSizeMP3); break;
        case CODEC_AAC: InBuff.changeMaxBlockSize(m_frameSizeAAC); break;
        case CODEC_M4A: InBuff.changeMaxBlockSize(m_frameSizeAAC); break;
        case CODEC_FLAC: InBuff.changeMaxBlockSize(m_frameSizeFLAC); break;
        case CODEC_OPUS: InBuff.changeMaxBlockSize(m_frameSizeOPUS); break;
        case CODEC_VORBIS: InBuff.changeMaxBlockSize(m_frameSizeVORBIS); break;
        case CODEC_WAV: InBuff.changeMaxBlockSize(m_frameSizeWav); break;
        case CODEC_OGG: // the decoder will be determined later (vorbis, flac, opus?)
            break;
        default: goto exit; break;
    }
    return true;

exit:
    stopSong();
    return false;
}
//##################################################################
bool Audio::parseContentType(char* ct) {
    enum : int { CT_NONE, CT_MP3, CT_AAC, CT_M4A, CT_WAV, CT_FLAC, CT_PLS, CT_M3U, CT_ASX, CT_M3U8, CT_TXT, CT_AACP, CT_OPUS, CT_OGG, CT_VORBIS };

    strlower(ct);
    trim(ct);

    m_codec = CODEC_NONE;
    int ct_val = CT_NONE;

    if(!strcmp(ct, "audio/mpeg")) ct_val = CT_MP3;
    else if(!strcmp(ct, "audio/mpeg3"))                   ct_val = CT_MP3;
    else if(!strcmp(ct, "audio/x-mpeg"))                  ct_val = CT_MP3;
    else if(!strcmp(ct, "audio/x-mpeg-3"))                ct_val = CT_MP3;
    else if(!strcmp(ct, "audio/mp3"))                     ct_val = CT_MP3;
    else if(!strcmp(ct, "audio/aac"))                     ct_val = CT_AAC;
    else if(!strcmp(ct, "audio/x-aac"))                   ct_val = CT_AAC;
    else if(!strcmp(ct, "audio/aacp"))                    ct_val = CT_AAC;
    else if(!strcmp(ct, "video/mp2t")){                   ct_val = CT_AAC;  if(m_m3u8Codec == CODEC_MP3) ct_val = CT_MP3;} // see m3u8redirection()
    else if(!strcmp(ct, "audio/mp2t")){                   ct_val = CT_AAC;  if(m_m3u8Codec == CODEC_MP3) ct_val = CT_MP3;} // see m3u8redirection()
    else if(!strcmp(ct, "audio/mp4"))                     ct_val = CT_M4A;
    else if(!strcmp(ct, "audio/m4a"))                     ct_val = CT_M4A;
    else if(!strcmp(ct, "audio/x-m4a"))                   ct_val = CT_M4A;
    else if(!strcmp(ct, "audio/wav"))                     ct_val = CT_WAV;
    else if(!strcmp(ct, "audio/x-wav"))                   ct_val = CT_WAV;
    else if(!strcmp(ct, "audio/flac"))                    ct_val = CT_FLAC;
    else if(!strcmp(ct, "audio/x-flac"))                  ct_val = CT_FLAC;
    else if(!strcmp(ct, "audio/scpls"))                   ct_val = CT_PLS;
    else if(!strcmp(ct, "audio/x-scpls"))                 ct_val = CT_PLS;
    else if(!strcmp(ct, "application/pls+xml"))           ct_val = CT_PLS;
    else if(!strcmp(ct, "audio/mpegurl")) {               ct_val = CT_M3U;  if(m_expectedPlsFmt == FORMAT_M3U8) ct_val = CT_M3U8;}
    else if(!strcmp(ct, "audio/x-mpegurl"))               ct_val = CT_M3U;
    else if(!strcmp(ct, "audio/ms-asf"))                  ct_val = CT_ASX;
    else if(!strcmp(ct, "video/x-ms-asf"))                ct_val = CT_ASX;
    else if(!strcmp(ct, "audio/x-ms-asx"))                ct_val = CT_ASX;  // #413

    else if(!strcmp(ct, "application/ogg"))               ct_val = CT_OGG;
    else if(!strcmp(ct, "audio/ogg"))                     ct_val = CT_OGG;

    else if(!strcmp(ct, "application/vorbis"))  ct_val = CT_VORBIS;
    else if(!strcmp(ct, "audio/vorbis"))        ct_val = CT_VORBIS;

    else if(!strcmp(ct, "audio/flac"))       ct_val = CT_FLAC;
    else if(!strcmp(ct, "audio/x-flac"))     ct_val = CT_FLAC;

    else if(!strcmp(ct, "application/opus"))  ct_val = CT_OPUS;
    else if(!strcmp(ct, "audio/opus"))        ct_val = CT_OPUS;

    else if(!strcmp(ct, "application/vnd.apple.mpegurl")) ct_val = CT_M3U8;
    else if(!strcmp(ct, "application/x-mpegurl"))         ct_val = CT_M3U8;

    else if(!strcmp(ct, "application/octet-stream"))      ct_val = CT_TXT;  // ??? listen.radionomy.com/1oldies before redirection
    else if(!strcmp(ct, "text/html"))                     ct_val = CT_TXT;
    else if(!strcmp(ct, "text/plain"))                    ct_val = CT_TXT;
    else if(!strcmp(ct, "application/json")){             ct_val = CT_TXT;  if(m_expectedPlsFmt == FORMAT_M3U8) ct_val = CT_M3U8;}  // maybe a m3u8 redirection
    else if(ct_val == CT_NONE) {
        AUDIO_ERROR("ContentType %s not supported", ct);
        return false; // nothing valid had been seen
    }
    else { ; }
    switch(ct_val) {
        case CT_MP3:
            m_codec = CODEC_MP3;
            // { AUDIO_INFO("ContentType %s, format is mp3", ct); } // ok is likely mp3
            AUDIO_INFO("format is mp3");
            break;
        case CT_AAC:
            m_codec = CODEC_AAC;
            // { AUDIO_INFO("ContentType %s, format is aac", ct); }
            AUDIO_INFO("format is aac");
            break;
        case CT_M4A:
            m_codec = CODEC_M4A;
            // { AUDIO_INFO("ContentType %s, format is aac", ct); }
            AUDIO_INFO("format is aac");
            break;
        case CT_FLAC:
            m_codec = CODEC_FLAC;
            // { AUDIO_INFO("ContentType %s, format is flac", ct); }
            AUDIO_INFO("format is flac");
            break;
        case CT_OPUS:
            m_codec = CODEC_OPUS;
            m_f_ogg = true; // opus is ogg
            // { AUDIO_INFO("ContentType %s, format is opus", ct); }
            AUDIO_INFO("format is opus");
            break;
        case CT_VORBIS:
            m_codec = CODEC_VORBIS;
            m_f_ogg = true; // vorbis is ogg
            // { AUDIO_INFO("ContentType %s, format is vorbis", ct); }
            AUDIO_INFO("format is vorbis");
            break;
        case CT_WAV:
            m_codec = CODEC_WAV;
            // { AUDIO_INFO("ContentType %s, format is wav", ct); }
            AUDIO_INFO("format is wav");
            break;
        case CT_OGG:
            m_codec = CODEC_OGG; AUDIO_INFO("format is ogg"); 	 // determine in first OGG packet -OPUS, VORBIS, FLAC
            m_f_ogg = true; // maybe flac or opus or vorbis
            break;
        case CT_PLS: m_playlistFormat = FORMAT_PLS; break;
        case CT_M3U: m_playlistFormat = FORMAT_M3U; break;
        case CT_ASX: m_playlistFormat = FORMAT_ASX; break;
        case CT_M3U8: m_playlistFormat = FORMAT_M3U8; break;
        case CT_TXT: // overwrite text/plain
            if(m_expectedCodec == CODEC_AAC) {
                m_codec = CODEC_AAC; AUDIO_INFO("format is aac"); /* AUDIO_INFO("set ct from M3U8 to AAC");*/ }
            if(m_expectedCodec == CODEC_MP3) {
                m_codec = CODEC_MP3; AUDIO_INFO("format is mp3"); /* AUDIO_INFO("set ct from M3U8 to MP3");*/ }
            if(m_expectedPlsFmt == FORMAT_ASX) {
                m_playlistFormat = FORMAT_ASX;  /* AUDIO_INFO("set playlist format to ASX");*/ }
            if(m_expectedPlsFmt == FORMAT_M3U) {
                m_playlistFormat = FORMAT_M3U;  /* AUDIO_INFO("set playlist format to M3U");*/ }
            if(m_expectedPlsFmt == FORMAT_M3U8) {
                m_playlistFormat = FORMAT_M3U8; /* AUDIO_INFO("set playlist format to M3U8");*/ }
            if(m_expectedPlsFmt == FORMAT_PLS) {
                m_playlistFormat = FORMAT_PLS; /* AUDIO_INFO("set playlist format to PLS");*/ }
            break;
        default:
            AUDIO_ERROR("%s, unsupported audio format", ct);
            return false;
            break;
    }
    return true;
}
// clang-format on
//##################################################################
void Audio::showstreamtitle(char* ml) {
    // example for ml:
    // StreamTitle='Oliver Frank - Mega Hitmix';StreamUrl='www.radio-welle-woerthersee.at';
    // or adw_ad='true';durationMilliseconds='10135';adId='34254';insertionType='preroll';
    // html: 'Bielszy odcie&#324; bluesa 682 cz.1' --> 'Bielszy odcień bluesa 682 cz.1'

    if(!ml) return;
    ps_ptr<char>title("title");
    ps_ptr<char>artist("artist");
    ps_ptr<char>streamTitle("streamTitle");
    ps_ptr<char>sUrl("sUrl");

    htmlToUTF8(ml); // convert to UTF-8

    int16_t  idx1 = 0, idx2, idx4, idx5, idx6, idx7, titleLen = 0, artistLen = 0, titleStart = 0, artistStart = 0;

    // if(idx1 < 0) idx1 = indexOf(ml, "Title:", 0); // Title found (e.g. https://stream-hls.bauermedia.pt/comercial.aac/playlist.m3u8)
    // if(idx1 < 0) idx1 = indexOf(ml, "title:", 0); // Title found (e.g. #EXTINF:10,title="The Dan Patrick Show (M-F 9a-12p ET)",artist="zc1401"

    if(indexOf(ml, "StreamTitle='<?xml version=", 0) == 0) {
        /* e.g. xmlStreamTitle
              StreamTitle='<?xml version="1.0" encoding="utf-8"?><RadioInfo><Table><DB_ALBUM_ID>37364</DB_ALBUM_ID>
              <DB_ALBUM_IMAGE>00000037364.jpg</DB_ALBUM_IMAGE><DB_ALBUM_NAME>Boyfriend</DB_ALBUM_NAME>
              <DB_ALBUM_TYPE>Single</DB_ALBUM_TYPE><DB_DALET_ARTIST_NAME>DOVE CAMERON</DB_DALET_ARTIST_NAME>
              <DB_DALET_ITEM_CODE>CD4161</DB_DALET_ITEM_CODE><DB_DALET_TITLE_NAME>BOYFRIEND</DB_DALET_TITLE_NAME>
              <DB_FK_SITE_ID>2</DB_FK_SITE_ID><DB_IS_MUSIC>1</DB_IS_MUSIC><DB_LEAD_ARTIST_ID>26303</DB_LEAD_ARTIST_ID>
              <DB_LEAD_ARTIST_NAME>Dove Cameron</DB_LEAD_ARTIST_NAME><DB_RADIO_IMAGE>cidadefm.jpg</DB_RADIO_IMAGE>
              <DB_RADIO_NAME>Cidade</DB_RADIO_NAME><DB_SONG_ID>120126</DB_SONG_ID><DB_SONG_LYRIC>60981</DB_SONG_LYRIC>
              <DB_SONG_NAME>Boyfriend</DB_SONG_NAME></Table><AnimadorInfo><TITLE>Cidade</TITLE>
              <START_TIME_UTC>2022-11-15T22:00:00+00:00</START_TIME_UTC><END_TIME_UTC>2022-11-16T06:59:59+00:00
              </END_TIME_UTC><SHOW_NAME>Cidade</SHOW_NAME><SHOW_HOURS>22h às 07h</SHOW_HOURS><SHOW_PANEL>0</SHOW_PANEL>
              </AnimadorInfo></RadioInfo>';StreamUrl='';
        */
        idx4 = indexOf(ml, "<DB_DALET_TITLE_NAME>");
        idx5 = indexOf(ml, "</DB_DALET_TITLE_NAME>");
        idx6 = indexOf(ml, "<DB_LEAD_ARTIST_NAME>");
        idx7 = indexOf(ml, "</DB_LEAD_ARTIST_NAME>");
        if(idx4 == -1 || idx5 == -1) return;
        titleStart = idx4 + 21; // <DB_DALET_TITLE_NAME>
        titleLen = idx5 - titleStart;

        if(idx6 != -1 && idx7 != -1) {
            artistStart = idx6 + 21; // <DB_LEAD_ARTIST_NAME>
            artistLen = idx7 - artistStart;
        }
        if(titleLen) title.assign(ml + titleStart, titleLen);
        if(artistLen) artist.assign(ml + artistStart, artistLen);

        if(title.valid() && artist.valid()){
            streamTitle.assign(title.get());
            streamTitle.append(" - ");
            streamTitle.append(artist.get());
        }
        else if(title.valid()){
            streamTitle.assign(title.get());
        }
        else if(artist.valid()){
            streamTitle.assign(artist.get());
        }
    }

    else if(indexOf(ml, "StreamTitle='") == 0){
        titleStart = 13;
        idx2 = indexOf(ml, ";", 12);
        if(idx2 > titleStart + 1){
            titleLen = idx2 - 1 - titleStart;
            streamTitle.assign(ml + 13, titleLen);
        }
    }

    else if(startsWith(ml, "#EXTINF")){
        // extraxt StreamTitle from m3u #EXTINF line to icy-format
        // orig: #EXTINF:10,title="text="TitleName",artist="ArtistName"
        // conv: StreamTitle=TitleName - ArtistName
        // orig: #EXTINF:10,title="text=\"Spot Block End\" amgTrackId=\"9876543\"",artist=" ",url="length=\"00:00:00\""
        // conv: StreamTitle=text=\"Spot Block End\" amgTrackId=\"9876543\" -

        idx1 = indexOf(ml, "title=\"");
        idx2 = indexOf(ml, "artist=\"");
        if(idx1 > 0){
            int titleStart = idx1 + 7;
            int idx3 = indexOf(ml, "\"", titleStart);
            if(idx3 > titleStart){
                int titleLength = idx3 - titleStart;
                title.assign(ml + titleStart, titleLength);
                 if(title.starts_with("text=\\")){ // #EXTINF:10,title="text=\"Spot Block End\"",artist=" ",
                    titleStart += 7;
                    idx3 = indexOf(ml, "\\", titleStart);
                    if(idx3 > titleStart){
                        int titleLength = idx3 - titleStart;
                        title.assign(ml + titleStart, titleLength);
                    }
                }
            }
        }
        if(idx2 > 0){
            int artistStart = idx2 + 8;
            int idx3 = indexOf(ml, "\"", artistStart);
            if(idx3 > artistStart){
                int artistLength = idx3 - artistStart;
                artist.assign(ml + artistStart, artistLength);
                if(strcmp(artist.get(), " ") == 0) artist.reset();
            }
        }
        if(title.valid() && artist.valid()){
            streamTitle.assign(title.get());
            streamTitle.append(" - ");
            streamTitle.append(artist.get());
        }
        else if(title.valid()){
            streamTitle.assign(title.get());
        }
        else if(artist.valid()){
            streamTitle.assign(artist.get());
        }
    }
    else{
        ;
    }

    if(indexOf(ml, "StreamUrl=", 0) > 0){
        idx1 = indexOf(ml, "StreamUrl=", 0);
        idx2 = indexOf(ml, ";", idx1);
        if(idx1 >= 0 && idx2 > idx1) { // StreamURL found
            uint16_t len = idx2 - idx1;
            sUrl.assign(ml + idx1, len);
            if(sUrl.valid()){
                AUDIO_INFO("Stream URL; %s", sUrl.get());
            }
        }
    }

    if(indexOf(ml, "adw_ad=", 0) > 0){
        idx1 = indexOf(ml, "adw_ad=", 0);
        if(idx1 >= 0) { // Advertisement found
            idx1 = indexOf(ml, "durationMilliseconds=", 0);
            idx2 = indexOf(ml, ";", idx1);
            if(idx1 >= 0 && idx2 > idx1) {
                uint16_t len = idx2 - idx1;
                ps_ptr<char> sAdv("sAdv");
                sAdv.assign(ml + idx1, len + 1);
                // AUDIO_INFO("Adveritsement: %s", sAdv.get());
                uint8_t pos = 21;                                                 // remove "StreamTitle="
                if(sAdv[pos] == '\'') pos++;                                      // remove leading  \'
                if(sAdv[strlen(sAdv.get()) - 1] == '\'') sAdv[strlen(sAdv.get()) - 1] = '\0'; // remove trailing \'
                AUDIO_INFO("Advertisement: %s", sAdv.get() + pos);
            }
        }
        return;
    }
    if(!streamTitle.valid()) return;

    if(!m_streamTitle.equals(streamTitle)){
        m_streamTitle.clone_from(streamTitle);
    }
    else{
        return; // is equal
    }

    if(m_streamTitle.starts_with("{\"")){ // maybe a json string
        // "{\"status\":0,\"error\":{\"info\":\"\\u042d\\u0442\\u043e \\u0440\\u0435\\u043a\\u043b\\u0430\\u043c\\u0430 \\u0438\\u043b\\u0438 \\u0434\\u0436\\u0438\\u043d\\u0433\\u043b\",\"code\":201},\"result\":\"\\u042d\\u0442\\u043e \\u0440\\u0435\\u043a\\u043b\\u0430\\u043c\\u0430 \\u0438\\u043b\\u0438 \\u0434\\u0436\\u0438\\u043d\\u0433\\u043b\"}\n0";
        ps_ptr<char> jsonIn("jsonIn");
        jsonIn.clone_from(m_streamTitle);
        jsonIn.truncate_at('\n'); // can be '{"status":1,"message":"Ok","result":"Ok","errorCode":0}\n0'
        if(!jsonIn.isJson()) return;
        int idx = jsonIn.index_of_icase("\"result\"");
        if(idx < 0) return;
        jsonIn.remove_before(idx + 10); // remove "result":
        jsonIn.truncate_at('"'); // remove after '"'    Ok","result":"Ok","errorCode":0} --> OK
        // AUDIO_INFO("jsonIn: %s", jsonIn.c_get());
        m_streamTitle.unicodeToUTF8(jsonIn.c_get());
    }

    /*info(evt_streamtitle,*/ audio_showstreamtitle(m_streamTitle.c_get());
}
//##################################################################
/*void Audio::showCodecParams() {

    AUDIO_INFO("Channels: %u", getChannels());
    AUDIO_INFO("SampleRate: %lu (Hz)", getSampleRate());
    AUDIO_INFO("BitsPerSample: %u", getBitsPerSample());
    if(getBitRate()) { AUDIO_INFO("BitRate: %lu", getBitRate()); }
//    if(getBitRate()) { info(evt_info, "BitRate: %lu", getBitRate()); }
    else { AUDIO_INFO("BitRate: N/A"); }

    if(m_codec == CODEC_AAC) {
        uint8_t answ = AACGetFormat();
        if(answ < 3) {
            const char hf[4][8] = {"unknown", "ADIF", "ADTS"};
            AUDIO_INFO("AAC HeaderFormat: %s", hf[answ]);
        }
        answ = AACGetSBR();
        if(answ > 0 && answ < 4) {
            const char sbr[4][50] = {"without SBR", "upsampled SBR", "downsampled SBR", "no SBR used, but file is upsampled by a factor 2"};
            AUDIO_INFO("Spectral band replication: %s", sbr[answ]);
        }
    }
}*/
//###################################################################
size_t Audio::sendBytes(uint8_t* data, size_t len) {

   if(!m_f_running) return 0; // guard

/*     m_sbyt.bytesLeft = 0;
    m_sbyt.nextSync = 0;

    if(!m_f_playing) {
        m_sbyt.channels = 2; // assume aac stereo
//        m_sbyt.isPS = 0;
        m_sbyt.f_setDecodeParamsOnce = true;
        m_sbyt.nextSync = findNextSync(data, len);
        if(m_sbyt.nextSync <  0) return len; // no syncword found
        if(m_sbyt.nextSync == 0) { m_f_playing = true; }
        if(m_sbyt.nextSync >  0) return m_sbyt.nextSync;
    }
    // m_f_playing is true at this pos
    int res = 0;
    m_sbyt.bytesLeft = len;
    int bytesDecoded = 0;

    if(m_codec == CODEC_NONE && m_playlistFormat == FORMAT_M3U8) return 0; // can happen when the m3u8 playlist is loaded
    if(!m_f_decode_ready) return 0; // find sync first

    bytesDecoded = len - m_sbyt.bytesLeft;

    if(bytesDecoded == 0) { // unlikely framesize
        AUDIO_INFO("framesize is 0, start decoding again");
        m_f_playing = false; // seek for new syncword
        // we're here because there was a wrong sync word so skip one byte and seek for the next
        return 1;
    }	*/
    // status: bytesDecoded > 0
    const char* st = NULL;
    std::vector<uint32_t> vec;
    switch(m_codec) {
        case CODEC_FLAC:
                            st = FLACgetStreamTitle();
                            if(st) {
                                audio_showstreamtitle(st);
                            }
                            break;
        case CODEC_VORBIS:
                            st = VORBISgetStreamTitle();
                            if(st) {
                                audio_showstreamtitle(st);
                            }
                            break;
/*        case CODEC_OPUS:
                            st = OPUSgetStreamTitle();
                            if(st){
                                audio_showstreamtitle(st);
                            }
                            break;
*/
    }
/*    if(m_sbyt.f_setDecodeParamsOnce && m_validSamples) {
        m_sbyt.f_setDecodeParamsOnce = false;
    }
    if(!m_validSamples) return bytesDecoded; //nothing to play

    uint16_t bytesDecoderOut = m_validSamples;
    calculateAudioTime(bytesDecoded, bytesDecoderOut);
//    calculateAudioTime(bytesDecoded, m_validSamples);

//    m_curSample = 0;
//    if(m_validSamples) {playChunk();}
//    return bytesDecoded;
//}
//##################################################################
//void Audio::playChunk() {
//    if(m_validSamples == 0) return 0; // nothing to do

//    if(!m_f_running) return 0; // guard
*/
    size_t chunk_length = 0;                                // Length of chunk 32 byte or shorter
    size_t bytesDecoded = 0;
//    bytesDecoded = 0;
//    uint8_t* data = InBuff.getReadPtr();

    data_mode_on();
    while(len){                                             // More to do?
        if(!digitalRead(dreq_pin)) break;
        chunk_length = len;
        if(len > vs1053_chunk_size){
            chunk_length = vs1053_chunk_size;
        }
        m_PlayingStartTime = millis();
        spi_VS1053->writeBytes(data, chunk_length);
        data         += chunk_length;
        len          -= chunk_length;
        bytesDecoded += chunk_length;
    }
    data_mode_off();
    return bytesDecoded;
//    return;
}
//##################################################################
/*void Audio::calculateAudioTime(uint16_t bytesDecoderIn, uint16_t bytesDecoderOut) {

//    if(m_dataMode != AUDIO_LOCALFILE && m_streamType != ST_WEBFILE) return; //guard

    float audioCurrentTime = 0.0;

    if(m_f_firstCurTimeCall) { // first call
        m_f_firstCurTimeCall = false;
        memset(&m_cat, 0, sizeof(audiolib::cat_t));
        m_cat.nominalBitRate = m_nominal_bitrate;

        if(m_codec == CODEC_FLAC && FLACGetAudioFileDuration()){ // BITSTREAMINFO FLAC/OGG
            m_audioFileDuration = FLACGetAudioFileDuration();
            m_cat.nominalBitRate = (m_audioDataSize / FLACGetAudioFileDuration()) * 8;
        }
    }

    m_cat.sumBytesIn   += bytesDecoderIn;
    m_cat.deltaBytesIn += bytesDecoderIn;
    m_cat.sumBytesOut  += bytesDecoderOut;


    if(m_cat.timeStamp + 50 < millis()){
        uint32_t t       = millis();            // time tracking
        uint32_t delta_t = t - m_cat.timeStamp; //    ---"---
        m_cat.timeStamp  = t;                   //    ---"---

        if(m_cat.nominalBitRate){
            audioCurrentTime = (uint32_t)(m_cat.sumBytesIn * 8 / m_cat.nominalBitRate);
        }
        else{
            double instBitRate = (m_cat.deltaBytesIn * 8000.0) / delta_t;
            m_cat.counter ++;
            m_cat.avrBitRate += (instBitRate - m_cat.avrBitRate) / m_cat.counter;
            if((abs(m_cat.avrBitRate- m_cat.oldAvrBitrate < 50)) && !m_cat.avrBitrateStable){
                m_cat.brCounter++;
                if(m_cat.brCounter > 6){
                    m_cat.avrBitrateStable = m_cat.avrBitRate;
                    AUDIO_INFO("estimated bitrate : %lu (b/s)", m_cat.avrBitrateStable);
//                    info(evt_bitrate, "%i", m_cat.avrBitrateStable);
                    AUDIO_INFO("BitRate: %lu", m_cat.avrBitrateStable);
                }
            }
            m_avr_bitrate = m_cat.avrBitRate;
            audioCurrentTime = (float)m_cat.sumBytesIn * 8 / m_cat.avrBitRate;
            m_audioFileDuration = round(((float)m_audioDataSize * 8 / m_cat.avrBitRate));
            m_cat.oldAvrBitrate = m_avr_bitrate;
        }
        m_cat.deltaBytesIn = 0;
        m_audioCurrentTime = round(audioCurrentTime);
    }

    if(m_haveNewFilePos && (m_cat.avrBitRate || m_cat.nominalBitRate)){
        uint32_t posWhithinAudioBlock =  m_haveNewFilePos - m_audioDataStart;
        float newTime = 0;
        if(m_cat.nominalBitRate){newTime = (float)posWhithinAudioBlock / (m_cat.nominalBitRate / 8);}
        else                    {newTime = (float)posWhithinAudioBlock / (m_cat.avrBitRate / 8); m_avr_bitrate = m_cat.avrBitRate;}
        m_audioCurrentTime = round(newTime);
        m_cat.sumBytesIn = posWhithinAudioBlock;
        m_haveNewFilePos = 0;
        m_cat.syltIdx = 0;
        if(m_syltLines.size()){
            while(m_cat.syltIdx < m_syltLines.size()){
                if(m_audioCurrentTime * 1000 < m_syltTimeStamp[m_cat.syltIdx]) break;
                m_cat.syltIdx++;
            }
            if(m_cat.syltIdx) m_cat.syltIdx--;
        }
    }

    if(m_syltLines.size()){
        //  AUDIO_INFO("%f", audioCurrentTime * 1000); // ms
        if(m_cat.syltIdx >= m_syltLines.size()) return;
        if(m_audioCurrentTime * 1000 > m_syltTimeStamp[m_cat.syltIdx]){
//            info(evt_lyrics, "%s", m_syltLines[m_cat.syltIdx].c_get());
            AUDIO_INFO("%s", (m_syltLines[m_cat.syltIdx].c_get()));
            m_cat.syltIdx++;
        }
    }
}*/
//****************************************************************************************
uint32_t Audio::getFileSize() { // returns the size of webfile or local file
    if(!m_audiofile) {
        if (m_audioFileSize > 0) { return m_audioFileSize;}
        return 0;
    }
    return m_audiofile.size();
}
//###################################################################
uint32_t Audio::getAudioFileDuration() {
    if(!getBitRate())                       return 0;
    if(m_playlistFormat == FORMAT_M3U8)     return 0;
    if(!m_audioDataSize)                    return 0;
    return m_audioFileDuration;
}
//###################################################################
/*uint32_t Audio::getAudioCurrentTime() { // return current time in seconds
    return m_audioCurrentTime;
}*/
uint32_t Audio::getAudioCurrentTime(){

   if(m_dataMode != AUDIO_LOCALFILE && m_streamType != ST_WEBFILE) return 0; //guard

   const uint16_t l3id012[16] = {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0};
   const uint16_t l3id3[16]   = {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0};
   uint16_t SCIStatus;

   if(m_codec == CODEC_MP3){
      SCIStatus=read_register(SCI_HDAT1);
      uint8_t layer = SCIStatus>>1 & 0b11;
      uint8_t id    = SCIStatus>>3 & 0b11;
      SCIStatus = read_register(SCI_HDAT0);
      if(layer==1){ //layer3
         if(id==3){m_avr_bitrate = l3id3[SCIStatus>>12] * 1000;}
         else{       m_avr_bitrate = l3id012[SCIStatus>>12] * 1000;}
      }
   if(m_codec == CODEC_FLAC || m_codec == CODEC_VORBIS){
      SCIStatus=read_register(SCI_HDAT0);
      m_avr_bitrate = SCIStatus * 8;
   }
   if(m_avr_bitrate==0) return 0;
   m_audioFileDuration = 8 * ((float)m_audioDataSize / (m_avr_bitrate));
   m_audioCurrentTime = 8 * ((float)getFilePos() / (m_avr_bitrate));

   if(m_haveNewFilePos && m_avr_bitrate){
      uint32_t posWhithinAudioBlock =  m_haveNewFilePos - m_audioDataStart;
      uint32_t newTime = posWhithinAudioBlock / (m_avr_bitrate / 8);
      m_audioCurrentTime = newTime;
      m_haveNewFilePos = 0;
   }
   return round(m_audioCurrentTime);
}
  return 0;
}
//###################################################################
/*uint32_t Audio::getAudioFilePosition(){
    if(!m_f_stream) return 0;
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)){AUDIO_ERROR("audio is not a file"); return 0;}
    return m_audioFilePosition - inBufferFilled();
}*/
uint32_t Audio::getFilePos() {
    if(!m_f_stream) return 0;
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)){AUDIO_ERROR("audio is not a file"); return 0;}
    return m_audioFilePosition - inBufferFilled();
}
//###################################################################
/*bool Audio::setAudioFilePosition(uint32_t pos){
    if(!m_f_stream) return false;
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)){AUDIO_ERROR("audio is not a file"); return false;}
    if((m_streamType == ST_WEBFILE) && (!m_f_acceptRanges)){AUDIO_ERROR("server does not accept ranges"); return false;}
    if(pos > m_audioDataStart + m_audioDataSize) {AUDIO_ERROR("given position is too large"); return false;}
    if(pos < m_audioDataStart) {AUDIO_INFO("set audiodatastart at %lu", m_audioDataStart); m_resumeFilePos = m_audioDataStart;}
    m_resumeFilePos = pos;
    return true;
}*/
bool Audio::setFilePos(uint32_t pos){
    if(!m_f_stream) return false;
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)){AUDIO_ERROR("audio is not a file"); return false;}
    if((m_streamType == ST_WEBFILE) && (!m_f_acceptRanges)){AUDIO_ERROR("server does not accept ranges"); return false;}
    if(pos > m_audioDataStart + m_audioDataSize) {AUDIO_ERROR("given position is too large"); return false;}
    if(pos < m_audioDataStart) {AUDIO_INFO("set audiodatastart at %lu", m_audioDataStart); m_resumeFilePos = m_audioDataStart;}
    m_resumeFilePos = pos;
    return true;
}
//###################################################################
/*uint32_t Audio::getTotalPlayingTime() {
    // Is set to zero by a connectToXXX() and starts as soon as the first audio data is available,
    // the time counting is not interrupted by a 'pause / resume'
    return millis() - m_PlayingStartTime;
}*/
//###################################################################
/*bool Audio::setAudioPlayTime(uint16_t sec) {
    // e.g. setAudioPlayTime(300) sets the pointer at pos 5 min
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)) return false;  // guard
    if(!getBitRate())                                                   return false;  // guard
    if(!m_f_running)                                                    return false;  // guard

    if(sec > getAudioFileDuration()) sec = getAudioFileDuration();
    uint32_t filepos = m_audioDataStart + (getBitRate() * sec / 8);
    m_resumeFilePos = filepos;
    return true;
}*/
//###################################################################
bool Audio::setTimeOffset(int sec) { // fast forward or rewind the current position in seconds
    // info(evt_info, "time offset %li sec", sec);
    if((m_dataMode != AUDIO_LOCALFILE) && (m_streamType != ST_WEBFILE)){ AUDIO_ERROR("%s","not a file"); return false;}  // guard
    if(!getBitRate())                                                   return false;  // guard
    if(!m_f_running)                                                    return false;  // guard

    int32_t newTime = getAudioCurrentTime() + sec;
    if (newTime < 0) newTime = 0;
    if (newTime > getAudioFileDuration()) {stopSong(); return true;}

    uint32_t oneSec = getBitRate() / 8;                 // bytes decoded in one sec
    int32_t  offset = oneSec * sec;                      // bytes to be wind/rewind
    int32_t pos = m_audioFilePosition - inBufferFilled();
    pos += offset;
    m_resumeFilePos = pos;
    return true;
}
//###################################################################
int32_t Audio::audioFileRead(uint8_t* buff, size_t len){
    if(buff && len == 0) return 0; // nothing to do
    int32_t readed_bytes = 0;
    uint32_t offset = 0;
    // This method standardized reading files, regardless of the source (local or web) and the correct number of the bytes read must be determined.
    int32_t res = -1;

    if(!buff && !len){ // read one byte
        if(m_dataMode == AUDIO_LOCALFILE){
            res = m_audiofile.read();
            if(res >= 0) m_audioFilePosition ++;
        }
        else{
            res = m_client->read();
            if(res >= 0) m_audioFilePosition ++;
        }
    }
    else { // read len
        uint32_t t = millis();
        while(len > 0){
            if(m_dataMode == AUDIO_LOCALFILE){
                readed_bytes = m_audiofile.read(buff + offset, len);
                if(readed_bytes >= 0) {m_audioFilePosition += readed_bytes; len -= readed_bytes; offset += readed_bytes; res = offset; t = millis();}
                if(readed_bytes <= 0) break;
            }
            else{
                readed_bytes = m_client->read(buff + offset, len);
                if(readed_bytes >= 0) {m_audioFilePosition += readed_bytes; len -= readed_bytes; offset += readed_bytes; res = offset; t = millis();}
                if(readed_bytes <= 0) break; // vTaskDelay(5);
            }
            if(t + 3000 < millis()){AUDIO_ERROR("timeout"); res = -1; break;}
        }
    }
    return res;
}

//###################################################################
int32_t Audio::audioFileSeek(uint32_t position, size_t len){
    int32_t res = -1;

    if(m_dataMode == AUDIO_LOCALFILE){
        uint32_t actualPos = m_audiofile.position(); // starts with 1
        if(actualPos != m_audioFilePosition){
            /*AUDIO_LOG_WARN*/AUDIO_INFO("actualPos != m_audioFilePosition %lu != %lu", actualPos, m_audioFilePosition);
            m_audioFilePosition = actualPos;
        }
        if(!m_audiofile) return -1;
        if(position > m_audiofile.size()){
            /*AUDIO_LOG_WARN*/AUDIO_INFO("position larger than size %lu > %lu", position, m_audiofile.size());
            position = m_audiofile.size();
        }
        bool r = m_audiofile.seek(position);
        m_audioFilePosition = m_audiofile.position();
        if(r == false){
            AUDIO_ERROR("something went wrong");
            return -1;
        }
        else{
            return position;
        }
    }
    else{
        if(m_f_acceptRanges){
            bool r;
            if(len == 0) len = UINT32_MAX;
            r = httpRange(position, len);
            if(res == false){AUDIO_ERROR("http range request was not successful"); return 0;}
            r = parseHttpRangeHeader();
            if(r == false){AUDIO_ERROR("http range response was not successful"); return 0;}
            m_audioFilePosition = position;
            return position;
        }
    }
    return res;
}
//###################################################################
/*bool Audio::fsRange(uint32_t range) {

    if((m_dataMode == AUDIO_LOCALFILE) && !m_audiofile){                 AUDIO_ERROR("%s","local file not accessibble"); return false;}  // guard
    uint32_t startAB = m_audioDataStart;                 // audioblock begin
    uint32_t endAB = m_audioDataStart + m_audioDataSize; // audioblock end
    if(range < (int32_t)startAB) {range = startAB;}
    if(range >= (int32_t)endAB)  {range = endAB;}

    m_validSamples = 0;
    m_resumeFilePos = range;  // used in processLocalFile()
    return true;
}*/
//###################################################################
uint32_t Audio::getBitRate() {
    if(m_nominal_bitrate) return m_nominal_bitrate;
    else if(m_avr_bitrate) return m_avr_bitrate;
    else {m_avr_bitrate = (wram_read(0x1e05) & 0xFF) * 1000;  	// Kbit/s => bit/s
    return m_avr_bitrate;}
}
//###################################################################
/*uint64_t Audio::getLastGranulePosition(){
    if(m_codec != CODEC_OPUS && m_codec != CODEC_VORBIS) return 0;

    uint64_t granulePos = 0;
    uint8_t* buff = (uint8_t*) ps_malloc(UINT16_MAX);
    if(!buff) {AUDIO_ERROR("oom"); return 0;}
    int rangeStart = m_audioFileSize - UINT16_MAX - 1;
//    AUDIO_LOG_WARN("rangeStart: %lu, audioFileSize: %li, len: %lu, %lu", __LINE__, rangeStart, m_audioFileSize, UINT16_MAX);
    audioFileSeek(rangeStart, UINT16_MAX);
    audioFileRead(buff, UINT16_MAX);
    int32_t pos = specialIndexOfLast(buff, "OggS", UINT16_MAX);
    if(buff[pos + 5] & 0x04){ // is last page;
        for (int j = 0; j < 8; j++) {
            granulePos |= ((uint64_t)buff[pos + 6 + j] << (j * 8));
        }
    }
    AUDIO_INFO("granulePos %llu", granulePos);
    m_resumeFilePos = 0;
    if(buff) {free(buff); buff = NULL;}
    return granulePos;
}*/
//###################################################################
const uint8_t everyn = 4;
void Audio::computeVUlevel() {

// * \brief get current measured VU Meter
// * Returns the calculated peak sample values from both channels in 3 dB increaments through.
// * Where the high byte represent the left channel, and the low bytes the right channel.
// * Values from 0 to 31 are valid for both channels.
// *
// * \warning This feature is only available with patches that support VU meter.

//  if(!VS_PATCH_ENABLE) return;
  static uint8_t cc = 0;
  cc++;
  if(!_vuInitalized || !config.store.vumeter || cc!=everyn) return;
  if(cc==everyn) cc=0;
  int16_t reg = read_register(SCI_AICTRL3); 	 // returns the values in 1 dB resolution from 0 (lowest) 95 (highest)
  vuLeft = map((uint8_t)(reg & 0x00FF), 85, 95, 0, 255);
  vuRight = map((uint8_t)(reg >> 8), 85, 95, 0, 255);
  if(vuLeft>config.vuThreshold) config.vuThreshold = vuLeft;
  if(vuRight>config.vuThreshold) config.vuThreshold=vuRight;
}

//###################################################################
uint16_t Audio::get_VUlevel(uint16_t dimension){
//  if(!VS_PATCH_ENABLE) return 0;
  if(!_vuInitalized || !config.store.vumeter || config.vuThreshold==0 || !m_f_running) return 0;
  uint8_t L = map(vuLeft, config.vuThreshold, 0, 0, dimension);
  uint8_t R = map(vuRight, config.vuThreshold, 0, 0, dimension);
  return (L << 8) | R;
}
//###################################################################
/*size_t Audio::bufferFilled(){
    return InBuff.bufferFilled();
}
//###################################################################
size_t Audio::bufferFree(){
    return InBuff.freeSpace();
}	*/
//###################################################################
void Audio::setTone(int8_t *rtone){                       // Set bass/treble (4 nibbles)

    // Set tone characteristics.  See documentation for the 4 nibbles.
    uint16_t value=0;                                       // Value to send to SCI_BASS
    int i;                                                  // Loop control

    for(i=0; i < 4; i++) {
        value=(value << 4) | rtone[i];                      // Shift next nibble in
    }
    write_register(SCI_BASS, value);                        // Volume left and right
}
/*
Name			Bits			Description
ST AMPLITUDE		15:12		Treble Control in 1.5 dB steps (-8..7, 0 = off)
ST FREQLIMIT		11:8			Lower limit frequency in 1000 Hz steps (1..15) 			// 1000..15000
SB AMPLITUDE		7:4			Bass Enhancement in 1 dB steps (0..15, 0 = off)
SB FREQLIMIT		3:0			Lower limit frequency in 10 Hz steps (2..15)				// 20..150
*/
/*
void Audio::setTone(int8_t gainLowPass, int8_t gainBandPass, int8_t gainHighPass){ 
  if(gainLowPass<0) gainLowPass=0;
  if(gainLowPass>15) gainLowPass=15;
  if(gainBandPass<0) gainBandPass=0;
  if(gainBandPass>13) gainBandPass=13;
  int8_t rtone[] = {(int8_t)map(gainHighPass, -16, 16, -8, 7), (int8_t)(2+gainBandPass), gainLowPass, (int8_t)(15-gainBandPass)};
  setTone(rtone);
}
*/
void Audio::setTone(int8_t gainLowPass, int8_t gainBandPass, int8_t gainHighPass){ 
  gainHighPass = constrain(gainHighPass, -16, 16);
  gainBandPass = constrain(gainBandPass, -16, 16);
  gainLowPass = constrain(gainLowPass, -16, 16);

  uint8_t trebleFreqLimit = map(-gainBandPass, -16, 16, 1, 15);
  uint8_t bassFreqLimit = map(gainBandPass, -16, 16, 2, 15);
  uint8_t st_amplitude = map(gainHighPass, -16, 16, -8, 7);
  uint8_t sb_amplitude = map(gainLowPass, -16, 16, 0, 15);
  uint16_t sci_bass = (st_amplitude << 12) | (trebleFreqLimit << 8) |
                      (sb_amplitude << 4) | bassFreqLimit;
  write_register(SCI_BASS, sci_bass);
}
//###################################################################
void Audio::forceMono(bool m) { // #100 mono option
    m_f_forceMono = m;          // false stereo, true mono
  if (m_f_forceMono != false) {
//    wram_write(0x1e09, 0x0001);		// To activate the mono downmix mode
      write_register(SCI_WRAMADDR, 0x1e09);
      write_register(SCI_WRAM, 0x0001);
  }
}
//###################################################################
void Audio::setBalance(int8_t bal) { // bal -16...16
//    if(bal < -16) bal = -16;
//    if(bal > 16) bal = 16;
    m_balance = bal;

//    computeLimit();
    setVolume(curvol);
}
//###################################################################
void Audio::setVolume(uint8_t vol) {
    // Set volume.  Both left and right.
    // Input value is 0..21.  21 is the loudest.
    // Clicking reduced by using 0xf8 to 0x00 as limits.
//    uint16_t value;					// Value to send to SCI_VOL
	uint8_t valueL, valueR;			// Value to send to SCI_VOL
	int16_t balance_map = map(m_balance, -16, 16, -100, 100);
	
        curvol = vol;					// Save for later use
	valueL = vol;
   	valueR = vol;
    if (balance_map < 0) {
        valueR = (float)valueR-(float)valueR * abs((float)balance_map)/100;
    } else if (balance_map > 0) {
    		valueL = (float)valueL-(float)valueL * abs((float)balance_map)/100;
    }
	uint8_t lgvolL = VS1053VOL(valueL);
	uint8_t lgvolR = VS1053VOL(valueR);
	if(lgvolL==VS1053VOLM) lgvolL=0;
	if(lgvolR==VS1053VOLM) lgvolR=0;
	valueL=map(lgvolL, 0, 254, 0xF8, 0x00);
	valueR=map(lgvolR, 0, 254, 0xF8, 0x00);
//	value=(valueL << 8) | valueR;
	write_register(SCI_VOL, (valueL << 8) | valueR);
}
//###################################################################
uint8_t Audio::getVolume(){                                 // Get the currenet volume setting.
    return curvol;
}
//###################################################################
uint32_t Audio::inBufferFilled() {
    // current audio input buffer fillsize in bytes
    return InBuff.bufferFilled();
}
//###################################################################
/*uint32_t Audio::inBufferFree() {
    // current audio input buffer free space in bytes
    return InBuff.freeSpace();
}

uint32_t Audio::getInBufferSize() {
    // current audio input buffer size in bytes
    return InBuff.getBufsize();
}
bool Audio::setInBufferSize(size_t mbs){
    size_t oldBuffSize = InBuff.getBufsize();
    stopSong();
    bool res = InBuff.setBufsize(mbs);
    if(res == false){
        AUDIO_ERROR("%i bytes is not possible, back to %i bytes", mbs, oldBuffSize);
        InBuff.setBufsize(oldBuffSize);
    }
    InBuff.init();
    return res;
}	*/
//###################################################################
//    AAC - T R A N S P O R T S T R E A M
//###################################################################
bool Audio::ts_parsePacket(uint8_t* packet, uint8_t* packetStart, uint8_t* packetLength) {

    bool log = false;

    const uint8_t TS_PACKET_SIZE = 188;
    const uint8_t PAYLOAD_SIZE = 184;
    const uint8_t PID_ARRAY_LEN = 4;

    (void)PAYLOAD_SIZE; // suppress [-Wunused-variable]

    if(packet == NULL) {
        if(log) /*AUDIO_LOG_WARN*/AUDIO_INFO("parseTS reset");
        memset(&m_tspp, 0, sizeof(audiolib::tspp_t));
        return true;
    }

    // --------------------------------------------------------------------------------------------------------
    // 0. Byte SyncByte  | 0 | 1 | 0 | 0 | 0 | 1 | 1 | 1 | always bit pattern of 0x47
    //---------------------------------------------------------------------------------------------------------
    // 1. Byte           |PUSI|TP|   |PID|PID|PID|PID|PID|
    //---------------------------------------------------------------------------------------------------------
    // 2. Byte           |PID|PID|PID|PID|PID|PID|PID|PID|
    //---------------------------------------------------------------------------------------------------------
    // 3. Byte           |TSC|TSC|AFC|AFC|CC |CC |CC |CC |
    //---------------------------------------------------------------------------------------------------------
    // 4.-187. Byte      |Payload data if AFC==01 or 11  |
    //---------------------------------------------------------------------------------------------------------

    // PUSI Payload unit start indicator, set when this packet contains the first byte of a new payload unit.
    //      The first byte of the payload will indicate where this new payload unit starts.
    // TP   Transport priority, set when the current packet has a higher priority than other packets with the same PID.
    // PID  Packet Identifier, describing the payload data.
    // TSC  Transport scrambling control, '00' = Not scrambled.
    // AFC  Adaptation field control, 01 – no adaptation field, payload only, 10 – adaptation field only, no payload,
    //                                11 – adaptation field followed by payload, 00 – RESERVED for future use
    // CC   Continuity counter, Sequence number of payload packets (0x00 to 0x0F) within each stream (except PID 8191)

    // for(int i = 1; i < 188; i++) {printf("%02X ", packet[i - 1]); if(i && (i % 16 == 0)) printf("\n");}
    // printf("\n----------\n");

    if(packet[0] != 0x47) {
        AUDIO_ERROR("ts SyncByte not found, first bytes are 0x%02X 0x%02X 0x%02X 0x%02X", packet[0], packet[1], packet[2], packet[3]);
        stopSong();
        return false;
    }
    int PID = (packet[1] & 0x1F) << 8 | (packet[2] & 0xFF);
//    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PID: 0x%04X(%d)", PID, PID);
    int PUSI = (packet[1] & 0x40) >> 6;
//    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Payload Unit Start Indicator: %d", PUSI);
    int AFC = (packet[3] & 0x30) >> 4;
//    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Adaption Field Control: %d", AFC);

    int AFL = -1;
    if((AFC & 0b10) == 0b10) {  // AFC '11' Adaptation Field followed
        AFL = packet[4] & 0xFF; // Adaptation Field Length
//        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Adaptation Field Length: %d", AFL);
    }
    int PLS = PUSI ? 5 : 4;     // PayLoadStart, Payload Unit Start Indicator
    if(AFL > 0) PLS += AFL + 1; // skip adaption field

    if(AFC == 2){ // The TS package contains only an adaptation Field and no user data.
        *packetStart = AFL + 1;
        *packetLength = 0;
        return true;
    }

    if(PID == 0) {
        // Program Association Table (PAT) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PAT");
        m_tspp.pidNumber = 0;
        m_tspp.pidOfAAC = 0;

        int startOfProgramNums = 8;
        int lengthOfPATValue = 4;
        int sectionLength = ((packet[PLS + 1] & 0x0F) << 8) | (packet[PLS + 2] & 0xFF);
//        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Section Length: %d", sectionLength);
        int program_number, program_map_PID;
        int indexOfPids = 0;
        (void)program_number; // [-Wunused-but-set-variable]
        for(int i = startOfProgramNums; i <= sectionLength; i += lengthOfPATValue) {
            program_number = ((packet[PLS + i] & 0xFF) << 8) | (packet[PLS + i + 1] & 0xFF);
            program_map_PID = ((packet[PLS + i + 2] & 0x1F) << 8) | (packet[PLS + i + 3] & 0xFF);
//            if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Program Num: 0x%04X(%d) PMT PID: 0x%04X(%d)", program_number, program_number, program_map_PID, program_map_PID);
            m_tspp.pids[indexOfPids++] = program_map_PID;
        }
        m_tspp.pidNumber = indexOfPids;
        *packetStart = 0;
        *packetLength = 0;
        return true;
    }
    else if(PID == m_tspp.pidOfAAC) {
//        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("AAC");
        uint8_t posOfPacketStart = 4;
        if(AFL >= 0) {
            posOfPacketStart = 5 + AFL;
//            if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("posOfPacketStart: %d", posOfPacketStart);
        }
        // Packetized Elementary Stream (PES) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PES_DataLength %i", m_tspp.PES_DataLength);
        if(m_tspp.PES_DataLength > 0) {
            *packetStart = posOfPacketStart + m_tspp.fillData;
            *packetLength = TS_PACKET_SIZE - posOfPacketStart - m_tspp.fillData;
//            if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("packetlength %i", *packetLength);
            m_tspp.fillData = 0;
            m_tspp.PES_DataLength -= (*packetLength);
            return true;
        }
        else {
            int firstByte = packet[posOfPacketStart] & 0xFF;
            int secondByte = packet[posOfPacketStart + 1] & 0xFF;
            int thirdByte = packet[posOfPacketStart + 2] & 0xFF;
//            if(log) /*AUDIO_LOG_DEBUG*/INFO ("First 3 bytes: 0x%02X, 0x%02X, 0x%02X", firstByte, secondByte, thirdByte);
            if(firstByte == 0x00 && secondByte == 0x00 && thirdByte == 0x01) { // Packet start code prefix
                // --------------------------------------------------------------------------------------------------------
                // posOfPacketStart + 0...2     0x00, 0x00, 0x01                                          PES-Startcode
                //---------------------------------------------------------------------------------------------------------
                // posOfPacketStart + 3         0xE0 (Video) od 0xC0 (Audio)                              StreamID
                //---------------------------------------------------------------------------------------------------------
                // posOfPacketStart + 4...5     0xLL, 0xLL                                                PES Packet length
                //---------------------------------------------------------------------------------------------------------
                // posOfPacketStart + 6...7                                                               PTS/DTS Flags
                //---------------------------------------------------------------------------------------------------------
                // posOfPacketStart + 8         0xXX                                                      header length
                //---------------------------------------------------------------------------------------------------------

                uint8_t StreamID = packet[posOfPacketStart + 3] & 0xFF;
                if(StreamID >= 0xC0 && StreamID <= 0xDF) { ; } // okay ist audio stream
                if(StreamID >= 0xE0 && StreamID <= 0xEF) {AUDIO_ERROR("video stream!"); return false; }
                int PES_PacketLength = ((packet[posOfPacketStart + 4] & 0xFF) << 8) + (packet[posOfPacketStart + 5] & 0xFF);
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PES PacketLength: %d", PES_PacketLength);
                bool PTS_flag = false;
                bool DTS_flag = false;
                int flag_byte1 = packet[posOfPacketStart + 6] & 0xFF;
                int flag_byte2 = packet[posOfPacketStart + 7] & 0xFF;  (void) flag_byte2; // unused yet
                if(flag_byte1 & 0b10000000) PTS_flag = true;
                if(flag_byte1 & 0b00000100) DTS_flag = true;
//                if(log && PTS_flag) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PTS_flag is set");
//                if(log && DTS_flag) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("DTS_flag is set");
                uint8_t PES_HeaderDataLength = packet[posOfPacketStart + 8] & 0xFF;
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PES_headerDataLength %d", PES_HeaderDataLength);

                m_tspp.PES_DataLength = PES_PacketLength;
                int startOfData = PES_HeaderDataLength + 9;
                if(posOfPacketStart + startOfData >= 188) { // only fillers in packet
//                    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("posOfPacketStart + startOfData %i", posOfPacketStart + startOfData);
                    *packetStart = 0;
                    *packetLength = 0;
                    m_tspp.PES_DataLength -= (PES_HeaderDataLength + 3);
                    m_tspp.fillData = (posOfPacketStart + startOfData) - 188;
//                    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("fillData %i", m_tspp.fillData);
                    return true;
                }
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("First AAC data byte: %02X", packet[posOfPacketStart + startOfData]);
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Second AAC data byte: %02X", packet[posOfPacketStart + startOfData + 1]);
                *packetStart = posOfPacketStart + startOfData;
                *packetLength = TS_PACKET_SIZE - posOfPacketStart - startOfData;
                m_tspp.PES_DataLength -= (*packetLength);
                m_tspp.PES_DataLength -= (PES_HeaderDataLength + 3);
                return true;
            }
            if(firstByte == 0 && secondByte == 0 && thirdByte == 0){
                // PES packet startcode prefix is 0x000000
                // skip such packets
                return true;
            }
        }
        *packetStart = 0;
        *packetLength = 0;
        AUDIO_ERROR("PES not found");
        return false;
    }
    else if(m_tspp.pidNumber) {
        //  Program Map Table (PMT) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        for(int i = 0; i < m_tspp.pidNumber; i++) {
            if(PID == m_tspp.pids[i]) {
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("PMT");
                int staticLengthOfPMT = 12;
                int sectionLength = ((packet[PLS + 1] & 0x0F) << 8) | (packet[PLS + 2] & 0xFF);
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Section Length: %d", sectionLength);
                int programInfoLength = ((packet[PLS + 10] & 0x0F) << 8) | (packet[PLS + 11] & 0xFF);
//                if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Program Info Length: %d", programInfoLength);
                int cursor = staticLengthOfPMT + programInfoLength;
                while(cursor < sectionLength - 1) {
                    int streamType = packet[PLS + cursor] & 0xFF;
                    int elementaryPID = ((packet[PLS + cursor + 1] & 0x1F) << 8) | (packet[PLS + cursor + 2] & 0xFF);
//                    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("Stream Type: 0x%02X Elementary PID: 0x%04X", streamType, elementaryPID);

                    if(streamType == 0x0F || streamType == 0x11 || streamType == 0x04) {
//                        if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("AAC PID discover");
                        m_tspp.pidOfAAC = elementaryPID;
                    }
                    int esInfoLength = ((packet[PLS + cursor + 3] & 0x0F) << 8) | (packet[PLS + cursor + 4] & 0xFF);
//                    if(log) /*AUDIO_LOG_DEBUG*/AUDIO_INFO("ES Info Length: 0x%04X", esInfoLength);
                    cursor += 5 + esInfoLength;
                }
            }
        }
        *packetStart = 0;
        *packetLength = 0;
        return true;
    }
    // PES received before PAT and PMT seen
    *packetStart = 0;
    *packetLength = 0;
    if(PID > 0) {
        return true;
    }
    return false;
}
//##################################################################
//    W E B S T R E A M  -  H E L P   F U N C T I O N S
//##################################################################
bool Audio::readMetadata(uint16_t maxBytes, uint16_t *readedBytes, bool first) {
    *readedBytes = 0;
    ps_ptr<char>buff(__LINE__); buff.alloc(4096); buff.clear(); // is max 256 *16
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(first) {
        m_rmet.pos_ml = 0; // determines the current position in metaline
        m_rmet.metaDataSize = 0;
        m_rmet.res = 0;
        return true;
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    if(!maxBytes) return 0; // guard

    if(!m_rmet.metaDataSize) {
        int b = audioFileRead(); // First byte of metadata?
        if (b < 0) {
            /*AUDIO_LOG_WARN*/AUDIO_ERROR("client->read() failed (%d)", b);
            return false;
        }
        m_rmet.metaDataSize = b * 16;        // New count for metadata including length byte, max 4096
        m_rmet.pos_ml = 0;
        buff[m_rmet.pos_ml] = 0; // Prepare for new line
        *readedBytes = 1;
        maxBytes -= 1;
    }
    if(!m_rmet.metaDataSize) {
        return *readedBytes;
    } // metalen is 0
    int32_t a = audioFileRead((uint8_t*)&buff[m_rmet.pos_ml], min((uint16_t)(m_rmet.metaDataSize - m_rmet.pos_ml), (uint16_t)(maxBytes)));

    if(a > 0){
        m_rmet.res += a;
        *readedBytes += a;
        m_rmet.pos_ml += a;
    }
    if(m_rmet.pos_ml == m_rmet.metaDataSize) {
        buff[m_rmet.pos_ml] = '\0';
        // buff.hex_dump(m_rmet.metaDataSize);
        if(buff.strlen() > 0) { // Any info present?
            // metaline contains artist and song name.  For example:
            // "StreamTitle='Don McLean - American Pie';StreamUrl='';"
            // Sometimes it is just other info like:
            // "StreamTitle='60s 03 05 Magic60s';StreamUrl='';"
            // Isolate the StreamTitle, remove leading and trailing quotes if present.
            latinToUTF8(buff);          // convert to UTF-8 if necessary
            int pos = buff.index_of_icase("song_spot", 0); // remove some irrelevant infos
            if(pos > 3) {                               // e.g. song_spot="T" MediaBaseId="0" itunesTrackId="0"
                buff[pos] = 0;
            }
            showstreamtitle(buff.get()); // Show artist and title if present in metadata
        }
        m_metacount = m_metaint;
        m_rmet.metaDataSize = 0;
        m_rmet.pos_ml = 0;
        buff[m_rmet.pos_ml] = 0; // Prepare for new line
    }
    else{
        return false; // not enough data, next round
    }
    return true;
}
//##################################################################
int32_t Audio::getChunkSize(uint16_t *readedBytes, bool first) {
    uint32_t timeout = 2000; // ms
    uint32_t ctime;

    if (first) {
        m_gchs.oneByteOfTwo = false;
        m_gchs.f_skipCRLF = false;
        m_gchs.isHttpChunked = true;      // default: We assume http chunked
        m_gchs.transportLimit = 0;        // 0 = not yet recognized
        return 0;
    }

    *readedBytes = 0;

    // if we are in transport chunk mode → return limit
    if (!m_gchs.isHttpChunked) {
        return m_gchs.transportLimit;
    }

    // skip CRLF from the previous chunk (only http-chunked)
    if (m_gchs.f_skipCRLF) {
        uint32_t t = millis();
        if(m_client->available() == 1 && !m_gchs.oneByteOfTwo){
            int a = audioFileRead(); m_gchs.oneByteOfTwo = true; *readedBytes = 1;
            if (a != 0x0D) AUDIO_INFO("chunk count error, expected: 0x0D, received: 0x%02X", a);
            return -1;
        }
        if(!m_gchs.oneByteOfTwo){
            int a = audioFileRead();
            if (a != 0x0D) AUDIO_INFO("chunk count error, expected: 0x0D, received: 0x%02X", a);
            *readedBytes += 1;
            if(!m_client->available()){return -1;}
        }
        m_gchs.oneByteOfTwo = false;
        int b = audioFileRead();
        if (b != 0x0A) /*AUDIO_LOG_WARN*/AUDIO_INFO("chunk count error, expected: 0x0A, received: 0x%02X", b);
        *readedBytes += 1;
        m_gchs.f_skipCRLF = false;
        if(!m_client->available()){return -1;}
    }

    // -------- HTTP-chunked-Read Logic --------
    std::string chunkLine;
    ctime = millis();

    while (true) {
        if ((millis() - ctime) > timeout) {
            AUDIO_INFO("chunkedDataTransfer: timeout");
            stopSong();
            return 0;
        }
        if (!m_client->available()) continue;
        int b = audioFileRead();
        if (b < 0) continue;

        (*readedBytes)++;

        if (b == '\n') break; // End of the line
        if (b == '\r') continue;

        chunkLine += static_cast<char>(b);

        // Detection: if signs are not hexadecimal and not ';'→ No http chunk
        if (!isxdigit(b) && b != ';') {
            // We have no valid HTTP chunk line → assume transport chunking
            m_gchs.isHttpChunked = false;
            // determine limit from the current data volume + already read bytes
            m_gchs.transportLimit = m_client->available() + *readedBytes;
//            /*AUDIO_LOG_DEBUG*/AUDIO_INFO("No http chunked recognized-switch to transport chunking with limit %u", (unsigned)m_gchs.transportLimit);
            return m_gchs.transportLimit;
        }
    }

    // Extract the hex number (before possibly ';')
    size_t semicolonPos = chunkLine.find(';');
    std::string hexSize = (semicolonPos != std::string::npos) ? chunkLine.substr(0, semicolonPos) : chunkLine;

    size_t chunksize = strtoul(hexSize.c_str(), nullptr, 16);

    if (chunksize > 0) {
        m_gchs.f_skipCRLF = true; // skip next CRLF after data
    } else {
        // last chunk: read the final CRLF
        uint8_t idx = 0;
        ctime = millis();
        while (idx < 2 && (millis() - ctime) < timeout) {
            int ch = audioFileRead();
            if (ch < 0) continue;
            idx++;
        }
    }
    return chunksize;
}
//##################################################################
bool Audio::readID3V1Tag() {
    if (m_codec != CODEC_MP3) return false;
    ps_ptr<char>chBuff(__LINE__);
    chBuff.alloc(256);

    const uint8_t* p = InBuff.getReadPtr();

    // Lambda for simplification
    auto readID3Field = [&](ps_ptr<char>& field, const uint8_t* src, size_t len, const char* label = nullptr) {
        field.alloc(len + 1, "field");
        memcpy(field.get(), src, len);
        field[len] = '\0';
        latinToUTF8(field);
        if (field.strlen() > 0 && label) {
            field.insert(label, 0);
            /*info(evt_id3data,*/ audio_id3data(field.get());
        }
    };

    if (InBuff.bufferFilled() == 128 && startsWith((const char*)p, "TAG")) {
        ps_ptr<char> title("title"), artist("artist"), album("album"), year("year"), comment("comment");

        readID3Field(title,   p + 3,     30, "Title: ");
        readID3Field(artist,  p + 33,    30, "Artist: ");
        readID3Field(album,   p + 63,    30, "Album: ");
        readID3Field(year,    p + 93,    4,  "Year: ");
        readID3Field(comment, p + 97,    30, "Comment: ");

        uint8_t zeroByte = p[125];
        uint8_t track = p[126];
        uint8_t genre8 = p[127];

        AUDIO_INFO(zeroByte ? "ID3 version: 1" : "ID3 Version 1.1");

        if (zeroByte == 0) {
            sprintf(chBuff.get(), "Track Number: %d", track);
            /*info(evt_id3data,*/ audio_id3data(chBuff.get());
        }

        if (genre8 < 192) {
            sprintf(chBuff.get(), "Genre: %d", genre8);
            /*info(evt_id3data,*/ audio_id3data(chBuff.get());
        }

        return true;
    }

    if (InBuff.bufferFilled() == 227 && startsWith((const char*)p, "TAG+")) { // "TAG+" "can exist as an extension, does not overwrite" TAG"
        AUDIO_INFO("ID3 version: 1 - Enhanced TAG");

        ps_ptr<char> title("title"), artist("artist"), album("album"), genre("genre");

        readID3Field(title,  p + 4,     60, "Title: ");
        readID3Field(artist, p + 64,    60, "Artist: ");
        readID3Field(album,  p + 124,   60, "Album: ");
        readID3Field(genre,  p + 185,   30, "Genre: ");

        // optional expansion: speed, start-time, end-time
        return true;
    }

    return false;
    // [1] https://en.wikipedia.org/wiki/List_of_ID3v1_Genres
    // [2] https://en.wikipedia.org/wiki/ID3#ID3v1_and_ID3v1.1[5]
}
//##################################################################
int32_t Audio::newInBuffStart(int32_t m_resumeFilePos){
        int32_t  offset = 0, buffFillValue = 0, res = 0;
        uint32_t timeOut = 0;

        if(m_controlCounter != 100){AUDIO_ERROR("timeOffset not possible"); m_resumeFilePos = -1; offset = -1; goto exit;}
        if(m_resumeFilePos >= (int32_t)m_audioDataStart + m_audioDataSize) {   m_resumeFilePos = -1; offset = -1; goto exit;}
//        if(m_codec == CODEC_M4A && ! m_stsz_position){                         m_resumeFilePos = -1; offset = -1; goto exit;}

        if(m_resumeFilePos <  (int32_t)m_audioDataStart) m_resumeFilePos = m_audioDataStart;
//        buffFillValue = min(m_audioDataSize - m_resumeFilePos, UINT16_MAX);
        buffFillValue = ((m_audioDataSize - m_resumeFilePos) < UINT16_MAX) ? (m_audioDataSize - m_resumeFilePos) : UINT16_MAX;

        m_f_lockInBuffer = true;                          // lock the buffer, the InBuffer must not be re-entered in playAudioData()
        {
            while(m_f_audioTaskIsDecoding) vTaskDelay(1); // We can't reset the InBuffer while the decoding is in progress
            m_f_allDataReceived = false;

/* process before */
/*            if(m_codec == CODEC_M4A){
                m_resumeFilePos += m4a_correctResumeFilePos();
                if(m_resumeFilePos == -1) goto exit;
            }*/

/* skip to position */
            res = audioFileSeek(m_resumeFilePos);
            InBuff.resetBuffer();
            offset = 0;
            audioFileRead(InBuff.getReadPtr() + offset, buffFillValue);
            InBuff.bytesWritten(buffFillValue);

/* process after */
            offset = 0;
//            if(m_codec == CODEC_OPUS || m_codec == CODEC_VORBIS) {if(InBuff.bufferFilled() < 0xFFFF) return - 1;} // ogg frame <= 64kB
//            if(m_codec == CODEC_WAV)   {while((m_resumeFilePos % 4) != 0){m_resumeFilePos++; offset++; if(m_resumeFilePos >= m_audioFileSize) goto exit;}}  // must divisible by four
            if(m_codec == CODEC_MP3)   {offset = mp3_correctResumeFilePos();  if(offset == -1) goto exit; /*MP3Decoder_ClearBuffer();*/}
            if(m_codec == CODEC_FLAC)  {offset = flac_correctResumeFilePos(); if(offset == -1) goto exit; /*FLACDecoderReset();*/}
//            if(m_codec == CODEC_VORBIS){offset = ogg_correctResumeFilePos();  if(offset == -1) goto exit; /*VORBISDecoder_ClearBuffers();*/}
//            if(m_codec == CODEC_OPUS)  {offset = ogg_correctResumeFilePos();  if(offset == -1) goto exit; /*OPUSDecoder_ClearBuffers();*/}


            InBuff.bytesWasRead(offset);
        }
        m_f_lockInBuffer = false;
        return res + offset;
exit:
        m_f_lockInBuffer = false;
        stopSong();
        return offset;
}
//##################################################################
boolean Audio::streamDetection(uint32_t bytesAvail) {
    if(!m_lastHost.valid()) {AUDIO_ERROR("m_lastHost is empty"); return false;}

    // if within one second the content of the audio buffer falls below the size of an audio frame 100 times,
    // issue a message
    if(m_sdet.tmr_slow + 1000 < millis()) {
        m_sdet.tmr_slow = millis();
        if(m_sdet.cnt_slow > 100) AUDIO_INFO("slow stream, dropouts are possible");
        m_sdet.cnt_slow = 0;
    }
    if(InBuff.bufferFilled() < InBuff.getMaxBlockSize()) m_sdet.cnt_slow++;
    if(bytesAvail) {
        m_sdet.tmr_lost = millis() + 1000;
        m_sdet.cnt_lost = 0;
    }
    if(InBuff.bufferFilled() > InBuff.getMaxBlockSize() * 2) return false; // enough data available to play

    // if no audio data is received within three seconds, a new connection attempt is started.
    if(m_sdet.tmr_lost < millis()) {
        m_sdet.cnt_lost++;
        m_sdet.tmr_lost = millis() + 1000;
        if(m_sdet.cnt_lost == 5) { // 5s no data?
            m_sdet.cnt_lost = 0;
            AUDIO_INFO("Stream lost -> try new connection");
            m_f_reset_m3u8Codec = false;
            httpPrint(m_lastHost.get());
            return true;
        }
    }
    return false;
}
//##################################################################
uint32_t Audio::m4a_correctResumeFilePos() {
    // In order to jump within an m4a file, the exact beginning of an aac block must be found. Since m4a cannot be
    // streamed, i.e. there is no syncword, an imprecise jump can lead to a crash.

    if(!m_stsz_position) return m_audioDataStart; // guard

    typedef union {
        uint8_t  u8[4];
        uint32_t u32;
    } tu;
    tu uu;

    uint32_t i = 0, pos = m_audioDataStart;
    uint32_t filePtr = m_audioFilePosition;
    bool found = false;
    audioFileSeek(m_stsz_position);

    auto read_next = [&]() -> int {
        int r;
        int cnt = 0;
        while(true){
            r = audioFileRead();
            if(r >= 0) break;
            vTaskDelay(10);
            cnt++;
            if(cnt > 300) {AUDIO_ERROR("timeout"); break;}
        }
        return r;
    };

    while(i < m_stsz_numEntries) {
        i++;
        uu.u8[3] = read_next();
        uu.u8[2] = read_next();
        uu.u8[1] = read_next();
        uu.u8[0] = read_next();

        pos += uu.u32;
        if(pos >= m_resumeFilePos) {found = true; break;}
    }
    if(!found)  return -1; // not found

    // audioFileSeek(filePtr); // restore file pointer
    return pos - m_resumeFilePos; // return the number of bytes to jump
}
//##################################################################
uint32_t Audio::ogg_correctResumeFilePos() {
    // The starting point is the next OggS magic word
    vTaskDelay(1);
    //  AUDIO_INFO("in_resumeFilePos %i", resumeFilePos);

    auto find_sync_word = [&](uint8_t* pos, uint32_t av) -> int {
        int steps = 0;
        while(av--) {
            if(pos[steps] == 'O'){
                if(pos[steps + 1] == 'g') {
                    if(pos[steps + 2] == 'g') {
                        if(pos[steps + 3] == 'S') { // Check for the second part of magic word
                            return steps;   // Magic word found, return the number of steps
                        }
                    }
                }
            }
            steps++;
        }
        return -1; // Return -1 if OggS magic word is not found
    };

    uint8_t*       readPtr = InBuff.getReadPtr();
    size_t         av = InBuff.getMaxAvailableBytes();
    int32_t        steps = 0;

    if(av < InBuff.getMaxBlockSize()) return -1; // guard

    steps = find_sync_word(readPtr, av);
    if(steps == -1) return -1;
    return steps; // Return the number of steps to the sync word
}
//##################################################################
int32_t Audio::flac_correctResumeFilePos() {

    auto find_sync_word = [&](uint8_t* pos, uint32_t av) -> int {
        int steps = 0;
        while(av--) {
            char c = pos[steps];
            steps++;
            if(c == 0xFF) { // First byte of sync word found
                char nextByte = pos[steps];
                steps++;
                if(nextByte == 0xF8) {     // Check for the second part of sync word
                    return steps - 2;       // Sync word found, return the number of steps
                }
            }
        }
        return -1; // Return -1 if sync word is not found
    };

    uint8_t*       readPtr = InBuff.getReadPtr();
    size_t         av = InBuff.getMaxAvailableBytes();
    int32_t        steps = 0;

    if(av < InBuff.getMaxBlockSize()) return -1; // guard

    steps = find_sync_word(readPtr, av);
    if(steps == -1) return -1;
    return steps; // Return the number of steps to the sync word
}
//##################################################################
int32_t Audio::mp3_correctResumeFilePos() {

    int32_t        steps = 0;
    int32_t        sumSteps = 0;
    uint8_t*       pos = InBuff.getReadPtr();
    size_t         av = InBuff.getMaxAvailableBytes();

    if(av < InBuff.getMaxBlockSize()) return -1; // guard

    while(true) {
        steps = MP3FindSyncWord(pos, av);
        if(steps == 0)break;
        if(steps == -1) return -1;
        pos += steps;
        sumSteps += steps;
    }
    // AUDIO_INFO("found sync word at %i  sync1 = 0x%02X, sync2 = 0x%02X", readPtr - pos, *readPtr, *(readPtr + 1));
    return sumSteps; // return the position of the first byte of the frame
}
//###################################################################
//###################################################################
//###################################################################
uint8_t Audio::determineOggCodec(uint8_t* data, uint16_t len){
    // if we have contentType == application/ogg; codec cn be OPUS, FLAC or VORBIS
    // let's have a look, what it is
    int idx = specialIndexOf(data, "OggS", 6);
    if(idx != 0) {
        if(specialIndexOf(data, "fLaC", 6)) {
//           oggHead_idx = idx;
//           oggHead_data = data;
//           parseFlacComment(data, len);
//            read_FLAC_Header(data, len);
           return CODEC_FLAC;
        }
        return CODEC_NONE;
    }
    data += 27;
    idx = specialIndexOf(data, "OpusHead", 40);
    if(idx >= 0) {
//       oggHead_idx = idx;
//       oggHead_data = data;
//       parseOpusComment(data, len);
       return CODEC_OPUS;
       }
    idx = specialIndexOf(data, "fLaC", 40);
    if(idx >= 0) {
//       oggHead_idx = idx;
//       oggHead_data = data;
//       parseFlacComment(data, len);
//        read_FLAC_Header(data, len);
       return CODEC_FLAC;
       }
    idx = specialIndexOf(data, "vorbis", 40);
    if(idx >= 0) {
//       oggHead_idx = idx;
//       oggHead_data = data;
//       parseVorbisComment(data, len);
        return CODEC_VORBIS;
        }
    return CODEC_NONE;
}
/* //###################################################################
int32_t Audio::OGG_specialIndexOf(uint8_t* base, const char* str, int32_t baselen, bool exact){
    int32_t result = 0;  					// seek for str in buffer or in header up to baselen, not nullterninated
    if (strlen(str) > baselen) return -1; 			// if exact == true seekstr in buffer must have "\0" at the end
    for (int32_t i = 0; i < baselen - strlen(str); i++){
        result = i;
        for (int32_t j = 0; j < strlen(str) + exact; j++){
            if (*(base + i + j) != *(str + j)){
                result = -1;
                break;
            }
        }
        if (result >= 0) break;
    }
    return result;
}
//################################################################### */
char* Audio::VORBISgetStreamTitle(){
    if(s_f_vorbisNewSteamTitle){
        s_f_vorbisNewSteamTitle = false;
        return s_vorbisChbuf;
    }
    return NULL;
}
//###################################################################
int8_t Audio::parseVorbisComment(uint8_t *inbuf, int16_t nBytes){      // reference https://xiph.org/vorbis/doc/v-comment.html

    int8_t   ret = 0;

    // first bytes are: '.vorbis'
    uint32_t pos = 7;
    uint32_t vendorLength       = *(inbuf + pos + 3) << 24; // lengt of vendor string, e.g. Xiph.Org libVorbis I 20070622
             vendorLength      += *(inbuf + pos + 2) << 16;
             vendorLength      += *(inbuf + pos + 1) << 8;
             vendorLength      += *(inbuf + pos);
    uint16_t s_vorbisCommentHeaderLength = 0;
    int32_t   s_commentLength = 0;

    if(vendorLength > 254){  // guard
       log_e("vorbis comment too long, vendorLength %i", vendorLength);
       return 0;
    }

    memcpy(s_vorbisChbuf, inbuf + 11, vendorLength);
    s_vorbisChbuf[vendorLength] = '\0';
    pos += 4 + vendorLength;
    s_vorbisCommentHeaderLength -= (7 + 4 + vendorLength);

    // log_i("vendorLength %x", vendorLength);
    // log_i("vendorString %s", s_vorbisChbuf);

    uint8_t nrOfComments = *(inbuf + pos);
    // log_i("nrOfComments %i", nrOfComments);
    pos += 4;
    s_vorbisCommentHeaderLength -= 4;

    int32_t idx = 0;
    char* artist = NULL;
    char* title  = NULL;
    uint32_t commentLength = 0;

    for(int32_t i = 0; i < nrOfComments; i++){
        commentLength  = 0;
        commentLength  = *(inbuf + pos + 3) << 24;
        commentLength += *(inbuf + pos + 2) << 16;
        commentLength += *(inbuf + pos + 1) << 8;
        commentLength += *(inbuf + pos);
        s_commentLength = commentLength;

        uint8_t cl = min((uint32_t)254, commentLength);
        memcpy(s_vorbisChbuf, inbuf + pos +  4, cl);
        s_vorbisChbuf[cl] = '\0';

        // log_i("commentLength %i comment %s", commentLength, s_vorbisChbuf);

        idx =  specialIndexOf((uint8_t*)s_vorbisChbuf, "artist=", 10);
        if(idx != 0) idx =  specialIndexOf((uint8_t*)s_vorbisChbuf, "ARTIST=", 10);
        if(idx == 0){ artist = strndup((const char*)(s_vorbisChbuf + 7), commentLength - 7); s_commentLength = 0;
        AUDIO_INFO("ARTIST: %s", artist); }

        idx =  specialIndexOf((uint8_t*)s_vorbisChbuf, "title=", 10);
        if(idx != 0) idx =  specialIndexOf((uint8_t*)s_vorbisChbuf, "TITLE=", 10);
        if(idx == 0){ title = strndup((const char*)(s_vorbisChbuf + 6), commentLength - 6); s_commentLength = 0;
        AUDIO_INFO("TITLE: %s", title); }
    }

    if(artist && title){
        strcpy(s_vorbisChbuf, artist);
        strcat(s_vorbisChbuf, " - ");
        strcat(s_vorbisChbuf, title);
        s_f_vorbisNewSteamTitle = true;
        ret = 1;
    }
    else if(artist){
        strcpy(s_vorbisChbuf, artist);
        s_f_vorbisNewSteamTitle = true;
        ret = 1;
    }
    else if(title){
        strcpy(s_vorbisChbuf, title);
        s_f_vorbisNewSteamTitle = true;
        ret = 1;
    }
    if(artist){free(artist); artist = NULL;}
    if(title) {free(title);  title = NULL;}

    return ret;
}
//###################################################################
char* Audio::OPUSgetStreamTitle(){
    if(s_f_opusNewSteamTitle){
        s_f_opusNewSteamTitle = false;
        return s_opusSteamTitle;
    }
    return NULL;
}
//###################################################################
int8_t Audio::parseOpusComment(uint8_t *inbuf, int32_t nBytes){      // reference https://exiftool.org/TagNames/Vorbis.html#Comments
                                                       // reference https://www.rfc-editor.org/rfc/rfc7845#section-5

    int32_t idx = specialIndexOf(inbuf, "OpusTags", 10);
    if(idx != 0) return 0; // is not OpusTags

    int8_t   ret = 0;

    char* artist = NULL;
    char* title  = NULL;

    uint16_t pos = 8;
             nBytes -= 8;
    uint32_t vendorLength       = *(inbuf + 11) << 24; // lengt of vendor string, e.g. Lavf58.65.101
             vendorLength      += *(inbuf + 10) << 16;
             vendorLength      += *(inbuf +  9) << 8;
             vendorLength      += *(inbuf +  8);
    pos += vendorLength + 4;
    nBytes -= (vendorLength + 4);
    uint32_t commentListLength  = *(inbuf + 3 + pos) << 24; // nr. of comment entries
             commentListLength += *(inbuf + 2 + pos) << 16;
             commentListLength += *(inbuf + 1 + pos) << 8;
             commentListLength += *(inbuf + 0 + pos);
    pos += 4;
    nBytes -= 4;

    for(int32_t i = 0; i < commentListLength; i++){
        uint32_t commentStringLen   = *(inbuf + 3 + pos) << 24;
                 commentStringLen  += *(inbuf + 2 + pos) << 16;
                 commentStringLen  += *(inbuf + 1 + pos) << 8;
                 commentStringLen  += *(inbuf + 0 + pos);
        pos += 4;
        nBytes -= 4;
        idx = specialIndexOf(inbuf + pos, "artist=", 10);
        if(idx != 0) idx = specialIndexOf(inbuf + pos, "ARTIST=", 10);
        if(idx == 0){ artist = strndup((const char*)(inbuf + pos + 7), commentStringLen - 7);
        AUDIO_INFO("ARTIST: %s", artist);
        }
        idx = specialIndexOf(inbuf + pos, "title=", 10);
        if(idx != 0) idx = specialIndexOf(inbuf + pos, "TITLE=", 10);
        if(idx == 0){ title = strndup((const char*)(inbuf + pos + 6), commentStringLen - 6);
        AUDIO_INFO("TITLE: %s", title);
        }
    }

    if(artist && title){
        strcpy(s_opusSteamTitle, artist);
        strcat(s_opusSteamTitle, " - ");
        strcat(s_opusSteamTitle, title);
        s_f_opusNewSteamTitle = true;
        ret = 1;
    }
    else if(artist){
        strcpy(s_opusSteamTitle, artist);
        s_f_opusNewSteamTitle = true;
        ret = 1;
    }
    else if(title){
        strcpy(s_opusSteamTitle, title);
        s_f_opusNewSteamTitle = true;
        ret = 1;
    }
    if(artist){free(artist); artist = NULL;}
    if(title) {free(title);  title = NULL;}

    return ret;
}
//###################################################################
char* Audio::FLACgetStreamTitle(){
    if(s_f_flacNewStreamtitle){
        s_f_flacNewStreamtitle = false;
        return s_flacStreamTitle;
    }
    return NULL;
}
//###################################################################
int8_t Audio::parseFlacComment(uint8_t *inbuf, int16_t nBytes){

    int8_t   ret = 0;
    uint16_t pos = 0;
    int32_t  blockLength = 0;
    uint32_t vendorLength = 0;
    uint32_t commemtStringLength = 0;
    uint32_t userCommentListLength = 0;
    uint8_t  mdBlockHeader = 0;
    uint8_t  blockType = 0;
    uint16_t s_f_lastMetaDataBlock = 0;
    uint16_t s_flacRemainBlockPicLen = 0;
    char*    vb[2] = {0}; 					// vorbis comment

//    enum {streamInfo, padding, application, seekTable, vorbisComment, cueSheet, picture};

//    while(true){
        mdBlockHeader         = *(inbuf + pos);
        s_f_lastMetaDataBlock = mdBlockHeader & 0b10000000; 		//log_w("lastMdBlockFlag %i", s_f_lastMetaDataBlock);
        blockType             = mdBlockHeader & 0b01111111; 			//log_w("blockType %i", blockType);

        blockLength        = *(inbuf + pos + 1) << 16;
        blockLength       += *(inbuf + pos + 2) << 8;
        blockLength       += *(inbuf + pos + 3); 					//log_w("blockLength %i", blockLength);

        nBytes -= 4;
        pos += 4;

        switch(blockType) {

            case 0:
                //log_i("nBytes %i, blockLength %i", nBytes, blockLength);
                pos += blockLength;
                nBytes -= blockLength;
                break;

            case 4: 								// https://www.xiph.org/vorbis/doc/v-comment.html
                vendorLength  = *(inbuf + pos + 3) << 24;
                vendorLength += *(inbuf + pos + 2) << 16;
                vendorLength += *(inbuf + pos + 1) <<  8;
                vendorLength += *(inbuf + pos + 0);
                if(vendorLength > 1024){  log_e("vendorLength > 1024 bytes");  }

                pos += 4 + vendorLength;
                userCommentListLength  = *(inbuf + pos + 3) << 24;
                userCommentListLength += *(inbuf + pos + 2) << 16;
                userCommentListLength += *(inbuf + pos + 1) <<  8;
                userCommentListLength += *(inbuf + pos + 0);

                pos += 4;
                commemtStringLength = 0;

                for(int32_t i = 0; i < userCommentListLength; i++){
                    commemtStringLength  = *(inbuf + pos + 3) << 24;
                    commemtStringLength += *(inbuf + pos + 2) << 16;
                    commemtStringLength += *(inbuf + pos + 1) <<  8;
                    commemtStringLength += *(inbuf + pos + 0);

                    if((specialIndexOf(inbuf + pos + 4, "TITLE", 6) == 0) || (specialIndexOf(inbuf + pos + 4, "title", 6) == 0)){
                        vb[0] = strndup((const char*)(inbuf + pos + 4 + 6), min((uint32_t)127, commemtStringLength - 6));
                        AUDIO_INFO("TITLE: %s", vb[0]);
                    }
                    if((specialIndexOf(inbuf + pos + 4, "ARTIST", 7) == 0) || (specialIndexOf(inbuf + pos + 4, "artist", 7) == 0)){
                        vb[1] = strndup((const char*)(inbuf + pos + 4 + 7), min((uint32_t)127, commemtStringLength - 7));
                        AUDIO_INFO("ARTIST: %s", vb[1]);
                    }
                    if((specialIndexOf(inbuf + pos + 4, "ALBUM", 6) == 0) || (specialIndexOf(inbuf + pos + 4, "album", 6) == 0)){
                        vb[2] = strndup((const char*)(inbuf + pos + 4 + 6), min((uint32_t)127, commemtStringLength - 6));
                        AUDIO_INFO("ALBUM: %s", vb[2]);
                    }
                }

                memset(s_flacStreamTitle, 0, 256);
                if(vb[1] && vb[0]){ 				// artist and title
                    strcpy(s_flacStreamTitle, vb[1]);
                    strcat(s_flacStreamTitle, " - ");
                    strcat(s_flacStreamTitle, vb[0]);
                    s_f_flacNewStreamtitle = true;
                    ret = 1;
                }
                else if(vb[1]){ 					// only artist
                    strcpy(s_flacStreamTitle, vb[1]);
                    s_f_flacNewStreamtitle = true;
                    ret = 1;
                }
                else if(vb[0]){ 					// only title
                    strcpy(s_flacStreamTitle, vb[0]);
                    s_f_flacNewStreamtitle = true;
                    ret = 1;
                }
                for(int32_t i = 0; i < 8; i++){
                    if(vb[i]){free(vb[i]); vb[i] = NULL;}
                }
                break;
        }
//    }
    return ret;
}
//###################################################################
// separate task for decoding and outputting the data. 'playAudioData()' is started periodically and fetches the data from the InBuffer.
//  This ensures that the I2S-DMA is always sufficiently filled, even if the Arduino 'loop' is stuck.
//****************************************************************************************
void Audio::setAudioTaskCore(uint8_t coreID){  // Recommendation:If the ARDUINO RUNNING CORE is 1, the audio task should be core 0 or vice versa
    if(coreID > 1) return;
    stopAudioTask();
    xSemaphoreTake(mutex_audioTask, 0.3 * configTICK_RATE_HZ);
    m_audioTaskCoreId = coreID;
    xSemaphoreGive(mutex_audioTask);
    startAudioTask();
}
//****************************************************************************************
void Audio::startAudioTask() {
    if (m_f_audioTaskIsRunning) {
        AUDIO_INFO("Task is already running.");
        return;
    }
    m_f_audioTaskIsRunning = true;


    m_audioTaskHandle = xTaskCreateStaticPinnedToCore(
        &Audio::taskWrapper,    /* Function to implement the task */
        "PeriodicTask",         /* Name of the task */
        AUDIO_STACK_SIZE,       /* Stack size in words */
        this,                   /* Task input parameter */
        2,                      /* Priority of the task */
        xAudioStack,            /* Task stack */
        &xAudioTaskBuffer,      /* Memory for the task's control block */
        m_audioTaskCoreId       /* Core where the task should run */
    );
}
//****************************************************************************************
void Audio::stopAudioTask()  {
    if (!m_f_audioTaskIsRunning) {
        AUDIO_INFO("audio task is not running.");
        return;
    }
    xSemaphoreTake(mutex_audioTask, 0.3 * configTICK_RATE_HZ);
    m_f_audioTaskIsRunning = false;
    if (m_audioTaskHandle != nullptr) {
        vTaskDelete(m_audioTaskHandle);
        m_audioTaskHandle = nullptr;
    }
    xSemaphoreGive(mutex_audioTask);
}
//****************************************************************************************
void Audio::taskWrapper(void *param) {
    Audio *runner = static_cast<Audio*>(param);
    runner->audioTask();
}
//****************************************************************************************
void Audio::audioTask() {
    while (m_f_audioTaskIsRunning) {
        vTaskDelay(1 / portTICK_PERIOD_MS);  // periodically every x ms
        performAudioTask();
    }
    vTaskDelete(nullptr);  // Delete this task
}
//****************************************************************************************
void Audio::performAudioTask() {
    if(!m_f_running) return;
    if(!m_f_stream) return;
    if(m_codec == CODEC_NONE) return; // wait for codec is  set
    if(m_codec == CODEC_OGG)  return; // wait for FLAC, VORBIS or OPUS
    xSemaphoreTake(mutex_audioTask, 0.3 * configTICK_RATE_HZ);
//    while(m_validSamples) {vTaskDelay(20 / portTICK_PERIOD_MS); playChunk();} // I2S buffer full
    while(m_validSamples) { vTaskDelay(20 / portTICK_PERIOD_MS); } // I2S buffer full
    playAudioData();
    xSemaphoreGive(mutex_audioTask);
}
//****************************************************************************************
uint32_t Audio::getHighWatermark(){
    UBaseType_t highWaterMark = uxTaskGetStackHighWaterMark(m_audioTaskHandle);
    return highWaterMark; // dwords
}
//****************************************************************************************
#endif  //  if I2S_DOUT==255
